package in.exuber.usmarket.activity.paidcommissionsfilter;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

import in.exuber.usmarket.R;
import in.exuber.usmarket.activity.homeaddproducts.HomeAddProductsActivity;
import in.exuber.usmarket.activity.profileedit.ProfileEditActivity;
import in.exuber.usmarket.apimodels.login.loginoutput.MobileLang;
import in.exuber.usmarket.utils.ConnectionDetector;
import in.exuber.usmarket.utils.Constants;

import static in.exuber.usmarket.utils.UtilMethods.getLanguageLabelPreference;
import static in.exuber.usmarket.utils.UtilMethods.hideKeyBoard;

public class PaidCommissionsFilterActivity extends AppCompatActivity implements View.OnClickListener {

    //Declaring views
    private LinearLayout paidCommissionsFilterActivityContainer;

    private LinearLayout toolbarDoneClick;
    private LinearLayout toolberClearClick;

    //Connection Detector
    private ConnectionDetector connectionDetector;

    //Sharedpreferences
    private SharedPreferences marketPreference;

    TextView toolBar_headerText,clearAllText,doneText,categories,monthText,yearText,thisYearText,previousYearText,historicalText,
            txt_JanText,txt_FebText,txt_MarText,txt_AprText,txt_MayText,txt_JunText,txt_JulText,txt_AugText,txt_SepText,txt_OctText,
            txt_NovText,txt_DecText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paid_commissions_filter);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        //Initialising connection detector
        connectionDetector = new ConnectionDetector(PaidCommissionsFilterActivity.this);

        //Initialising shared preferences
        marketPreference =  getSharedPreferences(Constants.PREFERENCE_NAME,MODE_PRIVATE);

        //Setting Toolbar
        Toolbar toolbar = findViewById(R.id.paidCommissionsFilter_toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);

        //Initialising views
        paidCommissionsFilterActivityContainer = findViewById(R.id.activity_paid_commissions_filter);

        toolbarDoneClick = findViewById(R.id.ll_paidCommissionsFilter_toolBar_doneClick);
        toolberClearClick = findViewById(R.id.ll_paidCommissionsFilter_toolBar_clearLayout);

        toolBar_headerText=findViewById(R.id.tv_paidCommissionsFilter_toolBar_headerText);
        clearAllText=findViewById(R.id.txt_clearAllText);
        doneText=findViewById(R.id.txt_doneText);
        categories=findViewById(R.id.txt_categories);
        monthText=findViewById(R.id.txt_monthText);
        yearText=findViewById(R.id.txt_yearText);
        thisYearText=findViewById(R.id.txt_thisYearText);
        previousYearText=findViewById(R.id.txt_previousYearText);
        historicalText=findViewById(R.id.txt_historicalText);
        txt_JanText=findViewById(R.id.txt_JanText);
        txt_FebText=findViewById(R.id.txt_FebText);
        txt_MarText=findViewById(R.id.txt_MarText);
        txt_AprText=findViewById(R.id.txt_AprText);
        txt_MayText=findViewById(R.id.txt_MayText);
        txt_JunText=findViewById(R.id.txt_JunText);
        txt_JulText=findViewById(R.id.txt_JulText);
        txt_AugText=findViewById(R.id.txt_AugText);
        txt_SepText=findViewById(R.id.txt_SepText);
        txt_OctText=findViewById(R.id.txt_OctText);
        txt_NovText=findViewById(R.id.txt_NovText);
        txt_DecText=findViewById(R.id.txt_DecText);

        //Setting onclick
        toolbarDoneClick.setOnClickListener(this);
        toolberClearClick.setOnClickListener(this);

        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(PaidCommissionsFilterActivity.this);
        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1480")) {
                toolBar_headerText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1479")) {
                clearAllText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1134")) {
                doneText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1138")) {
                categories.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1481")) {
                monthText.setText(languageLabelModelList.get(index).getValue());
            }


            if (languageLabelModelList.get(index).getLangCode().equals("1486")) {
                txt_JanText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1487")) {
                txt_FebText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1488")) {
                txt_MarText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1489")) {
                txt_AprText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1490")) {
                txt_MayText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1491")) {
                txt_JunText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1492")) {
                txt_JulText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1493")) {
                txt_AugText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1494")) {
                txt_SepText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1495")) {
                txt_OctText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1496")) {
                txt_NovText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1497")) {
                txt_DecText.setText(languageLabelModelList.get(index).getValue());
            }

            if (languageLabelModelList.get(index).getLangCode().equals("1482")) {
                yearText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1483")) {
                thisYearText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1484")) {
                previousYearText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1485")) {
                historicalText.setText(languageLabelModelList.get(index).getValue());
            }
        }

    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {

            case R.id.ll_paidCommissionsFilter_toolBar_doneClick:

                //Hiding Keyboard
                hideKeyBoard(PaidCommissionsFilterActivity.this);

                finish();


                break;
        }

    }
}
