
package in.exuber.usmarket.apimodels.agreements.agreementsoutput;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AgreementOutput {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("agreementId")
    @Expose
    private String agreementId;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("recipent")
    @Expose
    private Recipent recipent;
    @SerializedName("company")
    @Expose
    private Object company;
    @SerializedName("role")
    @Expose
    private Role role;
    @SerializedName("agreementStatus")
    @Expose
    private AgreementStatus agreementStatus;
    @SerializedName("desc")
    @Expose
    private Object desc;
    @SerializedName("url")
    @Expose
    private String url;
    @SerializedName("dataStatus")
    @Expose
    private String dataStatus;
    @SerializedName("createdBy")
    @Expose
    private Object createdBy;
    @SerializedName("createdOn")
    @Expose
    private Long createdOn;
    @SerializedName("updatedBy")
    @Expose
    private Object updatedBy;
    @SerializedName("updatedOn")
    @Expose
    private Object updatedOn;
    @SerializedName("totalAgreement")
    @Expose
    private Integer totalAgreement;
    @SerializedName("agreementData")
    @Expose
    private List<AgreementDatum> agreementData = null;
    @SerializedName("fileList")
    @Expose
    private Object fileList;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAgreementId() {
        return agreementId;
    }

    public void setAgreementId(String agreementId) {
        this.agreementId = agreementId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Recipent getRecipent() {
        return recipent;
    }

    public void setRecipent(Recipent recipent) {
        this.recipent = recipent;
    }

    public Object getCompany() {
        return company;
    }

    public void setCompany(Object company) {
        this.company = company;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public AgreementStatus getAgreementStatus() {
        return agreementStatus;
    }

    public void setAgreementStatus(AgreementStatus agreementStatus) {
        this.agreementStatus = agreementStatus;
    }

    public Object getDesc() {
        return desc;
    }

    public void setDesc(Object desc) {
        this.desc = desc;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDataStatus() {
        return dataStatus;
    }

    public void setDataStatus(String dataStatus) {
        this.dataStatus = dataStatus;
    }

    public Object getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Object createdBy) {
        this.createdBy = createdBy;
    }

    public Long getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Long createdOn) {
        this.createdOn = createdOn;
    }

    public Object getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(Object updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Object getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Object updatedOn) {
        this.updatedOn = updatedOn;
    }

    public Integer getTotalAgreement() {
        return totalAgreement;
    }

    public void setTotalAgreement(Integer totalAgreement) {
        this.totalAgreement = totalAgreement;
    }

    public List<AgreementDatum> getAgreementData() {
        return agreementData;
    }

    public void setAgreementData(List<AgreementDatum> agreementData) {
        this.agreementData = agreementData;
    }

    public Object getFileList() {
        return fileList;
    }

    public void setFileList(Object fileList) {
        this.fileList = fileList;
    }

}
