
package in.exuber.usmarket.apimodels.agreements.agreementsoutput;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Recipent_ {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("userId")
    @Expose
    private String userId;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("userKey")
    @Expose
    private Object userKey;
    @SerializedName("email")
    @Expose
    private Object email;
    @SerializedName("password")
    @Expose
    private Object password;
    @SerializedName("otp")
    @Expose
    private Object otp;
    @SerializedName("phoneNo")
    @Expose
    private Object phoneNo;
    @SerializedName("role")
    @Expose
    private Object role;
    @SerializedName("picId")
    @Expose
    private Object picId;
    @SerializedName("deviceId")
    @Expose
    private Object deviceId;
    @SerializedName("gLatitude")
    @Expose
    private Object gLatitude;
    @SerializedName("gLongitude")
    @Expose
    private Object gLongitude;
    @SerializedName("country")
    @Expose
    private Object country;
    @SerializedName("prefLanguage")
    @Expose
    private Object prefLanguage;
    @SerializedName("devicePlatform")
    @Expose
    private Object devicePlatform;
    @SerializedName("socialType")
    @Expose
    private Object socialType;
    @SerializedName("socialId")
    @Expose
    private Object socialId;
    @SerializedName("socialImage")
    @Expose
    private Object socialImage;
    @SerializedName("company")
    @Expose
    private Object company;
    @SerializedName("saAg")
    @Expose
    private Object saAg;
    @SerializedName("terms")
    @Expose
    private Object terms;
    @SerializedName("usResident")
    @Expose
    private Object usResident;
    @SerializedName("mobileId")
    @Expose
    private Object mobileId;
    @SerializedName("flagCode")
    @Expose
    private Object flagCode;
    @SerializedName("appIntro")
    @Expose
    private Object appIntro;
    @SerializedName("facebookId")
    @Expose
    private Object facebookId;
    @SerializedName("whatsappFlag")
    @Expose
    private Object whatsappFlag;
    @SerializedName("productList")
    @Expose
    private Object productList;
    @SerializedName("langList")
    @Expose
    private Object langList;
    @SerializedName("mobileLang")
    @Expose
    private Object mobileLang;
    @SerializedName("dataStatus")
    @Expose
    private Object dataStatus;
    @SerializedName("createdBy")
    @Expose
    private Object createdBy;
    @SerializedName("createdOn")
    @Expose
    private Object createdOn;
    @SerializedName("updatedBy")
    @Expose
    private Object updatedBy;
    @SerializedName("updatedOn")
    @Expose
    private Object updatedOn;
    @SerializedName("dob")
    @Expose
    private Object dob;
    @SerializedName("physicalAddress")
    @Expose
    private Object physicalAddress;
    @SerializedName("education")
    @Expose
    private Object education;
    @SerializedName("workExperience")
    @Expose
    private Object workExperience;
    @SerializedName("linkedin")
    @Expose
    private Object linkedin;
    @SerializedName("facebook")
    @Expose
    private Object facebook;
    @SerializedName("twitter")
    @Expose
    private Object twitter;
    @SerializedName("instagram")
    @Expose
    private Object instagram;
    @SerializedName("accessId")
    @Expose
    private Object accessId;
    @SerializedName("type")
    @Expose
    private Object type;
    @SerializedName("lastName")
    @Expose
    private Object lastName;
    @SerializedName("address1")
    @Expose
    private Object address1;
    @SerializedName("address2")
    @Expose
    private Object address2;
    @SerializedName("city")
    @Expose
    private Object city;
    @SerializedName("unit")
    @Expose
    private Object unit;
    @SerializedName("state")
    @Expose
    private Object state;
    @SerializedName("postalCode")
    @Expose
    private Object postalCode;
    @SerializedName("userStatus")
    @Expose
    private Object userStatus;
    @SerializedName("code")
    @Expose
    private Object code;
    @SerializedName("myLeads")
    @Expose
    private Integer myLeads;
    @SerializedName("myConLeads")
    @Expose
    private Integer myConLeads;
    @SerializedName("myProduct")
    @Expose
    private Integer myProduct;
    @SerializedName("mySharedCamp")
    @Expose
    private Integer mySharedCamp;
    @SerializedName("mySales")
    @Expose
    private Integer mySales;
    @SerializedName("whatsappCode")
    @Expose
    private Object whatsappCode;
    @SerializedName("whatsappNumber")
    @Expose
    private Object whatsappNumber;
    @SerializedName("totalSalesAssociate")
    @Expose
    private Integer totalSalesAssociate;
    @SerializedName("totalLeads")
    @Expose
    private Integer totalLeads;
    @SerializedName("totalCustomer")
    @Expose
    private Integer totalCustomer;
    @SerializedName("totalSales")
    @Expose
    private Integer totalSales;
    @SerializedName("totalSASales")
    @Expose
    private Integer totalSASales;
    @SerializedName("bank_details")
    @Expose
    private Object bankDetails;
    @SerializedName("sdec")
    @Expose
    private Integer sdec;
    @SerializedName("totalCompany")
    @Expose
    private Integer totalCompany;
    @SerializedName("totalProduct")
    @Expose
    private Integer totalProduct;
    @SerializedName("totalCampaign")
    @Expose
    private Integer totalCampaign;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Object getUserKey() {
        return userKey;
    }

    public void setUserKey(Object userKey) {
        this.userKey = userKey;
    }

    public Object getEmail() {
        return email;
    }

    public void setEmail(Object email) {
        this.email = email;
    }

    public Object getPassword() {
        return password;
    }

    public void setPassword(Object password) {
        this.password = password;
    }

    public Object getOtp() {
        return otp;
    }

    public void setOtp(Object otp) {
        this.otp = otp;
    }

    public Object getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(Object phoneNo) {
        this.phoneNo = phoneNo;
    }

    public Object getRole() {
        return role;
    }

    public void setRole(Object role) {
        this.role = role;
    }

    public Object getPicId() {
        return picId;
    }

    public void setPicId(Object picId) {
        this.picId = picId;
    }

    public Object getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Object deviceId) {
        this.deviceId = deviceId;
    }

    public Object getGLatitude() {
        return gLatitude;
    }

    public void setGLatitude(Object gLatitude) {
        this.gLatitude = gLatitude;
    }

    public Object getGLongitude() {
        return gLongitude;
    }

    public void setGLongitude(Object gLongitude) {
        this.gLongitude = gLongitude;
    }

    public Object getCountry() {
        return country;
    }

    public void setCountry(Object country) {
        this.country = country;
    }

    public Object getPrefLanguage() {
        return prefLanguage;
    }

    public void setPrefLanguage(Object prefLanguage) {
        this.prefLanguage = prefLanguage;
    }

    public Object getDevicePlatform() {
        return devicePlatform;
    }

    public void setDevicePlatform(Object devicePlatform) {
        this.devicePlatform = devicePlatform;
    }

    public Object getSocialType() {
        return socialType;
    }

    public void setSocialType(Object socialType) {
        this.socialType = socialType;
    }

    public Object getSocialId() {
        return socialId;
    }

    public void setSocialId(Object socialId) {
        this.socialId = socialId;
    }

    public Object getSocialImage() {
        return socialImage;
    }

    public void setSocialImage(Object socialImage) {
        this.socialImage = socialImage;
    }

    public Object getCompany() {
        return company;
    }

    public void setCompany(Object company) {
        this.company = company;
    }

    public Object getSaAg() {
        return saAg;
    }

    public void setSaAg(Object saAg) {
        this.saAg = saAg;
    }

    public Object getTerms() {
        return terms;
    }

    public void setTerms(Object terms) {
        this.terms = terms;
    }

    public Object getUsResident() {
        return usResident;
    }

    public void setUsResident(Object usResident) {
        this.usResident = usResident;
    }

    public Object getMobileId() {
        return mobileId;
    }

    public void setMobileId(Object mobileId) {
        this.mobileId = mobileId;
    }

    public Object getFlagCode() {
        return flagCode;
    }

    public void setFlagCode(Object flagCode) {
        this.flagCode = flagCode;
    }

    public Object getAppIntro() {
        return appIntro;
    }

    public void setAppIntro(Object appIntro) {
        this.appIntro = appIntro;
    }

    public Object getFacebookId() {
        return facebookId;
    }

    public void setFacebookId(Object facebookId) {
        this.facebookId = facebookId;
    }

    public Object getWhatsappFlag() {
        return whatsappFlag;
    }

    public void setWhatsappFlag(Object whatsappFlag) {
        this.whatsappFlag = whatsappFlag;
    }

    public Object getProductList() {
        return productList;
    }

    public void setProductList(Object productList) {
        this.productList = productList;
    }

    public Object getLangList() {
        return langList;
    }

    public void setLangList(Object langList) {
        this.langList = langList;
    }

    public Object getMobileLang() {
        return mobileLang;
    }

    public void setMobileLang(Object mobileLang) {
        this.mobileLang = mobileLang;
    }

    public Object getDataStatus() {
        return dataStatus;
    }

    public void setDataStatus(Object dataStatus) {
        this.dataStatus = dataStatus;
    }

    public Object getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Object createdBy) {
        this.createdBy = createdBy;
    }

    public Object getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Object createdOn) {
        this.createdOn = createdOn;
    }

    public Object getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(Object updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Object getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Object updatedOn) {
        this.updatedOn = updatedOn;
    }

    public Object getDob() {
        return dob;
    }

    public void setDob(Object dob) {
        this.dob = dob;
    }

    public Object getPhysicalAddress() {
        return physicalAddress;
    }

    public void setPhysicalAddress(Object physicalAddress) {
        this.physicalAddress = physicalAddress;
    }

    public Object getEducation() {
        return education;
    }

    public void setEducation(Object education) {
        this.education = education;
    }

    public Object getWorkExperience() {
        return workExperience;
    }

    public void setWorkExperience(Object workExperience) {
        this.workExperience = workExperience;
    }

    public Object getLinkedin() {
        return linkedin;
    }

    public void setLinkedin(Object linkedin) {
        this.linkedin = linkedin;
    }

    public Object getFacebook() {
        return facebook;
    }

    public void setFacebook(Object facebook) {
        this.facebook = facebook;
    }

    public Object getTwitter() {
        return twitter;
    }

    public void setTwitter(Object twitter) {
        this.twitter = twitter;
    }

    public Object getInstagram() {
        return instagram;
    }

    public void setInstagram(Object instagram) {
        this.instagram = instagram;
    }

    public Object getAccessId() {
        return accessId;
    }

    public void setAccessId(Object accessId) {
        this.accessId = accessId;
    }

    public Object getType() {
        return type;
    }

    public void setType(Object type) {
        this.type = type;
    }

    public Object getLastName() {
        return lastName;
    }

    public void setLastName(Object lastName) {
        this.lastName = lastName;
    }

    public Object getAddress1() {
        return address1;
    }

    public void setAddress1(Object address1) {
        this.address1 = address1;
    }

    public Object getAddress2() {
        return address2;
    }

    public void setAddress2(Object address2) {
        this.address2 = address2;
    }

    public Object getCity() {
        return city;
    }

    public void setCity(Object city) {
        this.city = city;
    }

    public Object getUnit() {
        return unit;
    }

    public void setUnit(Object unit) {
        this.unit = unit;
    }

    public Object getState() {
        return state;
    }

    public void setState(Object state) {
        this.state = state;
    }

    public Object getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(Object postalCode) {
        this.postalCode = postalCode;
    }

    public Object getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(Object userStatus) {
        this.userStatus = userStatus;
    }

    public Object getCode() {
        return code;
    }

    public void setCode(Object code) {
        this.code = code;
    }

    public Integer getMyLeads() {
        return myLeads;
    }

    public void setMyLeads(Integer myLeads) {
        this.myLeads = myLeads;
    }

    public Integer getMyConLeads() {
        return myConLeads;
    }

    public void setMyConLeads(Integer myConLeads) {
        this.myConLeads = myConLeads;
    }

    public Integer getMyProduct() {
        return myProduct;
    }

    public void setMyProduct(Integer myProduct) {
        this.myProduct = myProduct;
    }

    public Integer getMySharedCamp() {
        return mySharedCamp;
    }

    public void setMySharedCamp(Integer mySharedCamp) {
        this.mySharedCamp = mySharedCamp;
    }

    public Integer getMySales() {
        return mySales;
    }

    public void setMySales(Integer mySales) {
        this.mySales = mySales;
    }

    public Object getWhatsappCode() {
        return whatsappCode;
    }

    public void setWhatsappCode(Object whatsappCode) {
        this.whatsappCode = whatsappCode;
    }

    public Object getWhatsappNumber() {
        return whatsappNumber;
    }

    public void setWhatsappNumber(Object whatsappNumber) {
        this.whatsappNumber = whatsappNumber;
    }

    public Integer getTotalSalesAssociate() {
        return totalSalesAssociate;
    }

    public void setTotalSalesAssociate(Integer totalSalesAssociate) {
        this.totalSalesAssociate = totalSalesAssociate;
    }

    public Integer getTotalLeads() {
        return totalLeads;
    }

    public void setTotalLeads(Integer totalLeads) {
        this.totalLeads = totalLeads;
    }

    public Integer getTotalCustomer() {
        return totalCustomer;
    }

    public void setTotalCustomer(Integer totalCustomer) {
        this.totalCustomer = totalCustomer;
    }

    public Integer getTotalSales() {
        return totalSales;
    }

    public void setTotalSales(Integer totalSales) {
        this.totalSales = totalSales;
    }

    public Integer getTotalSASales() {
        return totalSASales;
    }

    public void setTotalSASales(Integer totalSASales) {
        this.totalSASales = totalSASales;
    }

    public Object getBankDetails() {
        return bankDetails;
    }

    public void setBankDetails(Object bankDetails) {
        this.bankDetails = bankDetails;
    }

    public Integer getSdec() {
        return sdec;
    }

    public void setSdec(Integer sdec) {
        this.sdec = sdec;
    }

    public Integer getTotalCompany() {
        return totalCompany;
    }

    public void setTotalCompany(Integer totalCompany) {
        this.totalCompany = totalCompany;
    }

    public Integer getTotalProduct() {
        return totalProduct;
    }

    public void setTotalProduct(Integer totalProduct) {
        this.totalProduct = totalProduct;
    }

    public Integer getTotalCampaign() {
        return totalCampaign;
    }

    public void setTotalCampaign(Integer totalCampaign) {
        this.totalCampaign = totalCampaign;
    }

}
