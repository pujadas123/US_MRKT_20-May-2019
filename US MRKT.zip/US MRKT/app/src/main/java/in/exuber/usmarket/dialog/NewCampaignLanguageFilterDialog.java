package in.exuber.usmarket.dialog;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

import in.exuber.usmarket.R;
import in.exuber.usmarket.adapter.dialog.NewCampaignLanguageFilterListAdapter;
import in.exuber.usmarket.apimodels.login.loginoutput.MobileLang;
import in.exuber.usmarket.fragment.campaign.CampaignNewFragment;

import static in.exuber.usmarket.utils.UtilMethods.getLanguageLabelPreference;


@SuppressLint("ValidFragment")
public class NewCampaignLanguageFilterDialog extends DialogFragment implements View.OnClickListener {

	//Declaring views
	private RecyclerView filterList;
	private ImageView closeClick;

	//Decalring variables
	private int selectedPosition;
	private ArrayList<String> filterDataList;
	private CampaignNewFragment campaignNewFragment;

	String All="ALL";

	//Adapter
	private NewCampaignLanguageFilterListAdapter newCampaignLanguageFilterListAdapter;

	public NewCampaignLanguageFilterDialog(int selectedPosition, CampaignNewFragment campaignNewFragment) {

		this.selectedPosition = selectedPosition;
		this.campaignNewFragment = campaignNewFragment;
	}

	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {

		//Creating Dialog
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

		//Inflating view
		LayoutInflater inflater = getActivity().getLayoutInflater();
		View filterDialog = inflater.inflate(R.layout.dialog_newcampaign_languagefilter, null);

		//Initialising variables
		filterDataList = new ArrayList<>();

		//Initialising views
		closeClick = filterDialog.findViewById(R.id.iv_newCampaign_languageFilterDialog_closeClick);

		//Recyclerview
		filterList = filterDialog.findViewById(R.id.rv_newCampaign_languageFilterDialog_filterList);
		filterList.setHasFixedSize(true);
		LinearLayoutManager linearLayoutManagerNotification = new LinearLayoutManager(getActivity());
		linearLayoutManagerNotification.setOrientation(LinearLayoutManager.VERTICAL);
		filterList.setLayoutManager(linearLayoutManagerNotification);

		//Setting values
		setAdapterData();

		//Setting adapter
		newCampaignLanguageFilterListAdapter = new NewCampaignLanguageFilterListAdapter(getActivity(),filterDataList,selectedPosition,NewCampaignLanguageFilterDialog.this);
		filterList.setAdapter(newCampaignLanguageFilterListAdapter);
		newCampaignLanguageFilterListAdapter.notifyDataSetChanged();


		//Setting onclick
		closeClick.setOnClickListener(this);


		builder.setView(filterDialog);
		return builder.create();
	}

	public void onResume()
	{
		super.onResume();
		Window window = getDialog().getWindow();
		ViewGroup.LayoutParams params = window.getAttributes();
		window.setLayout((int) (getWindowSize(getActivity()).x * 0.70), ViewGroup.LayoutParams.WRAP_CONTENT);
		window.setGravity(Gravity.CENTER);

	}

	public Point getWindowSize(Context context) {
		WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
		Display display = windowManager.getDefaultDisplay();
		Point size = new Point();
		display.getSize(size);
		return size;
	}



	@Override
	public void onClick(View v) {

		switch (v.getId())
		{
			case R.id.iv_newCampaign_languageFilterDialog_closeClick:

				//Dismissing dialog
				dismissDialog();

				break;
		}

	}

	//Func - Dismiss dialog
	public void dismissDialog() {
		dismiss();
	}

	//Func - Set Adapterdata
	public void setAdapterData()
	{

		List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
		for (int index = 0; index<languageLabelModelList.size();index++) {
			if (languageLabelModelList.get(index).getLangCode().equals("1436")) {
				All=languageLabelModelList.get(index).getValue();
			}
		}

		filterDataList.add(All);
		filterDataList.add("English");
		filterDataList.add("Español");


	}

    //Func - Set Adapterdata
    public void setSelectedData(int clickPosition) {

		campaignNewFragment.setLanguage(clickPosition);

        dismissDialog();

    }
}
