package in.exuber.usmarket.models.leads;

import java.util.ArrayList;

public class LeadsContactOutput {

    private String contact;
    private String contactSource;


    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getContactSource() {
        return contactSource;
    }

    public void setContactSource(String contactSource) {
        this.contactSource = contactSource;
    }
}
