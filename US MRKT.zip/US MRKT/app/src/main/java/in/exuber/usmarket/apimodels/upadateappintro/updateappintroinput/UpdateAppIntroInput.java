
package in.exuber.usmarket.apimodels.upadateappintro.updateappintroinput;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class UpdateAppIntroInput {

    @SerializedName("userId")
    @Expose
    private String userId;
    @SerializedName("appIntro")
    @Expose
    private String appIntro;

    /**
     * No args constructor for use in serialization
     * 
     */
    public UpdateAppIntroInput() {
    }

    /**
     * 
     * @param appIntro
     * @param userId
     */
    public UpdateAppIntroInput(String userId, String appIntro) {
        super();
        this.userId = userId;
        this.appIntro = appIntro;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAppIntro() {
        return appIntro;
    }

    public void setAppIntro(String appIntro) {
        this.appIntro = appIntro;
    }

}
