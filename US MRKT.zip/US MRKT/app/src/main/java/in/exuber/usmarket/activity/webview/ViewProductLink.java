package in.exuber.usmarket.activity.webview;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.google.gson.Gson;

import in.exuber.usmarket.R;
import in.exuber.usmarket.apimodels.product.productoutput.ProductOutput;
import in.exuber.usmarket.apimodels.productuser.productuseroutput.ProductUserOutput;
import in.exuber.usmarket.utils.Constants;

public class ViewProductLink extends AppCompatActivity {

    // Declare Variables
    WebView webview;
    private TextView toolbarHeader;

    private boolean isUserProductPassed;
    private String ViewLink, productID, userID, typeID, linkID;

    private ProductUserOutput productUserOutput;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_PROGRESS);

        setContentView(R.layout.viewproductlinkwebview);


        //Setting Toolbar
        Toolbar toolbar = findViewById(R.id.main_toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_back_primary);

        toolbarHeader = findViewById(R.id.tv_main_toolBar_headerText);



        webview = (WebView) findViewById(R.id.webview);

        webview.getSettings().setJavaScriptEnabled(true);

        webview.getSettings().setBuiltInZoomControls(true);

        webview.getSettings().setLoadWithOverviewMode(true);
        webview.getSettings().setUseWideViewPort(true);


        Bundle passedBundle = getIntent().getExtras();
        ViewLink = passedBundle.getString("viewLinkLayout");
        productID=passedBundle.getString("viewLinkProductId");
        userID=passedBundle.getString("viewLinkUserId");
        typeID=passedBundle.getString("viewLinkTypeId");
        linkID=passedBundle.getString("viewLinkLinkId");

        if (ViewLink.equals("LinkOne")){

            // Load URL
            webview.loadUrl("https://app.usmrkt.com/resources/uitemplates/campimage.jsp?cid=" + productID + "&sa=" + userID +"&type=" + typeID + "&link=" + linkID);

            Log.e("LO","One");
            Log.e("LUO",productID);
            Log.e("user",userID);
            Log.e("type",typeID);
            Log.e("Link",linkID);
        }
        if (ViewLink.equals("LinkTwo")){

            // Load URL
            webview.loadUrl("https://app.usmrkt.com/resources/uitemplates/campimage.jsp?cid=" + productID + "&sa=" + userID +"&type=" + typeID + "&link=" + linkID);

            Log.e("LT","Two");
            Log.e("LUO",productID);
            Log.e("user",userID);
            Log.e("type",typeID);
            Log.e("Link",linkID);

        }
        if (ViewLink.equals("LinkThree")){

            // Load URL
            webview.loadUrl("https://app.usmrkt.com/resources/uitemplates/campimage.jsp?cid=" + productID + "&sa=" + userID +"&type=" + typeID + "&link=" + linkID);

            Log.e("LTh","Three");
            Log.e("LUO",productID);
            Log.e("user",userID);
            Log.e("type",typeID);
            Log.e("Link",linkID);

        }
        if (ViewLink.equals("LinkFour")){

            // Load URL
            webview.loadUrl("https://app.usmrkt.com/resources/uitemplates/campimage.jsp?cid=" + productID + "&sa=" + userID +"&type=" + typeID + "&link=" + linkID);

            Log.e("LF","Four");
            Log.e("LUO",productID);
            Log.e("user",userID);
            Log.e("type",typeID);
            Log.e("Link",linkID);

        }
        if (ViewLink.equals("LinkFive")){

            // Load URL
            webview.loadUrl("https://app.usmrkt.com/resources/uitemplates/campimage.jsp?cid=" + productID + "&sa=" + userID +"&type=" + typeID + "&link=" + linkID);

            Log.e("LFi","Five");
            Log.e("LUO",productID);
            Log.e("user",userID);
            Log.e("type",typeID);
            Log.e("Link",linkID);

        }
        if (ViewLink.equals("CampaignOne")){

            // Load URL
            webview.loadUrl("https://app.usmrkt.com/resources/uitemplates/campimage.jsp?cid=" + productID + "&sa=" + userID +"&type=" + typeID + "&link=" + linkID);

            Log.e("camO","Five");
            Log.e("CamLUO",productID);
            Log.e("Camuser",userID);
            Log.e("Camtype",typeID);
            Log.e("CamLink",linkID);

        }

        /*// Load URL
        webview.loadUrl("https://app.usmrkt.com");*/

        // Show the progress bar
        webview.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView view, int progress) {
                setProgress(progress * 100);
            }
        });

        webview.setWebViewClient(new InsideWebViewClient());

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_dummy, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                finish();
                break;

        }
        return (super.onOptionsItemSelected(menuItem));
    }


    private class InsideWebViewClient extends WebViewClient {
        @Override
        // Force links to be opened inside WebView and not in Default Browser
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;

        }

    }

    @Override
    public void onBackPressed() {
        if (webview.canGoBack()) {
            webview.goBack();
        } else if (!getFragmentManager().popBackStackImmediate()) {
            super.onBackPressed();
        }
    }
}
