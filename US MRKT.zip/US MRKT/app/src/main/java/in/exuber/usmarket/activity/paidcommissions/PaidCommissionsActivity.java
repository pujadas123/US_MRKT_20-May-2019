package in.exuber.usmarket.activity.paidcommissions;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import in.exuber.usmarket.R;
import in.exuber.usmarket.activity.homeaddproducts.HomeAddProductsActivity;
import in.exuber.usmarket.activity.paidcommissionsfilter.PaidCommissionsFilterActivity;
import in.exuber.usmarket.adapter.PaidCommissionListAdapter;
import in.exuber.usmarket.apimodels.login.loginoutput.MobileLang;
import in.exuber.usmarket.apimodels.paidcommision.PaidCommissionOutput;
import in.exuber.usmarket.utils.Api;
import in.exuber.usmarket.utils.Config;
import in.exuber.usmarket.utils.ConnectionDetector;
import in.exuber.usmarket.utils.Constants;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static in.exuber.usmarket.utils.UtilMethods.getLanguageLabelPreference;
import static in.exuber.usmarket.utils.UtilMethods.hideKeyBoard;

public class PaidCommissionsActivity extends AppCompatActivity implements View.OnClickListener {

    private LinearLayout paidCommissionsActivityContainer;

    private TextView toolbarHeader;

    private NestedScrollView paidCommissionLayout;

    private RelativeLayout searchLayout;
    private TextView filterClick;
    private SearchView searchView;

    private TextView currentDateText, totalCommissionText;
    private LinearLayout dataLayout;
    private RecyclerView paidCommissionList;


    private LinearLayout progressDialog;
    private LinearLayout errorDisplay;
    private LinearLayout errorDisplayPaidCommissions;

    private ImageView errorDisplayIcon;
    private TextView errorDisplayText;
    private TextView errorDisplayTryClick;

    private ImageView errorDisplayIconPaidCommissions;
    private TextView errorDisplayTextPaidCommissions;
    private TextView errorDisplayTryClickPaidCommissions,asofText,totalText,productNameText,commissionText,progressPleaseWait;

    //Connection detector class
    private ConnectionDetector connectionDetector;

    //Sharedpreferences
    private SharedPreferences marketPreference;

    //Declaring Retrofit log
    private static OkHttpClient.Builder builder;


    //Adapter
    private PaidCommissionListAdapter paidCommissionListAdapter;


    private List<PaidCommissionOutput> paidCommissionOutputList;

    private static final int GET_FILTER_REQUEST_CODE = 1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paid_commissions);

        //Hiding keyboard
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        //Initialising shared preferences
        marketPreference = getSharedPreferences(Constants.PREFERENCE_NAME,MODE_PRIVATE);

        //Initialising connection detector
        connectionDetector = new ConnectionDetector(this);

        //Setting Toolbar
        Toolbar toolbar = findViewById(R.id.main_toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_back_primary);


        //Initialising variables
        paidCommissionOutputList = new ArrayList<>();

        //Initialising variables
        paidCommissionsActivityContainer = findViewById(R.id.activity_paid_commissions);

        paidCommissionLayout = findViewById(R.id.nsv_paidCommissions_commissionLayout);
        searchLayout=findViewById(R.id.rl_paidCommissions_searchLayout);

        toolbarHeader = findViewById(R.id.tv_main_toolBar_headerText);

        progressDialog =  findViewById(R.id.ll_custom_dialog);
        errorDisplay =  findViewById(R.id.ll_errorMain_layout);
        errorDisplayPaidCommissions =  findViewById(R.id.ll_errorPaidCommissions_layout);


        errorDisplayIcon = findViewById(R.id.iv_errorMain_errorIcon);
        errorDisplayText =  findViewById(R.id.tv_errorMain_errorText);
        errorDisplayTryClick =  findViewById(R.id.tv_errorMain_errorTryAgain);

        errorDisplayIconPaidCommissions = findViewById(R.id.iv_errorPaidCommissions_errorIcon);
        errorDisplayTextPaidCommissions =  findViewById(R.id.tv_errorPaidCommissions_errorText);
        errorDisplayTryClickPaidCommissions=findViewById(R.id.tv_errorMain_errorTryAgain);


        currentDateText = findViewById(R.id.tv_paidCommissions_currentDate);
        totalCommissionText = findViewById(R.id.tv_paidCommissions_totalCommission);
        progressPleaseWait=findViewById(R.id.txt_pleaseWait);

        searchView = findViewById(R.id.et_paidCommissions_search);
        filterClick = findViewById(R.id.tv_paidCommissions_filterClick);

        dataLayout = findViewById(R.id.ll_paidCommissions_dataLayout);

        asofText=findViewById(R.id.txt_asofText);
        totalText=findViewById(R.id.txt_totalText);
        productNameText=findViewById(R.id.tv_paidCommissionListAdapter_productName);
        commissionText=findViewById(R.id.tv_paidCommissionListAdapter_commission);

        paidCommissionList = findViewById(R.id.rv_paidCommissions_paidCommissionsList);
        paidCommissionList.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManagerPaidCommission = new LinearLayoutManager(this);
        linearLayoutManagerPaidCommission.setOrientation(LinearLayoutManager.VERTICAL);
        paidCommissionList.setLayoutManager(linearLayoutManagerPaidCommission);


        //Setting Current date
        long date = System.currentTimeMillis();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMM dd, yyyy");
        String dateString = simpleDateFormat.format(date);
        currentDateText.setText(dateString);

        //Setting toolbar header
        //toolbarHeader.setText(getResources().getString(R.string.paid_commissions_caps));



        //Get Paid Commissions
        getPaidCommissions();


        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String product) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {

                if (paidCommissionListAdapter !=  null) {
                    paidCommissionListAdapter.getFilter().filter(query);
                }

                return false;
            }
        });


        //setting onclick
        errorDisplayTryClick.setOnClickListener(this);
        filterClick.setOnClickListener(this);

        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(PaidCommissionsActivity.this);

        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1197")) {
                toolbarHeader.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1198")) {
                asofText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1199")) {
                totalText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1132")) {
                searchView.setQueryHint(languageLabelModelList.get(index).getValue()+"...");
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1201")) {
                productNameText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1202")) {
                commissionText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1437")) {
                filterClick.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1143")) {
                progressPleaseWait.setText(languageLabelModelList.get(index).getValue());
            }
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_dummy, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                finish();
                break;

        }
        return (super.onOptionsItemSelected(menuItem));
    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.tv_paidCommissions_filterClick:

                //Hiding Keyboard
                hideKeyBoard(PaidCommissionsActivity.this);

                Intent filterIntent = new Intent(PaidCommissionsActivity.this, PaidCommissionsFilterActivity.class);
                startActivityForResult(filterIntent,GET_FILTER_REQUEST_CODE);


                break;

            case R.id.tv_errorMain_errorTryAgain:

                //Hiding Keyboard
                hideKeyBoard(PaidCommissionsActivity.this);

                //Get Paid Commissions
                getPaidCommissions();

                break;

        }
    }

    //Func - Get Paid Commissions
    private void getPaidCommissions() {

        boolean isInternetPresent = connectionDetector.isConnectingToInternet();

        if (isInternetPresent) {


            errorDisplay.setVisibility(View.GONE);
            errorDisplayPaidCommissions.setVisibility(View.GONE);
            paidCommissionLayout.setVisibility(View.GONE);

            progressDialog.setVisibility(View.VISIBLE);

            //Calling Service
            callGetPaidCommissionsService();

        }
        else
        {
            //Hiding views
            progressDialog.setVisibility(View.GONE);
            paidCommissionLayout.setVisibility(View.GONE);
            errorDisplayPaidCommissions.setVisibility(View.GONE);

            errorDisplay.setVisibility(View.VISIBLE);

            errorDisplayIcon.setImageResource(R.drawable.ic_error_internet);
            List<MobileLang> languageLabelModelList = getLanguageLabelPreference(PaidCommissionsActivity.this);
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1340")) {
                    errorDisplayText.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //errorDisplayText.setText(getString(R.string.error_internet));
        }
    }

    //Func - Get Paid Commissions
    private void callGetPaidCommissionsService() {

        String accessTokenId = marketPreference.getString(Constants.LOGIN_ACCESSTOKEN_ID, null);
        final String userId = marketPreference.getString(Constants.LOGIN_USER_ID, null);
        String roleId = marketPreference.getString(Constants.LOGIN_ROLE_ID, null);

        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Config.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        final Api api = retrofit.create(Api.class);

        Call<List<PaidCommissionOutput>> call = (Call<List<PaidCommissionOutput>>) api.getPaidCommissions(accessTokenId,
                userId,
                roleId,
                Constants.SERVICE_GET_PAID_COMMISSIONS,
                userId);
        call.enqueue(new Callback<List<PaidCommissionOutput>>() {
            @Override
            public void onResponse(Call<List<PaidCommissionOutput>> call, Response<List<PaidCommissionOutput>> response) {

                //Checking for response code
                if (response.code() == 200 ) {

                    paidCommissionOutputList = response.body();


                    if (paidCommissionOutputList.size() == 0)
                    {


                        progressDialog.setVisibility(View.GONE);
                        errorDisplay.setVisibility(View.GONE);

                        paidCommissionLayout.setVisibility(View.VISIBLE);
                        searchLayout.setVisibility(View.GONE);
                        dataLayout.setVisibility(View.GONE);

                        errorDisplayPaidCommissions.setVisibility(View.VISIBLE);

                        errorDisplayIconPaidCommissions.setImageResource(R.drawable.ic_error_paid_commissions);

                        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(PaidCommissionsActivity.this);
                        for (int index = 0; index<languageLabelModelList.size();index++) {
                            if (languageLabelModelList.get(index).getLangCode().equals("1383")) {
                                errorDisplayTextPaidCommissions.setText(languageLabelModelList.get(index).getValue());
                            }
                        }
                        //errorDisplayTextPaidCommissions.setText(getString(R.string.error_no_data_paid_commissions));

                        totalCommissionText.setText("$ 0.00");

                    }
                    else {

                        //Hiding views
                        progressDialog.setVisibility(View.GONE);
                        errorDisplay.setVisibility(View.GONE);
                        errorDisplayPaidCommissions.setVisibility(View.GONE);

                        paidCommissionLayout.setVisibility(View.VISIBLE);
                        dataLayout.setVisibility(View.VISIBLE);

                        Log.e("Total Amount",""+paidCommissionOutputList.get(0).getTotalAmount());

                        DecimalFormat formatter = new DecimalFormat("$#,###,###.00");
                        totalCommissionText.setText(formatter.format(paidCommissionOutputList.get(0).getTotalAmount()));



                        paidCommissionListAdapter = new PaidCommissionListAdapter(PaidCommissionsActivity.this, paidCommissionOutputList);
                        paidCommissionList.setAdapter(paidCommissionListAdapter);
                        paidCommissionListAdapter.notifyDataSetChanged();



                    }


                }
                //If status code is not 200
                else
                {


                    progressDialog.setVisibility(View.GONE);
                    paidCommissionLayout.setVisibility(View.GONE);
                    errorDisplayPaidCommissions.setVisibility(View.GONE);


                    errorDisplay.setVisibility(View.VISIBLE);

                    errorDisplayIcon.setImageResource(R.drawable.ic_error_code);
                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(PaidCommissionsActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1341")) {
                            errorDisplayText.setText(languageLabelModelList.get(index).getValue() + ":" + response.code());
                        }
                    }
                    //errorDisplayText.setText(getString(R.string.error_response_code) + response.code());

                }
            }

            @Override
            public void onFailure(Call<List<PaidCommissionOutput>> call, Throwable t) {

                Log.e("Failure",t.toString());

                if (t instanceof IOException) {



                    progressDialog.setVisibility(View.GONE);
                    errorDisplay.setVisibility(View.GONE);

                    paidCommissionLayout.setVisibility(View.VISIBLE);
                    searchLayout.setVisibility(View.GONE);
                    dataLayout.setVisibility(View.GONE);

                    errorDisplayPaidCommissions.setVisibility(View.VISIBLE);

                    errorDisplayIconPaidCommissions.setImageResource(R.drawable.ic_error_paid_commissions);

                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(PaidCommissionsActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1383")) {
                            errorDisplayTextPaidCommissions.setText(languageLabelModelList.get(index).getValue());
                        }
                    }
                    //errorDisplayTextPaidCommissions.setText(getString(R.string.error_no_data_paid_commissions));

                    totalCommissionText.setText("$ 0.00");




                }
                else
                {
                    //Hiding views
                    progressDialog.setVisibility(View.GONE);
                    paidCommissionLayout.setVisibility(View.GONE);
                    errorDisplayPaidCommissions.setVisibility(View.GONE);


                    errorDisplay.setVisibility(View.VISIBLE);

                    errorDisplayIcon.setImageResource(R.drawable.ic_error_server);
                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(PaidCommissionsActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1342")) {
                            errorDisplayText.setText(languageLabelModelList.get(index).getValue());
                        }
                    }
                    //errorDisplayText.setText(getString(R.string.error_server));


                }





            }

        });
    }

    //Retrofit log
    public OkHttpClient.Builder getHttpClient() {

        if (builder == null) {
            HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            OkHttpClient.Builder client = new OkHttpClient.Builder();
            client.addInterceptor(loggingInterceptor);
            client.writeTimeout(60000, TimeUnit.MILLISECONDS);
            client.readTimeout(60000, TimeUnit.MILLISECONDS);
            client.connectTimeout(60000, TimeUnit.MILLISECONDS);
            return client;
        }
        return builder;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == Activity.RESULT_OK){

            if (requestCode == GET_FILTER_REQUEST_CODE)
            {

            }

        }
    }
}
