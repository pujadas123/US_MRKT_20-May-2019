package in.exuber.usmarket.activity.leadsedit;

import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.rilixtech.CountryCodePicker;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import in.exuber.usmarket.R;
import in.exuber.usmarket.activity.activeleadsdetails.LeadsDetailActivity;
import in.exuber.usmarket.activity.homeaddproducts.HomeAddProductsActivity;
import in.exuber.usmarket.activity.leadsadd.LeadsAddActivity;
import in.exuber.usmarket.adapter.ProductHomeListAdapter;
import in.exuber.usmarket.apimodels.allleads.allleadsoutput.AllLeadsOutput;
import in.exuber.usmarket.apimodels.editlead.editleadinput.AssignedTo;
import in.exuber.usmarket.apimodels.editlead.editleadinput.Category;
import in.exuber.usmarket.apimodels.editlead.editleadinput.CategoryList;
import in.exuber.usmarket.apimodels.editlead.editleadinput.CreatedBy;
import in.exuber.usmarket.apimodels.editlead.editleadinput.EditLeadInput;
import in.exuber.usmarket.apimodels.editlead.editleadinput.LeadOwner;
import in.exuber.usmarket.apimodels.editlead.editleadinput.LeadSource;
import in.exuber.usmarket.apimodels.editlead.editleadinput.Product;
import in.exuber.usmarket.apimodels.editlead.editleadinput.ProductList;
import in.exuber.usmarket.apimodels.editlead.editleadinput.SocialNetwork;
import in.exuber.usmarket.apimodels.editlead.editleadinput.Source;
import in.exuber.usmarket.apimodels.editlead.editleadinput.UpdatedBy;
import in.exuber.usmarket.apimodels.editlead.editleadinput.UserId;
import in.exuber.usmarket.apimodels.login.loginoutput.LoginOutput;
import in.exuber.usmarket.apimodels.login.loginoutput.MobileLang;
import in.exuber.usmarket.apimodels.productuser.productuseroutput.ProductUserOutput;
import in.exuber.usmarket.dialog.EditLeadsLeadSourceFilterDialog;
import in.exuber.usmarket.dialog.EditLeadsSocialNetworkFilterDialog;
import in.exuber.usmarket.models.categorylist.CategoryListOutput;
import in.exuber.usmarket.utils.Api;
import in.exuber.usmarket.utils.Config;
import in.exuber.usmarket.utils.ConnectionDetector;
import in.exuber.usmarket.utils.Constants;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static in.exuber.usmarket.utils.UtilMethods.getLanguageLabelPreference;
import static in.exuber.usmarket.utils.UtilMethods.hideKeyBoard;
import static in.exuber.usmarket.utils.UtilMethods.isValidEmail;

public class LeadsEditActivity extends AppCompatActivity implements View.OnClickListener {

    //Declaring views
    private LinearLayout leadsEditActivityContainer;
    private TextView toolbarHeader, toolbarHeaderDone;

    LinearLayout ll_toolbarHeaderDone;


    private EditText firstName, lastName, otherDetails, referralName;
    private TextView firstNameError, lastNameError, leadSourceError, otherDetailsError, referralError, socialnetworkError, interestError, categoriesError, phoneNumberError, emailError;
    private LinearLayout otherDetailsLayout, referralLayout, socialnetworkLayout;

    private LinearLayout leadSourceClick, socialnetworkClick;
    private TextView leadSource, socialNetwork;

    private EditText contactFacebook, contactInstagram, contactTwitter,contactWebsite, contactEmail, contactPhone;
    private CountryCodePicker phoneCodePicker;

    TextView txt_firstName,txt_lastName,txt_leadSource,txt_otherDetails,txt_referralName,txt_socialNetworkName,txt_contactInfo,
            txt_twitter,txt_website,txt_Email,txt_phone,txt_Interests,txt_categories,txt_products;
    String noInternet="No Internet Connection";
    String ServerError="Can't connect Server! Error";
    String SomethingWrong="Something went wrong!";

    //Sharedpreferences
    private SharedPreferences marketPreference;

    //Connection detector class
    private ConnectionDetector connectionDetector;

    //Progress dialog
    private ProgressDialog progressDialog;

    //Declaring Retrofit log
    private static OkHttpClient.Builder builder;

    //Declaring variables
    private AllLeadsOutput allLeadsOutput;
    private int selectedLeadSourcePosition = -1;

    private int selectedSocialNetworkPosition = -1;


    private MultiAutoCompleteTextView interests, categories;
    //private String[] catogoryInputList = {"Investment", "Real Estate"};

    //Declaring variables
    private List<ProductUserOutput> productOutputList;
    ArrayList<String> productNameList=new ArrayList<>();
    ArrayList<String> productIdList=new ArrayList<>();

    ArrayList<String>SelecetedPName=new ArrayList<>();
    ArrayList<String>SelecetedPId=new ArrayList<>();


    private List<CategoryListOutput> categoryOutputList;
    ArrayList<String> categoryNameList=new ArrayList<>();
    ArrayList<String> categoryIdList=new ArrayList<>();

    ArrayList<String>SelecetedCategoryName=new ArrayList<>();
    ArrayList<String>SelecetedCategoryId=new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leads_edit);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        //Initialising shared preferences
        marketPreference =  getSharedPreferences(Constants.PREFERENCE_NAME,MODE_PRIVATE);


        //Initialising connection detector
        connectionDetector = new ConnectionDetector(this);

        //Initialising variables
        productOutputList = new ArrayList<>();
        categoryOutputList = new ArrayList<>();

        //Initialising progress dialog
        progressDialog = new ProgressDialog(this);
        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(LeadsEditActivity.this);

        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1143")) {
                progressDialog.setMessage(languageLabelModelList.get(index).getValue()+"...");
            }
        }
        //progressDialog.setMessage(getString(R.string.loader_caption));
        progressDialog.setCancelable(true);
        progressDialog.setIndeterminate(false);
        progressDialog.setCancelable(false);

        //Setting Toolbar
        Toolbar toolbar = findViewById(R.id.main_toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_back_primary);


        //Initialising views
        leadsEditActivityContainer = findViewById(R.id.activity_leads_edit);
        toolbarHeader = findViewById(R.id.tv_main_toolBar_headerText);

        ll_toolbarHeaderDone=findViewById(R.id.ll_main_toolBar_actionClick);
        toolbarHeaderDone=findViewById(R.id.iv_main_toolBar_actionText);
        ll_toolbarHeaderDone.setOnClickListener(this);


        firstName = findViewById(R.id.et_editLeads_firstName);
        lastName =findViewById(R.id.et_editLeads_lastName);
        otherDetails = findViewById(R.id.et_editLeads_otherDetails);
        referralName = findViewById(R.id.et_addLeads_referralName);
        interests = findViewById(R.id.et_editLeads_interests);
        categories = findViewById(R.id.et_editLeads_categories);

        otherDetailsLayout = findViewById(R.id.ll_editLeads_otherDetailsLayout);
        referralLayout=findViewById(R.id.ll_editLeads_ReferralLayout);
        socialnetworkLayout=findViewById(R.id.ll_editLeads_socialnetworkLayout);

        firstNameError = findViewById(R.id.tv_editLeads_firstNameError);
        lastNameError = findViewById(R.id.tv_editLeads_lastNameError);
        leadSourceError = findViewById(R.id.tv_editLeads_leadSourceError);
        otherDetailsError = findViewById(R.id.tv_editLeads_otherDetailsError);
        referralError=findViewById(R.id.tv_editLeads_ReferralNameError);
        interestError = findViewById(R.id.tv_editLeads_interestsError);
        socialnetworkError = findViewById(R.id.tv_editLeads_socialnetworkNameError);
        categoriesError = findViewById(R.id.tv_editLeads_categoriesError);
        phoneNumberError = findViewById(R.id.tv_editLeads_phoneNumberError);
        emailError = findViewById(R.id.tv_editLeads_emailError);

        leadSourceClick = findViewById(R.id.ll_editLeads_leadSourceClick);
        leadSource = findViewById(R.id.tv_editLeads_leadSource);
        socialnetworkClick=findViewById(R.id.ll_editLeads_socialnetworkClick);
        socialNetwork=findViewById(R.id.tv_editLeads_socialnetworkName);

        contactFacebook = findViewById(R.id.et_editLeads_facebook);
        contactInstagram = findViewById(R.id.et_editLeads_instagram);
        contactTwitter = findViewById(R.id.et_editLeads_twitter);
        contactWebsite=findViewById(R.id.et_editLeads_website);
        contactEmail = findViewById(R.id.et_editLeads_email);
        contactPhone = findViewById(R.id.et_editLeads_phoneNumber);

        phoneCodePicker = findViewById(R.id.cpp_editLeads_phoneNumberPicker);

        txt_firstName=findViewById(R.id.txt_editLeads_firstName);
        txt_lastName=findViewById(R.id.txt_editLeads_lastName);
        txt_leadSource=findViewById(R.id.txt_editLeads_leadSource);
        txt_otherDetails=findViewById(R.id.txt_editLeads_otherDetails);
        txt_referralName=findViewById(R.id.txt_editLeads_referralName);
        txt_socialNetworkName=findViewById(R.id.txt_editLeads_socialNetworkName);
        txt_contactInfo=findViewById(R.id.txt_editLeads_contactInfo);
        txt_twitter=findViewById(R.id.txt_editLeads_twitter);
        txt_website=findViewById(R.id.txt_editLeads_website);
        txt_Email=findViewById(R.id.txt_editLeads_Email);
        txt_phone=findViewById(R.id.txt_editLeads_phone);
        txt_Interests=findViewById(R.id.txt_editLeads_Interests);
        txt_categories=findViewById(R.id.txt_editLeads_categories);
        txt_products=findViewById(R.id.txt_editLeads_products);


        //Hiding views
        otherDetailsLayout.setVisibility(View.GONE);
        firstNameError.setVisibility(View.GONE);
        lastNameError.setVisibility(View.GONE);
        leadSourceError.setVisibility(View.GONE);
        otherDetailsLayout.setVisibility(View.GONE);
        referralLayout.setVisibility(View.GONE);
        socialnetworkError.setVisibility(View.GONE);
        socialnetworkLayout.setVisibility(View.GONE);
        interestError.setVisibility(View.GONE);
        categoriesError.setVisibility(View.GONE);
        phoneNumberError.setVisibility(View.GONE);
        emailError.setVisibility(View.GONE);


        //Registering validation
        phoneCodePicker.registerPhoneNumberTextView(contactPhone);


        //Calling Service
        callGetProductService();
        callGetCategoryService();

        //Getting passed data
        Bundle passedBundle = getIntent().getExtras();
        String leadItemString = passedBundle.getString(Constants.INTENT_KEY_SELECTED_LEAD);


        //Converting string to Object
        Gson gson = new Gson();
        allLeadsOutput = gson.fromJson(leadItemString, AllLeadsOutput.class);

        //Setting toolbar header
        //toolbarHeader.setText(getResources().getString(R.string.edit_lead_caps));
        //toolbarHeaderDone.setText(getResources().getString(R.string.done));

        //Setting values
        firstName.setText(allLeadsOutput.getName());
        lastName.setText(allLeadsOutput.getLastName());

        //Set LeadSource
        if (allLeadsOutput.getLeadSource() != null)
        {
            String selectedLeadSourceId = allLeadsOutput.getLeadSource().getId();

            if (selectedLeadSourceId.equals(Constants.LEADSOURCE_SOCIAL_NETWORK_ID))
            {
                selectedLeadSourcePosition = 0;
                leadSource.setText(allLeadsOutput.getLeadSource().getName());
                socialnetworkLayout.setVisibility(View.VISIBLE);
            }

            if (selectedLeadSourceId.equals(Constants.LEADSOURCE_WEBSITE_ID))
            {
                selectedLeadSourcePosition = 1;
                leadSource.setText(allLeadsOutput.getLeadSource().getName());
                socialnetworkLayout.setVisibility(View.GONE);
            }

            if (selectedLeadSourceId.equals(Constants.LEADSOURCE_EMAIL_ID))
            {
                selectedLeadSourcePosition = 2;
                leadSource.setText(allLeadsOutput.getLeadSource().getName());
                socialnetworkLayout.setVisibility(View.GONE);
            }

            if (selectedLeadSourceId.equals(Constants.LEADSOURCE_PHONE_ID))
            {
                selectedLeadSourcePosition = 3;
                leadSource.setText(allLeadsOutput.getLeadSource().getName());
                socialnetworkLayout.setVisibility(View.GONE);
            }

            if (selectedLeadSourceId.equals(Constants.LEADSOURCE_REFEREL_ID))
            {
                selectedLeadSourcePosition = 4;
                leadSource.setText(allLeadsOutput.getLeadSource().getName());
                socialnetworkLayout.setVisibility(View.GONE);

                referralLayout.setVisibility(View.VISIBLE);
                referralError.setVisibility(View.GONE);

                if (allLeadsOutput.getUserName() != null)
                {
                    referralName.setText(allLeadsOutput.getUserName());
                }
            }

            if (selectedLeadSourceId.equals(Constants.LEADSOURCE_OTHER_ID))
            {
                selectedLeadSourcePosition = 5;
                leadSource.setText(allLeadsOutput.getLeadSource().getName());
                socialnetworkLayout.setVisibility(View.GONE);

                otherDetailsLayout.setVisibility(View.VISIBLE);
                otherDetailsError.setVisibility(View.GONE);

                if (allLeadsOutput.getUserName() != null)
                {
                    otherDetails.setText(allLeadsOutput.getUserName());
                }
            }

        }

        if (allLeadsOutput.getSocialNetwork() != null) {
            String selectedSocialNetworkId = allLeadsOutput.getSocialNetwork().getId();

            if (selectedSocialNetworkId.equals(Constants.SHARE_FACEBOOK_ID)) {
                selectedSocialNetworkPosition = 0;
                socialNetwork.setText(allLeadsOutput.getSocialNetwork().getName());



            }

            if (selectedSocialNetworkId.equals(Constants.SHARE_INSTAGRAM_ID)) {
                selectedSocialNetworkPosition = 1;
                socialNetwork.setText(allLeadsOutput.getSocialNetwork().getName());



            }

            if (selectedSocialNetworkId.equals(Constants.SHARE_TWITTER_ID)) {
                selectedSocialNetworkPosition = 2;
                socialNetwork.setText(allLeadsOutput.getSocialNetwork().getName());



            }
        }

        if (allLeadsOutput.getFacebook() != null)
        {
            contactFacebook.setText(allLeadsOutput.getFacebook());
        }

        if (allLeadsOutput.getInstagram() != null)
        {
            contactInstagram.setText(allLeadsOutput.getInstagram());
        }

        if (allLeadsOutput.getTwitter() != null)
        {
            contactTwitter.setText(allLeadsOutput.getTwitter());
        }

        if (allLeadsOutput.getWebsite() != null)
        {
            contactWebsite.setText(allLeadsOutput.getWebsite());
        }

        if (allLeadsOutput.getEmail() != null)
        {
            contactEmail.setText(allLeadsOutput.getEmail());
        }

        if (allLeadsOutput.getPhoneNo() != null)
        {
            contactPhone.setText(allLeadsOutput.getPhoneNo());
        }

        if (allLeadsOutput.getPhoneNo() != null)
        {
            contactPhone.setText(allLeadsOutput.getPhoneNo());

            if (allLeadsOutput.getCountryCode() != null)
            {
                try {
                    phoneCodePicker.setCountryForPhoneCode(Integer.parseInt(allLeadsOutput.getCountryCode()));
                    phoneCodePicker.setCountryForNameCode(allLeadsOutput.getFlagCode());
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }

            }
        }

        if (allLeadsOutput.getCategoryList() != null) {
            String categoryTagString = "";

            for (int index = 0; index < allLeadsOutput.getCategoryList().size(); index++) {
                String categoryName = allLeadsOutput.getCategoryList().get(index).getCategory().getName();

                if (categoryTagString.isEmpty()) {
                    categoryTagString = categoryName;
                } else {
                    categoryTagString = categoryTagString + ", " + categoryName;
                }

            }

            interests.setText(categoryTagString + ", ");
        }

        if (allLeadsOutput.getProductList() != null) {
            String productTagString = "";

            for (int i = 0; i < allLeadsOutput.getProductList().size(); i++) {
                String productName = allLeadsOutput.getProductList().get(i).getProduct().getProductName();

                if (productTagString.isEmpty()) {
                    productTagString = productName;
                } else {
                    productTagString = productTagString + ", " + productName;
                }

            }

            categories.setText(productTagString + ", ");
        }

        //Setting onclick
        leadSourceClick.setOnClickListener(this);
        socialnetworkClick.setOnClickListener(this);


        //Autocomplete Text view
        /*interests.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(LeadsEditActivity.this,
                android.R.layout.select_dialog_item, categoryNameList);
        interests.setThreshold(1);
        interests.setAdapter(arrayAdapter);*/

        interests.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {

                categoryNameList = new ArrayList<>();
                for (int i=0;i<categoryOutputList.size();i++) {
                    categoryNameList.add(categoryOutputList.get(i).getName());
                }
                String[] parts = interests.getText().toString().split(",");

                for (int i=0; i<parts.length; i++)
                {
                    for (int j=0; j<categoryNameList.size(); j++)
                    {
                        if (parts[i].trim().equalsIgnoreCase(categoryNameList.get(j)))
                        {
                            categoryNameList.remove(j);
                            break;
                        }
                    }
                }

                //Autocomplete Text view
                interests.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(LeadsEditActivity.this,
                        android.R.layout.select_dialog_item, categoryNameList);
                interests.setThreshold(1);
                interests.setAdapter(arrayAdapter);
                interests.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());

                interests.showDropDown();
                interests.requestFocus();
                return false;
            }
        });


        //Adding data to multiautocomplete textview...........
        /*categories.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(LeadsEditActivity.this,
                android.R.layout.select_dialog_item, productNameList);
        categories.setThreshold(1);
        categories.setAdapter(arrayAdapter2);*/

        categories.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                SelecetedCategoryName = new ArrayList<>();
                productNameList = new ArrayList<>();

                String[] parts = interests.getText().toString().split(",");
                Log.e("ValueOfProduct", productOutputList.size()+"");

                for (int index=0;index<parts.length;index++){
                    SelecetedCategoryName.add(parts[index].trim());

                    Log.e("Selected",SelecetedCategoryName.get(index));
                }

                for (int pos = 0; pos < SelecetedCategoryName.size(); pos++)
                {
                    for (int i=0;i<productOutputList.size();i++){

                        if (productOutputList.get(i).getProductId().getProductCategory().getName().equalsIgnoreCase(SelecetedCategoryName.get(pos))) {

                            int flag = 0;

                            for (int j=0; j<productNameList.size(); j++)
                            {
                                if (productNameList.get(j).equalsIgnoreCase(productOutputList.get(i).getProductId().getProductName()))
                                {
                                    flag = 1;
                                    break;
                                }
                                else
                                {
                                    flag = 0;
                                }
                            }

                            if (flag == 0)
                            {
                                Log.e("NameList", productOutputList.get(i).getProductId().getProductCategory().getName()+"");
                                productNameList.add(productOutputList.get(i).getProductId().getProductName());
                            }

                        }

                    }
                }

                String[] partsProducts = categories.getText().toString().split(",");

                for (int index1 = 0; index1 < partsProducts.length; index1++){
                    for (int index2 = 0; index2<productNameList.size(); index2++)
                    {
                        if (partsProducts[index1].trim().equalsIgnoreCase(productNameList.get(index2)))
                        {
                            productNameList.remove(index2);
                            break;
                        }
                    }
                }

                categories.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(LeadsEditActivity.this,
                        android.R.layout.select_dialog_item, productNameList);
                categories.setThreshold(1);
                categories.setAdapter(arrayAdapter);
                categories.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());

                categories.showDropDown();
                categories.requestFocus();

                return false;
            }
        });


        for (int index = 0; index<languageLabelModelList.size();index++) {

            if (languageLabelModelList.get(index).getLangCode().equals("1423")) {
                toolbarHeader.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1134")) {
                toolbarHeaderDone.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1182")) {
                txt_firstName.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1404")) {
                firstName.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1183")) {
                txt_lastName.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1406")) {
                lastName.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1163")) {
                txt_leadSource.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1424")) {
                txt_socialNetworkName.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1425")) {
                txt_referralName.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1417")) {
                referralName.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1426")) {
                txt_otherDetails.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1171")) {
                txt_contactInfo.setText(languageLabelModelList.get(index).getValue());
            }
            /*if (languageLabelModelList.get(index).getLangCode().equals("1419")) {
                txt_twitter.setText(languageLabelModelList.get(index).getValue());
            }*/
            if (languageLabelModelList.get(index).getLangCode().equals("1166")) {
                txt_website.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1167")) {
                txt_Email.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1168")) {
                txt_phone.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1420")) {
                contactPhone.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1173")) {
                txt_Interests.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1138")) {
                txt_categories.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1421")) {
                interests.setHint(languageLabelModelList.get(index).getValue()+".");
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1402")) {
                txt_products.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1422")) {
                categories.setHint(languageLabelModelList.get(index).getValue()+".");
            }
        }

    }

    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_done, menu);
        return true;
    }*/

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return (super.onOptionsItemSelected(menuItem));
    }


    //Service - Getting Product
    private void callGetProductService() {


        String accessTokenId = marketPreference.getString(Constants.LOGIN_ACCESSTOKEN_ID, null);
        final String userId = marketPreference.getString(Constants.LOGIN_USER_ID, null);
        String roleId = marketPreference.getString(Constants.LOGIN_ROLE_ID, null);

        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Config.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        final Api api = retrofit.create(Api.class);

        Call<List<ProductUserOutput>> call = (Call<List<ProductUserOutput>>) api.getProductByUserId(accessTokenId,
                userId,
                roleId,
                Constants.SERVICE_GET_PRODUCT_LIST_BY_USERID,
                userId);
        call.enqueue(new Callback<List<ProductUserOutput>>() {
            @Override
            public void onResponse(Call<List<ProductUserOutput>> call, Response<List<ProductUserOutput>> response) {

                //Checking for response code
                if (response.code() == 200 ) {


                    productOutputList = response.body();

                    if (productOutputList.size()!=0){
                        for (int i=0;i<productOutputList.size();i++){
                            productNameList.add(productOutputList.get(i).getProductId().getProductName());
                            productIdList.add(productOutputList.get(i).getProductId().getProductId());

                            Log.e("NameList",productNameList.get(i));
                            Log.e("NameIdList",productIdList.get(i));
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<List<ProductUserOutput>> call, Throwable t) {

                Log.e("Failure",t.toString());
            }


        });

    }


    //Service - Getting Category
    private void callGetCategoryService() {


        String accessTokenId = marketPreference.getString(Constants.LOGIN_ACCESSTOKEN_ID, null);
        final String userId = marketPreference.getString(Constants.LOGIN_USER_ID, null);
        String roleId = marketPreference.getString(Constants.LOGIN_ROLE_ID, null);

        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Config.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        final Api api = retrofit.create(Api.class);

        Call<List<CategoryListOutput>> call = (Call<List<CategoryListOutput>>) api.getCategoryList(accessTokenId,
                userId,
                roleId,
                Constants.SERVICE_GET_CATEGORY);
        call.enqueue(new Callback<List<CategoryListOutput>>() {
            @Override
            public void onResponse(Call<List<CategoryListOutput>> call, Response<List<CategoryListOutput>> response) {

                //Checking for response code
                if (response.code() == 200 ) {


                    categoryOutputList = response.body();

                    if (categoryOutputList.size()!=0){
                        for (int i=0;i<categoryOutputList.size();i++){
                            categoryNameList.add(categoryOutputList.get(i).getName());
                            categoryIdList.add(categoryOutputList.get(i).getId());

                            Log.e("CategoryNameList",categoryNameList.get(i));
                            Log.e("CategoryNameIdList",categoryIdList.get(i));
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<List<CategoryListOutput>> call, Throwable t) {

                Log.e("Failure",t.toString());
            }
        });
    }


    @Override
    public void onBackPressed() {

        finish();

    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.ll_editLeads_leadSourceClick:

                //Calling dialog
                FragmentManager filterManager = getFragmentManager();
                EditLeadsLeadSourceFilterDialog filterDialog = new EditLeadsLeadSourceFilterDialog(selectedLeadSourcePosition);
                filterDialog.show(filterManager, "FILTER_DIALOG");

                break;

            case R.id.ll_editLeads_socialnetworkClick:

                //Calling dialog
                FragmentManager filterManagerSocial = getFragmentManager();
                EditLeadsSocialNetworkFilterDialog filterDialogSocial = new EditLeadsSocialNetworkFilterDialog(selectedSocialNetworkPosition);
                filterDialogSocial.show(filterManagerSocial, "SOCIAL_FILTER_DIALOG");

                break;

            case R.id.ll_main_toolBar_actionClick:
                //Hiding Keyboard
                hideKeyBoard(LeadsEditActivity.this);


                //Hiding views
                //otherDetailsLayout.setVisibility(View.GONE);
                firstNameError.setVisibility(View.GONE);
                lastNameError.setVisibility(View.GONE);
                leadSourceError.setVisibility(View.GONE);
                socialnetworkError.setVisibility(View.GONE);
                interestError.setVisibility(View.GONE);
                categoriesError.setVisibility(View.GONE);
                phoneNumberError.setVisibility(View.GONE);
                emailError.setVisibility(View.GONE);

                String firstNameText = firstName.getText().toString().trim();
                String lastNameText = lastName.getText().toString().trim();
                String socialText = socialNetwork.getText().toString().trim();
                String referralText = referralName.getText().toString().trim();
                String otherDetailsText = otherDetails.getText().toString().trim();
                String interestsText = interests.getText().toString().trim();
                String categoriesText = categories.getText().toString().trim();
                String contactPhoneText = contactPhone.getText().toString().trim();
                String contactEmailText = contactEmail.getText().toString().trim();







                boolean validFlag = validateTextFields(firstNameText,lastNameText,socialText,referralText,otherDetailsText,interestsText,categoriesText,contactPhoneText,contactEmailText);

                if (validFlag)
                {
                    editLeads(firstNameText,lastNameText,socialText,referralText,otherDetailsText,interestsText,categoriesText);

                }

                break;
        }

    }

    //Func - Select Lead Source
    public void setLeadSource(int clickPosition, String leadSourceName) {

        referralLayout.setVisibility(View.GONE);
        referralError.setVisibility(View.GONE);
        otherDetailsLayout.setVisibility(View.GONE);
        otherDetailsError.setVisibility(View.GONE);

        selectedLeadSourcePosition = clickPosition;
        leadSource.setText(leadSourceName);
        leadSourceError.setVisibility(View.GONE);
        socialnetworkLayout.setVisibility(View.GONE);
        socialnetworkError.setVisibility(View.GONE);

        String loginResponse = marketPreference.getString(Constants.LOGIN_RESPONSE, null);

        //Converting string to Object
        Gson gson = new Gson();
        LoginOutput loginOutput = gson.fromJson(loginResponse, LoginOutput.class);

        if (selectedLeadSourcePosition == 0)
        {
            socialnetworkLayout.setVisibility(View.VISIBLE);
            socialnetworkError.setVisibility(View.GONE);

        }
        else
        {
            socialnetworkLayout.setVisibility(View.GONE);
            socialnetworkError.setVisibility(View.GONE);
        }

        if (selectedLeadSourcePosition == 4)
        {
            referralLayout.setVisibility(View.VISIBLE);
            referralError.setVisibility(View.GONE);

            //referralName.setText(loginOutput.getData().getName() + " " + loginOutput.getData().getLastName());
        }
        else
        {
            referralLayout.setVisibility(View.GONE);
            referralError.setVisibility(View.GONE);
        }

        if (selectedLeadSourcePosition == 5)
        {
            otherDetailsLayout.setVisibility(View.VISIBLE);
            otherDetailsError.setVisibility(View.GONE);

            //otherDetails.setText(loginOutput.getData().getName() + " " + loginOutput.getData().getLastName());
        }
        else
        {
            otherDetailsLayout.setVisibility(View.GONE);
            otherDetailsError.setVisibility(View.GONE);
        }


    }

    public void setSocialNetwork(int clickPosition, String selectedCategory) {

        selectedSocialNetworkPosition = clickPosition;
        socialNetwork.setText(selectedCategory);
    }

    //Func - Validating text fields
    private boolean validateTextFields(String firstNameText, String lastNameText, String otherDetailsText, String referralText,String socialText, String interestsText, String categoriesText, String contactPhoneText, String contactEmailText) {

        boolean validFlag = true;

        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(LeadsEditActivity.this);

        //Registering validation
        phoneCodePicker.registerPhoneNumberTextView(contactPhone);

        if (categoriesText.isEmpty()) {

            //categoriesError.setText(getString(R.string.error_category_empty));
            for (int index = 0; index<languageLabelModelList.size();index++) {

                if (languageLabelModelList.get(index).getLangCode().equals("1415")) {
                    categoriesError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            categoriesError.setVisibility(View.VISIBLE);
            categories.requestFocus();
            validFlag = false;

        }

        if (interestsText.isEmpty()) {

            //interestError.setText(getString(R.string.error_interests_empty));
            for (int index = 0; index<languageLabelModelList.size();index++) {

                if (languageLabelModelList.get(index).getLangCode().equals("1414")) {
                    interestError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            interestError.setVisibility(View.VISIBLE);
            interests.requestFocus();
            validFlag = false;

        }

        if (contactPhoneText.isEmpty()) {


            //phoneNumberError.setText(getString(R.string.error_phone_number_empty));
            for (int index = 0; index<languageLabelModelList.size();index++) {

                if (languageLabelModelList.get(index).getLangCode().equals("1412")) {
                    phoneNumberError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            phoneNumberError.setVisibility(View.VISIBLE);
            contactPhone.requestFocus();

            validFlag = false;
        }
        else
        {
            if (!phoneCodePicker.isValid()) {

                //phoneNumberError.setText(getString(R.string.error_phone_number_invalid));
                for (int index = 0; index<languageLabelModelList.size();index++) {

                    if (languageLabelModelList.get(index).getLangCode().equals("1413")) {
                        phoneNumberError.setText(languageLabelModelList.get(index).getValue());
                    }
                }
                phoneNumberError.setVisibility(View.VISIBLE);
                contactPhone.requestFocus();

                validFlag = false;
            }
        }

        if (contactEmailText.isEmpty()) {

            //emailError.setText(getString(R.string.error_email_empty));
            for (int index = 0; index<languageLabelModelList.size();index++) {

                if (languageLabelModelList.get(index).getLangCode().equals("1410")) {
                    emailError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            emailError.setVisibility(View.VISIBLE);
            contactEmail.requestFocus();

            validFlag = false;
        }
        else
        {
            if (!isValidEmail(contactEmailText)) {

                //emailError.setText(getString(R.string.error_email_invalid));
                for (int index = 0; index<languageLabelModelList.size();index++) {

                    if (languageLabelModelList.get(index).getLangCode().equals("1411")) {
                        emailError.setText(languageLabelModelList.get(index).getValue());
                    }
                }
                emailError.setVisibility(View.VISIBLE);
                contactEmail.requestFocus();

                validFlag = false;
            }
        }





        if (selectedLeadSourcePosition == -1)
        {
            //leadSourceError.setText(getString(R.string.error_lead_source_empty));
            for (int index = 0; index<languageLabelModelList.size();index++) {

                if (languageLabelModelList.get(index).getLangCode().equals("1407")) {
                    leadSourceError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            leadSourceError.setVisibility(View.VISIBLE);
            leadSourceClick.requestFocus();
            validFlag = false;
        }
        else
        {
            if (selectedLeadSourcePosition == 0)
            {
                if (selectedSocialNetworkPosition == -1)
                {
                    //socialnetworkError.setText(getString(R.string.error_social_network_empty));
                    for (int index = 0; index<languageLabelModelList.size();index++) {

                        if (languageLabelModelList.get(index).getLangCode().equals("1409")) {
                            socialnetworkError.setText(languageLabelModelList.get(index).getValue());
                        }
                    }
                    socialnetworkError.setVisibility(View.VISIBLE);
                    socialnetworkClick.requestFocus();
                    validFlag = false;
                }
            }

            if (selectedLeadSourcePosition == 4)
            {
                if (referralText.isEmpty())
                {
                    //referralError.setText(getString(R.string.error_referral_empty));
                    for (int index = 0; index<languageLabelModelList.size();index++) {

                        if (languageLabelModelList.get(index).getLangCode().equals("1416")) {
                            referralError.setText(languageLabelModelList.get(index).getValue());
                        }
                    }
                    referralError.setVisibility(View.VISIBLE);
                    referralName.requestFocus();
                    validFlag = false;
                }

            }

            if (selectedLeadSourcePosition == 5)
            {
                if (otherDetailsText.isEmpty())
                {
                    //otherDetailsError.setText(getString(R.string.error_details_empty));
                    for (int index = 0; index<languageLabelModelList.size();index++) {

                        if (languageLabelModelList.get(index).getLangCode().equals("1418")) {
                            otherDetailsError.setText(languageLabelModelList.get(index).getValue());
                        }
                    }
                    otherDetailsError.setVisibility(View.VISIBLE);
                    otherDetails.requestFocus();
                    validFlag = false;
                }

            }

        }




        if (lastNameText.isEmpty()) {

            //lastNameError.setText(getString(R.string.error_last_name_empty));
            for (int index = 0; index<languageLabelModelList.size();index++) {

                if (languageLabelModelList.get(index).getLangCode().equals("1405")) {
                    lastNameError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            lastNameError.setVisibility(View.VISIBLE);
            lastName.requestFocus();
            validFlag = false;

        }

        if (firstNameText.isEmpty()) {

            //firstNameError.setText(getString(R.string.error_first_name_empty));
            for (int index = 0; index<languageLabelModelList.size();index++) {

                if (languageLabelModelList.get(index).getLangCode().equals("1403")) {
                    firstNameError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            firstNameError.setVisibility(View.VISIBLE);
            firstName.requestFocus();
            validFlag = false;

        }

        return validFlag;
    }

    //Func - Edit Leads
    private void editLeads(String firstNameText,String lastNameText,String socialText,String referralText,String otherDetailsText,
                           String interestsText,String categoriesText) {

        boolean isInternetPresent = connectionDetector.isConnectingToInternet();

        if (isInternetPresent) {

            callEditLeadsService(firstNameText,lastNameText,socialText,referralText,otherDetailsText,interestsText,categoriesText);

        }
        else
        {
            List<MobileLang> languageLabelModelList = getLanguageLabelPreference(LeadsEditActivity.this);
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1340")) {
                    noInternet=languageLabelModelList.get(index).getValue();
                }
            }
            Snackbar snackbar = Snackbar
                    .make(leadsEditActivityContainer, noInternet, Snackbar.LENGTH_LONG);

            snackbar.show();
        }
    }

    //Service - Edit Leads
    private void callEditLeadsService(String firstNameText,String lastNameText,String socialText,String referralText,String otherDetailsText,
                                      String interestsText,String categoryText) {

        //Showing loading
        progressDialog.show();

        String accessTokenId = marketPreference.getString(Constants.LOGIN_ACCESSTOKEN_ID, null);
        final String userId = marketPreference.getString(Constants.LOGIN_USER_ID, null);
        String roleId = marketPreference.getString(Constants.LOGIN_ROLE_ID, null);

        String contactFacebookText = contactFacebook.getText().toString().trim();
        String contactInstagramText = contactInstagram.getText().toString().trim();
        String contactTwitterText = contactTwitter.getText().toString().trim();
        String contactWebsiteText = contactWebsite.getText().toString().trim();
        String contactEmailText = contactEmail.getText().toString().trim();
        String contactPhoneText = contactPhone.getText().toString().trim();


        EditLeadInput editLeadInput = new EditLeadInput();

        editLeadInput.setId(allLeadsOutput.getId().toString());
        editLeadInput.setLeadId(allLeadsOutput.getLeadId());
        editLeadInput.setName(firstNameText);
        editLeadInput.setLastName(lastNameText);

        editLeadInput.setFacebook(contactFacebookText);
        editLeadInput.setInstagram(contactInstagramText);
        editLeadInput.setTwitter(contactTwitterText);
        editLeadInput.setWebsite(contactWebsiteText);
        editLeadInput.setEmail(contactEmailText);
        editLeadInput.setFlagCode(phoneCodePicker.getSelectedCountryNameCode());
        editLeadInput.setPhoneNo(contactPhoneText);

        if (contactPhoneText.isEmpty())
        {
            editLeadInput.setCountryCode("");
        }
        else
        {
            editLeadInput.setCountryCode(phoneCodePicker.getSelectedCountryCodeWithPlus());
        }


        LeadSource leadSourceObject = new LeadSource();
        switch (selectedLeadSourcePosition)
        {
            case 0:

                leadSourceObject.setId(Constants.LEADSOURCE_SOCIAL_NETWORK_ID);
                editLeadInput.setUserName("");

                break;

            case 1:

                leadSourceObject.setId(Constants.LEADSOURCE_WEBSITE_ID);
                editLeadInput.setUserName("");

                break;

            case 2:

                leadSourceObject.setId(Constants.LEADSOURCE_EMAIL_ID);
                editLeadInput.setUserName("");

                break;

            case 3:

                leadSourceObject.setId(Constants.LEADSOURCE_PHONE_ID);
                editLeadInput.setUserName("");

                break;

            case 4:

                leadSourceObject.setId(Constants.LEADSOURCE_REFEREL_ID);
                editLeadInput.setUserName(referralName.getText().toString());

                break;

            case 5:

                leadSourceObject.setId(Constants.LEADSOURCE_OTHER_ID);
                editLeadInput.setUserName(otherDetails.getText().toString());

                break;
        }

        editLeadInput.setLeadSource(leadSourceObject);

        SocialNetwork socialNetwork = new SocialNetwork();
        switch (selectedSocialNetworkPosition)
        {
            case 0:

                socialNetwork.setId(Constants.SHARE_FACEBOOK_ID);


                break;

            case 1:

                socialNetwork.setId(Constants.SHARE_INSTAGRAM_ID);


                break;

            case 2:

                socialNetwork.setId(Constants.SHARE_TWITTER_ID);


                break;
        }

        editLeadInput.setSocialNetwork(socialNetwork);

        Source sourceObject = new Source();
        sourceObject.setId("4");
        editLeadInput.setSource(sourceObject);

        AssignedTo assignedToObject = new AssignedTo();
        assignedToObject.setUserId(userId);
        editLeadInput.setSource(sourceObject);

        LeadOwner leadOwnerObject = new LeadOwner();
        leadOwnerObject.setUserId(userId);
        editLeadInput.setLeadOwner(leadOwnerObject);

        CreatedBy createdByObject = new CreatedBy();
        createdByObject.setUserId(userId);
        editLeadInput.setCreatedBy(createdByObject);

        UserId userIdObject = new UserId();
        userIdObject.setUserId(userId);
        editLeadInput.setUserId(userIdObject);

        UpdatedBy updatedByObject = new UpdatedBy();
        updatedByObject.setUserId(userId);
        editLeadInput.setUpdatedBy(updatedByObject);


        Log.e("INTERESTS",interestsText);

        /*String[] parts = interestsText.split(",");
        boolean isRealEstateSelected = false;
        boolean isInvestmentSelected = false;



        for (int index=0;index<parts.length;index++){

            if (parts[index].trim().equals("Real Estate"))
            {
                isRealEstateSelected = true;

                Log.e("Real Estate","YES");
            }

            if (parts[index].trim().equals("Investment"))
            {
                isInvestmentSelected = true;

                Log.e("INVESTMENT","YES");
            }
        }

        List<CategoryList> categoryListUpload = new ArrayList<>();

        if (isRealEstateSelected)
        {
            CategoryList categoryList = new CategoryList();
            Category category = new Category();
            category.setId(Constants.PRODUCT_CATEGORY_REALESTATE_ID);
            categoryList.setCategory(category);

            categoryListUpload.add(categoryList);
        }

        if (isInvestmentSelected)
        {
            CategoryList categoryList = new CategoryList();
            Category category = new Category();
            category.setId(Constants.PRODUCT_CATEGORY_INVESTMENT_ID);
            categoryList.setCategory(category);

            categoryListUpload.add(categoryList);
        }

        if (categoryListUpload.size()>0)
        {
            editLeadInput.setCategoryList(categoryListUpload);
        }*/

        //Category....

        List<CategoryList> categoryListUpload = new ArrayList<>();
        String[] parts = interestsText.split(",");
        for (int index=0;index<parts.length;index++){
            SelecetedCategoryName.add(parts[index].trim());


            Log.e("Selected",SelecetedCategoryName.get(index));
        }

        for (int j=0;j<SelecetedCategoryName.size();j++){
            for (int k=0; k<categoryOutputList.size();k++){
                if (SelecetedCategoryName.get(j).equals(categoryOutputList.get(k).getName()))
                {
                    if (SelecetedCategoryId.size()!=0) {
                        int flag  =0;
                        for (int p = 0; p < SelecetedCategoryId.size(); p++) {
                            if (categoryOutputList.get(k).getId().equals(SelecetedCategoryId.get(p))) {
                                flag=0;
                                break;

                            } else {
                                flag=1;
                            }
                        }
                        if (flag==1)
                        {
                            SelecetedCategoryId.add(categoryOutputList.get(k).getId());
                        }
                    }
                    else {
                        SelecetedCategoryId.add(categoryOutputList.get(k).getId());
                    }

                }
            }
        }

        for (int m=0;m<SelecetedCategoryId.size();m++){
            CategoryList categoryList=new CategoryList();
            Category category=new Category();
            category.setId(SelecetedCategoryId.get(m));
            categoryList.setCategory(category);
            categoryListUpload.add(categoryList);
        }

        if (categoryListUpload.size()>0)
        {
            editLeadInput.setCategoryList(categoryListUpload);
        }



        //Product......

        List<ProductList> productListUpload = new ArrayList<>();
        String[] parts2 = categoryText.split(",");
        for (int index=0;index<parts2.length;index++){
            SelecetedPName.add(parts2[index].trim());


            Log.e("Selected",SelecetedPName.get(index));
        }

        for (int j=0;j<SelecetedPName.size();j++){
            for (int k=0; k<productOutputList.size();k++){
                if (SelecetedPName.get(j).equals(productOutputList.get(k).getProductId().getProductName()))
                {
                    if (SelecetedPId.size()!=0) {
                        int flag  =0;
                        for (int p = 0; p < SelecetedPId.size(); p++) {
                            if (productOutputList.get(k).getProductId().getProductId().equals(SelecetedPId.get(p))) {
                                flag=0;
                                break;

                            } else {
                                flag=1;
                            }
                        }
                        if (flag==1)
                        {
                            SelecetedPId.add(productOutputList.get(k).getProductId().getProductId());
                        }
                    }
                    else {
                        SelecetedPId.add(productOutputList.get(k).getProductId().getProductId());
                    }

                }
            }
        }

        for (int m=0;m<SelecetedPId.size();m++){
            ProductList productList=new ProductList();
            Product product=new Product();
            product.setProductId(SelecetedPId.get(m));
            productList.setProduct(product);
            productListUpload.add(productList);
        }

        if (productListUpload.size()>0)
        {
            editLeadInput.setProductList(productListUpload);
        }




        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Config.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        final Api api = retrofit.create(Api.class);

        Call<ResponseBody> call = (Call<ResponseBody>) api.editLeads(accessTokenId,
                userId,
                roleId,
                Constants.SERVICE_EDIT_LEADS,
                editLeadInput);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {


                //Checking for response code
                if (response.code() == 200 ) {

                    //Finishing Activity
                    LeadsDetailActivity.leadsDetailActivityActivityInstance.finish();

                    //Dismiss loading
                    progressDialog.dismiss();

                    SharedPreferences.Editor preferenceEditor = marketPreference.edit();

                    //Preference Editor
                    preferenceEditor.putBoolean(Constants.IS_ACTIVE_LEAD_DATA_CHANGED, true);
                    preferenceEditor.putBoolean(Constants.IS_READY_LEAD_DATA_CHANGED, true);
                    preferenceEditor.putBoolean(Constants.IS_CONVERTED_LEAD_DATA_CHANGED, true);

                    preferenceEditor.commit();

                    finish();


                }
                //If status code is not 200
                else
                {

                    //Dismiss loading
                    progressDialog.dismiss();

                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(LeadsEditActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1341")) {
                            ServerError=languageLabelModelList.get(index).getValue() + ":" + response.code();
                        }
                    }
                    Snackbar snackbar = Snackbar
                            .make(leadsEditActivityContainer, ServerError, Snackbar.LENGTH_LONG);

                    snackbar.show();

                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {


                //Dismiss loading
                progressDialog.dismiss();

                Log.e("Failure",t.toString());

                List<MobileLang> languageLabelModelList = getLanguageLabelPreference(LeadsEditActivity.this);
                for (int index = 0; index<languageLabelModelList.size();index++) {
                    if (languageLabelModelList.get(index).getLangCode().equals("1342")) {
                        SomethingWrong=languageLabelModelList.get(index).getValue();
                    }
                }
                Snackbar snackbar = Snackbar
                        .make(leadsEditActivityContainer, SomethingWrong, Snackbar.LENGTH_LONG);

                snackbar.show();



            }

        });

    }

    //Retrofit log
    public OkHttpClient.Builder getHttpClient() {

        if (builder == null) {
            HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            OkHttpClient.Builder client = new OkHttpClient.Builder();
            client.addInterceptor(loggingInterceptor);
            client.writeTimeout(60000, TimeUnit.MILLISECONDS);
            client.readTimeout(60000, TimeUnit.MILLISECONDS);
            client.connectTimeout(60000, TimeUnit.MILLISECONDS);
            return client;
        }
        return builder;
    }


}