package in.exuber.usmarket.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import in.exuber.usmarket.R;
import in.exuber.usmarket.activity.activeleadsdetails.LeadsDetailActivity;
import in.exuber.usmarket.apimodels.allleads.allleadsoutput.AllLeadsOutput;
import in.exuber.usmarket.apimodels.allleads.allleadsoutput.ProductList;

public class ActiveLeadsInterestProductAdapter extends RecyclerView.Adapter<ActiveLeadsInterestProductAdapter.MyViewHolder>{

    //Declaring variables
    List<ProductList> allLeadsOutput;
    Context context;

    public ActiveLeadsInterestProductAdapter(Context context, List<ProductList> allLeadsOutput) {
        this.allLeadsOutput = allLeadsOutput;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int i) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_interest_product,parent,false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {

        Log.e("Hi", "msh");

         myViewHolder.tv_interestProduct.setText(allLeadsOutput.get(i).getProduct().getProductName());
            Log.e("LeadPName", allLeadsOutput.get(i).getProduct().getProductName() + "");


    }

    @Override
    public int getItemCount() {
        return allLeadsOutput.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tv_interestProduct;
        public MyViewHolder(View itemView) {
            super(itemView);

            tv_interestProduct=itemView.findViewById(R.id.tv_interestProduct);
        }
    }
}
