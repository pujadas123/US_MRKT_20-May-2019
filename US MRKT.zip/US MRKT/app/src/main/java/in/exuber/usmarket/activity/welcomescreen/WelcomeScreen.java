package in.exuber.usmarket.activity.welcomescreen;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import in.exuber.usmarket.R;
import in.exuber.usmarket.activity.loginsignup.LoginSignupActivity;
import in.exuber.usmarket.apimodels.login.loginoutput.MobileLang;

import static in.exuber.usmarket.utils.UtilMethods.getLanguageLabelPreference;

public class WelcomeScreen extends AppCompatActivity implements View.OnClickListener {

    //Declariing views
    private LinearLayout letsGoClick;
    TextView welcomeCongratulations,welcomeText1,welcomeText2,welcomeScreen_letsGo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_screen);

        //Initialising views
        letsGoClick = findViewById(R.id.ll_welcomeScreen_letsGoClick);

        welcomeCongratulations=findViewById(R.id.txt_welcomeCongratulations);
        welcomeText1=findViewById(R.id.txt_welcomeText1);
        welcomeText2=findViewById(R.id.txt_welcomeText2);
        welcomeScreen_letsGo=findViewById(R.id.txt_welcomeScreen_letsGo);

        //Setting on click
        letsGoClick.setOnClickListener(this);
    }


    @Override
    protected void onResume() {
        super.onResume();

        /*List<MobileLang> languageLabelModelList = getLanguageLabelPreference(WelcomeScreen.this);

        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1130")) {
                welcomeCongratulations.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1130")) {
                welcomeText1.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1130")) {
                welcomeText2.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1130")) {
                welcomeScreen_letsGo.setText(languageLabelModelList.get(index).getValue());
            }
        }*/
    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.ll_welcomeScreen_letsGoClick:

                Log.e("Clicked","Clicked");

                startActivity(new Intent(WelcomeScreen.this, LoginSignupActivity.class));
                finish();

                break;
        }

    }
}
