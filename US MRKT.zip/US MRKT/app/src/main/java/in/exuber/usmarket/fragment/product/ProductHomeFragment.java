package in.exuber.usmarket.fragment.product;


import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.NestedScrollView;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SearchView;
import android.widget.TextView;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import in.exuber.usmarket.R;
import in.exuber.usmarket.activity.homeaddproducts.HomeAddProductsActivity;
import in.exuber.usmarket.activity.productedit.ProductEditActivity;
import in.exuber.usmarket.activity.profileagreementsdetail.ProfileAgreementsDetailActivity;
import in.exuber.usmarket.adapter.ProductHomeListAdapter;
import in.exuber.usmarket.apimodels.agreement.homepage.AgreementTypeOutput;
import in.exuber.usmarket.apimodels.agreement.recoeddata.AgreementRecordDataOutput;
import in.exuber.usmarket.apimodels.login.loginoutput.MobileLang;
import in.exuber.usmarket.apimodels.ppdateappdata.UpgradeAppDataOutputList;
import in.exuber.usmarket.apimodels.productuser.productuseroutput.ProductUserOutput;
import in.exuber.usmarket.apimodels.signup.signupoutput.RegistrationAgreementOutput;
import in.exuber.usmarket.utils.Api;
import in.exuber.usmarket.utils.Config;
import in.exuber.usmarket.utils.ConnectionDetector;
import in.exuber.usmarket.utils.Constants;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.content.Context.MODE_PRIVATE;
import static in.exuber.usmarket.utils.UtilMethods.getLanguageLabelPreference;
import static in.exuber.usmarket.utils.UtilMethods.hideKeyBoard;

/**
 * A simple {@link Fragment} subclass.
 */
public class ProductHomeFragment extends Fragment implements View.OnClickListener {

    //Declaring views
    private LinearLayout productHomeFragmentContainer;
    private SwipeRefreshLayout swipeRefreshLayout_productList;
    private NestedScrollView productLayout;

    private RelativeLayout toolbarEditClick;
    private RelativeLayout toolbarAddClick;
    TextView tooberHeaderEditText;

    private RecyclerView productList;

    private SearchView searchProduct;

    private LinearLayout progressDialog;
    private LinearLayout errorDisplay;
    private ScrollView errorDisplayMyProduct;

    private ImageView errorDisplayIcon;
    private TextView errorDisplayText;
    private TextView errorDisplayTryClick;

    private ImageView errorDisplayIconMyProduct;
    private TextView errorDisplayHeaderMyProduct;
    private TextView errorDisplayTextMyProduct;
    private TextView errorDisplayAddProductClickMyProduct,myProductsText, progressPleaseWait;



    //Sharedpreferences
    private SharedPreferences marketPreference;
    SharedPreferences.Editor preferenceEditor;

    //Connection Detector
    private ConnectionDetector connectionDetector;



    //Declaring Retrofit log
    private static OkHttpClient.Builder builder;

    //Declaring variables
    private List<ProductUserOutput> productOutputList;

     //Adapter
    private ProductHomeListAdapter productHomeListAdapter;

    String tc,agreements, popupURL;
    int terms1,terms2, sales1, sales2;
    AlertDialog alertDialog;
    AlertDialog.Builder alert;
    TextView txt_termsUrl, btn_termsAccept;
    private TextView dialogText, dialogCancel, dialogOk;

    AgreementTypeOutput agreementTypeOutputs=new AgreementTypeOutput();
    AgreementRecordDataOutput agreementRecordDataOutputs=new AgreementRecordDataOutput();

    UpgradeAppDataOutputList upgradeAppDataOutputList=new UpgradeAppDataOutputList();


    public ProductHomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View productView = inflater.inflate(R.layout.fragment_product_home, container, false);

        //Hiding keyboard
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        //Initialising shared preferences
        marketPreference =  getActivity().getSharedPreferences(Constants.PREFERENCE_NAME,MODE_PRIVATE);
        preferenceEditor=marketPreference.edit();
        preferenceEditor.apply();

        //Initialising connection detector
        connectionDetector = new ConnectionDetector(getActivity());

        //Initialising variables
        productOutputList = new ArrayList<>();

        //Initialising views
        productHomeFragmentContainer = productView.findViewById(R.id.fragment_product_home);

        toolbarEditClick = productView.findViewById(R.id.rl_homeProducts_toolBar_editLayout);
        toolbarAddClick = productView.findViewById(R.id.rl_homeProducts_toolBar_addLayout);

        tooberHeaderEditText=productView.findViewById(R.id.txt_toolberEdit);

        //Recyclerview
        productList = productView.findViewById(R.id.rv_homeProduct_productList);
        productList.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManagerProducts = new LinearLayoutManager(getActivity());
        linearLayoutManagerProducts.setOrientation(LinearLayoutManager.VERTICAL);
        productList.setLayoutManager(linearLayoutManagerProducts);

        productLayout = productView.findViewById(R.id.nsv_homeProduct_parentlayout);
        searchProduct = productView.findViewById(R.id.et_homeProduct_search);

        ///Swipe Refresh Layout
        swipeRefreshLayout_productList = productView.findViewById(R.id.srl_homeProduct_pullToRefresh);
        swipeRefreshLayout_productList.setColorSchemeResources(
                R.color.colorPrimary);

        progressDialog =  productView.findViewById(R.id.ll_custom_dialog);
        errorDisplay =  productView.findViewById(R.id.ll_errorMain_layout);
        errorDisplayMyProduct =  productView.findViewById(R.id.sv_errorMyProduct_layout);

        errorDisplayIcon = productView.findViewById(R.id.iv_errorMain_errorIcon);
        errorDisplayText =  productView.findViewById(R.id.tv_errorMain_errorText);
        errorDisplayTryClick =  productView.findViewById(R.id.tv_errorMain_errorTryAgain);

        errorDisplayIconMyProduct = productView.findViewById(R.id.iv_errorMyProduct_errorIcon);
        errorDisplayHeaderMyProduct =  productView.findViewById(R.id.tv_errorMyProduct_errorHeader);
        errorDisplayTextMyProduct =  productView.findViewById(R.id.tv_errorMyProduct_errorText);
        errorDisplayAddProductClickMyProduct =  productView.findViewById(R.id.tv_errorMyProduct_addProductClick);

        myProductsText=productView.findViewById(R.id.txt_homeProduct_myProducts);
        progressPleaseWait=productView.findViewById(R.id.txt_pleaseWait);



        searchProduct.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String product) {



                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {

                if (productHomeListAdapter != null)
                {
                    productHomeListAdapter.getFilter().filter(query.toLowerCase());
                }

                return false;
            }
        });

        //Calling Service
        getProduct();

        //Swipe Referesh listner
        swipeRefreshLayout_productList.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                //Calling Service
                getProduct();

                swipeRefreshLayout_productList.setRefreshing(false);
            }
        });



        //Setting onclick listner
        toolbarEditClick.setOnClickListener(this);
        toolbarAddClick.setOnClickListener(this);
        errorDisplayTryClick.setOnClickListener(this);
        errorDisplayAddProductClickMyProduct.setOnClickListener(this);


        return productView;
    }

    @Override
    public void onResume() {
        super.onResume();

        boolean isProductDataChanged = marketPreference.getBoolean(Constants.IS_PRODUCT_DATA_CHANGED, false);

        if (isProductDataChanged)
        {

            SharedPreferences.Editor preferenceEditor = marketPreference.edit();

            //Preference Editor
            preferenceEditor.putBoolean(Constants.IS_PRODUCT_DATA_CHANGED, false);

            preferenceEditor.apply();

            //Calling Service
            getProduct();
        }

        //Calling Agreement Service.....


        terms1 = marketPreference.getInt("terms1", 0);
        terms2 = marketPreference.getInt("terms2", 0);
        sales1 = marketPreference.getInt("sales1", 0);
        sales2 = marketPreference.getInt("sales2", 0);

        Log.e("Terms11", String.valueOf(terms1));
        Log.e("Terms22", String.valueOf(terms2));
        Log.e("Sales11", String.valueOf(sales1));
        Log.e("Sales22", String.valueOf(sales2));

        tc="tc";
        agreements="agreements";

        if (terms1 == terms2){

            if (sales1 == sales2){

            }
            else {
                callAgreementRecordByTypeService(agreements,"t","");
            }
        }
        else {

          //  callAgreementRecordByTypeService(tc,"","");

            if (sales1 == sales2){
                callAgreementRecordByTypeService(tc,"","");
            }
            else {
                callAgreementRecordByTypeService(tc,"","sa");
                //callAgreementRecordByTypeService(tc,"","");
            }

        }


        ////

        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1130")) {
                myProductsText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1131")) {
                tooberHeaderEditText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1132")) {
                searchProduct.setQueryHint(languageLabelModelList.get(index).getValue()+"...");
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1142")) {
                errorDisplayAddProductClickMyProduct.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1143")) {
                progressPleaseWait.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1345")) {
                errorDisplayTryClick.setText(languageLabelModelList.get(index).getValue());
            }
        }

        ////
    }

    //Func - Getting Agreement Type
    private void callAgreementRecordByTypeService(String typevalue, final String typedata, final String data) {

        progressDialog.setVisibility(View.VISIBLE);

        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Config.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        final Api api = retrofit.create(Api.class);

        String type=typevalue;

        Call<AgreementTypeOutput> call = (Call<AgreementTypeOutput>) api.agreementsRecordsByType(type);
        call.enqueue(new Callback<AgreementTypeOutput>() {
            @Override
            public void onResponse(Call<AgreementTypeOutput> call, Response<AgreementTypeOutput> response) {

                //Checking for response code
                if (response.code() == 200 ) {

                    progressDialog.setVisibility(View.GONE);

                    agreementTypeOutputs = response.body();

                    Log.e("MSG", String.valueOf(agreementTypeOutputs.getId()));


                    callAgreementRecordDataService(agreementTypeOutputs.getId(), typedata, data);

                }
            }

            @Override
            public void onFailure(Call<AgreementTypeOutput> call, Throwable t) {

                progressDialog.setVisibility(View.GONE);

                Log.e("Failure",t.toString());
            }
        });

    }

    //Func - Getting Agreement Data
    private void callAgreementRecordDataService(int ID, String typedata, final String data) {

        progressDialog.setVisibility(View.VISIBLE);

        String accessTokenId = marketPreference.getString(Constants.LOGIN_ACCESSTOKEN_ID, null);
        final String userId = marketPreference.getString(Constants.LOGIN_USER_ID, null);
        String roleId = marketPreference.getString(Constants.LOGIN_ROLE_ID, null);

        int agreementTypeId=ID;


        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Config.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        final Api api = retrofit.create(Api.class);

        Call<AgreementRecordDataOutput> call = (Call<AgreementRecordDataOutput>) api.agreementRecordsData(accessTokenId,
                userId,
                roleId,
                Constants.SERVICE_AGREEMENT_RECOED_DATA,
                agreementTypeId);
        call.enqueue(new Callback<AgreementRecordDataOutput>() {
            @Override
            public void onResponse(Call<AgreementRecordDataOutput> call, Response<AgreementRecordDataOutput> response) {

                //Checking for response code
                if (response.code() == 200 ) {

                    progressDialog.setVisibility(View.GONE);

                    agreementRecordDataOutputs = response.body();

                    popupURL = agreementRecordDataOutputs.getUrl();

                    Log.e("UUURRRLL",popupURL);

                    try {

                        AgreementTermsDialog(data);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }

            @Override
            public void onFailure(Call<AgreementRecordDataOutput> call, Throwable t) {

                progressDialog.setVisibility(View.GONE);

                Log.e("Failure",t.toString());
            }
        });

    }

    private void AgreementTermsDialog(final String data) throws JSONException {

        LayoutInflater li = LayoutInflater.from(getActivity());

        View dashboardDialog = li.inflate(R.layout.dialog_terms_agreement, null);

        //Initizliaing confirm button fo dialog box and edittext of dialog box
        txt_termsUrl = (TextView) dashboardDialog.findViewById(R.id.txt_termsUrl);
        btn_termsAccept = (TextView)dashboardDialog.findViewById(R.id.btn_termsAccept);

        //Creating an alertdialog builder
        alert = new AlertDialog.Builder(getActivity());

        //Adding our dialog box to the view of alert dialog
        alert.setView(dashboardDialog);

        //Creating an alert dialog
        alertDialog = alert.create();
        alertDialog.setCancelable(false);


        //Displaying the alert dialog
        alertDialog.show();

        txt_termsUrl.setText(popupURL);

        btn_termsAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (data.equalsIgnoreCase(""))
                {

                    terms1=terms2;
                    sales1=sales2;
                    preferenceEditor.putInt("terms1",terms1);
                    preferenceEditor.putInt("terms2",terms1);
                    preferenceEditor.putInt("sales1",sales1);
                    preferenceEditor.putInt("sales2",sales1);
                    preferenceEditor.commit();
                    alertDialog.dismiss();
                }
                else
                {
                    alertDialog.dismiss();
                    callAgreementRecordByTypeService(agreements,"","");
                }
            }
        });

        txt_termsUrl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(),ProfileAgreementsDetailActivity.class);
                intent.putExtra("selectedAgreement",popupURL);
                getActivity().startActivity(intent);
            }
        });
    }



    public void onBackPressed() {

        getActivity().finish();

    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {

            case R.id.rl_homeProducts_toolBar_editLayout:

                //Hiding Keyboard
                hideKeyBoard(getActivity());

                //Calling Edit Product Activity
                startActivity(new Intent(getActivity(), ProductEditActivity.class));


                break;

            case R.id.rl_homeProducts_toolBar_addLayout:

                //Hiding Keyboard
                hideKeyBoard(getActivity());

                //Calling Add Product Activity
                startActivity(new Intent(getActivity(), HomeAddProductsActivity.class));

                break;

            case R.id.tv_errorMyProduct_addProductClick:

                //Hiding Keyboard
                hideKeyBoard(getActivity());

                //Calling Edit Product Activity
                startActivity(new Intent(getActivity(), HomeAddProductsActivity.class));


                break;

            case R.id.tv_errorMain_errorTryAgain:

                //Hiding Keyboard
                hideKeyBoard(getActivity());

                //Calling Service
                getProduct();



                break;
        }

    }


    //Func - Getting Update App...
    private void getUpdateAppData() {

        toolbarEditClick.setVisibility(View.VISIBLE);

        boolean isInternetPresent = connectionDetector.isConnectingToInternet();

        if (isInternetPresent) {

            //Hiding views
            progressDialog.setVisibility(View.VISIBLE);

            //Calling Service
            callGetUpdateAppService();

        }
        else
        {
            //Hiding views
            progressDialog.setVisibility(View.GONE);
            productLayout.setVisibility(View.GONE);
            errorDisplayMyProduct.setVisibility(View.GONE);

            errorDisplay.setVisibility(View.VISIBLE);

            errorDisplayIcon.setImageResource(R.drawable.ic_error_internet);

            List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1340")) {
                    errorDisplayText.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //errorDisplayText.setText(getString(R.string.error_internet));
        }
    }

    //Service - Get Action Data For App Update
    private void callGetUpdateAppService() {

        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Config.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        final Api api = retrofit.create(Api.class);

        Call<UpgradeAppDataOutputList> call = (Call<UpgradeAppDataOutputList>) api.getUpdateApp();
        call.enqueue(new Callback<UpgradeAppDataOutputList>() {
            @Override
            public void onResponse(Call<UpgradeAppDataOutputList> call, Response<UpgradeAppDataOutputList> response) {

                //Checking for response code
                if (response.code() == 200 ) {

                    progressDialog.setVisibility(View.GONE);

                    int action = 0;

                    upgradeAppDataOutputList = response.body();

                    action=upgradeAppDataOutputList.getAction();

                    Log.e("ACTION_DATA", String.valueOf(action));


                    if (action != 0)
                    {
                        upgradeDialog(action);
                    }



                }
                //If status code is not 200
                else
                {


                    progressDialog.setVisibility(View.GONE);

                    errorDisplay.setVisibility(View.VISIBLE);

                    errorDisplayIcon.setImageResource(R.drawable.ic_error_code);
                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1341")) {
                            errorDisplayText.setText(languageLabelModelList.get(index).getValue() + ":" + response.code());
                        }
                    }
                    //errorDisplayText.setText(getString(R.string.error_response_code) + response.code());

                }
            }

            @Override
            public void onFailure(Call<UpgradeAppDataOutputList> call, Throwable t) {

                Log.e("Failure",t.toString());

                //Hiding views
                progressDialog.setVisibility(View.GONE);
            }

        });
    }

    //Dialog for Upgrade
    private void upgradeDialog(int value) {

        //Creating a LayoutInflater object for the dialog box
        LayoutInflater li = LayoutInflater.from(getActivity());
        //Creating a view to get the dialog box
        View upgradeDialog = li.inflate(R.layout.upgrade_dialog, null);

        //Initizliaing confirm button fo dialog box and edittext of dialog box
        dialogText = upgradeDialog.findViewById(R.id.dialog_text);
        dialogCancel = upgradeDialog.findViewById(R.id.dialog_cancel);
        dialogOk = upgradeDialog.findViewById(R.id.dialog_ok);

        if (value == 1)
        {
            dialogCancel.setVisibility(View.VISIBLE);
            dialogOk.setVisibility(View.VISIBLE);
        }
        else
        {
            dialogCancel.setVisibility(View.GONE);
            dialogOk.setVisibility(View.VISIBLE);
        }

        //Creating an alertdialog builder
        alert = new AlertDialog.Builder(getActivity());

        //Adding our dialog box to the view of alert dialog
        alert.setView(upgradeDialog);

        //Creating an alert dialog
        alertDialog = alert.create();
        alertDialog.setCancelable(false);


        //Displaying the alert dialog
        alertDialog.show();

        dialogCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        dialogOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent launchIntent = getActivity().getPackageManager().getLaunchIntentForPackage("com.android.vending");
                startActivity(launchIntent);

                alertDialog.dismiss();
            }
        });

    }


    //Func - Getting Product
    private void getProduct() {

        toolbarEditClick.setVisibility(View.VISIBLE);

        boolean isInternetPresent = connectionDetector.isConnectingToInternet();

        if (isInternetPresent) {

            //Hiding views
            errorDisplay.setVisibility(View.GONE);
            errorDisplayMyProduct.setVisibility(View.GONE);
            productLayout.setVisibility(View.GONE);

            progressDialog.setVisibility(View.VISIBLE);


            //Calling Service
            callGetProductService();

        }
        else
        {
            //Hiding views
            progressDialog.setVisibility(View.GONE);
            productLayout.setVisibility(View.GONE);
            errorDisplayMyProduct.setVisibility(View.GONE);

            errorDisplay.setVisibility(View.VISIBLE);

            errorDisplayIcon.setImageResource(R.drawable.ic_error_internet);

            List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1340")) {
                    errorDisplayText.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //errorDisplayText.setText(getString(R.string.error_internet));
        }
    }

    //Service - Getting Product
    private void callGetProductService() {


        String accessTokenId = marketPreference.getString(Constants.LOGIN_ACCESSTOKEN_ID, null);
        final String userId = marketPreference.getString(Constants.LOGIN_USER_ID, null);
        String roleId = marketPreference.getString(Constants.LOGIN_ROLE_ID, null);

        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Config.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        final Api api = retrofit.create(Api.class);

        Call<List<ProductUserOutput>> call = (Call<List<ProductUserOutput>>) api.getProductByUserId(accessTokenId,
                userId,
                roleId,
                Constants.SERVICE_GET_PRODUCT_LIST_BY_USERID,
                userId);
        call.enqueue(new Callback<List<ProductUserOutput>>() {
            @Override
            public void onResponse(Call<List<ProductUserOutput>> call, Response<List<ProductUserOutput>> response) {



                //Checking for response code
                if (response.code() == 200 ) {


                    productOutputList = response.body();

                    if (productOutputList.size() == 0)
                    {

                        //Hiding views
                        progressDialog.setVisibility(View.GONE);
                        errorDisplay.setVisibility(View.GONE);
                        productLayout.setVisibility(View.GONE);

                        errorDisplayMyProduct.setVisibility(View.VISIBLE);

                        errorDisplayIconMyProduct.setImageResource(R.drawable.ic_error_product);
                        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
                        for (int index = 0; index<languageLabelModelList.size();index++) {

                            if (languageLabelModelList.get(index).getLangCode().equals("1339")) {
                                errorDisplayHeaderMyProduct.setText(languageLabelModelList.get(index).getValue());
                            }
                        }
                        //errorDisplayHeaderMyProduct.setText(getString( R.string.error_no_data_myproduct));
                        errorDisplayTextMyProduct.setText(getString( R.string.error_description_no_data_myproduct));

                        toolbarEditClick.setVisibility(View.INVISIBLE);

                        ////Service for update app....
                        getUpdateAppData();


                    }
                    else {

                        progressDialog.setVisibility(View.GONE);
                        errorDisplayMyProduct.setVisibility(View.GONE);
                        errorDisplay.setVisibility(View.GONE);


                        productLayout.setVisibility(View.VISIBLE);

                        //Setting adapter
                        productHomeListAdapter = new ProductHomeListAdapter(getActivity(), productOutputList);
                        productList.setAdapter(productHomeListAdapter);
                        productHomeListAdapter.notifyDataSetChanged();

                        ////Service for update app....
                        getUpdateAppData();

                    }



                }
                //If status code is not 200
                else
                {

                    //Hiding views
                    progressDialog.setVisibility(View.GONE);
                    productLayout.setVisibility(View.GONE);
                    errorDisplayMyProduct.setVisibility(View.GONE);

                    errorDisplay.setVisibility(View.VISIBLE);

                    errorDisplayIcon.setImageResource(R.drawable.ic_error_code);
                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1341")) {
                            errorDisplayText.setText(languageLabelModelList.get(index).getValue() + ":" + response.code());
                        }
                    }
                    //errorDisplayText.setText(getString(R.string.error_response_code) + response.code());

                }
            }

            @Override
            public void onFailure(Call<List<ProductUserOutput>> call, Throwable t) {

                Log.e("Failure",t.toString());

                if (t instanceof IOException) {

                    //Hiding views
                    progressDialog.setVisibility(View.GONE);
                    errorDisplay.setVisibility(View.GONE);
                    productLayout.setVisibility(View.GONE);

                    errorDisplayMyProduct.setVisibility(View.VISIBLE);

                    errorDisplayIconMyProduct.setImageResource(R.drawable.ic_error_product);
                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
                    for (int index = 0; index<languageLabelModelList.size();index++) {

                        if (languageLabelModelList.get(index).getLangCode().equals("1339")) {
                            errorDisplayHeaderMyProduct.setText(languageLabelModelList.get(index).getValue());
                        }
                    }
                    //errorDisplayHeaderMyProduct.setText(getString( R.string.error_no_data_myproduct));
                    errorDisplayTextMyProduct.setText(getString( R.string.error_description_no_data_myproduct));

                    toolbarEditClick.setVisibility(View.INVISIBLE);



                }
                else
                {
                    //Hiding views
                    progressDialog.setVisibility(View.GONE);
                    productLayout.setVisibility(View.GONE);
                    errorDisplayMyProduct.setVisibility(View.GONE);

                    errorDisplay.setVisibility(View.VISIBLE);

                    errorDisplayIcon.setImageResource(R.drawable.ic_error_server);
                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1342")) {
                            errorDisplayText.setText(languageLabelModelList.get(index).getValue());
                        }
                    }
                    //errorDisplayText.setText(getString(R.string.error_server));
                }




            }

        });



    }


    //Retrofit log
    public OkHttpClient.Builder getHttpClient() {

        if (builder == null) {
            HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            OkHttpClient.Builder client = new OkHttpClient.Builder();
            client.addInterceptor(loggingInterceptor);
            client.writeTimeout(60000, TimeUnit.MILLISECONDS);
            client.readTimeout(60000, TimeUnit.MILLISECONDS);
            client.connectTimeout(60000, TimeUnit.MILLISECONDS);
            return client;
        }
        return builder;
    }


}
