package in.exuber.usmarket.utils;


public class Config {

    public static final String BASE_URL = "http://usmrkt.us-east-2.elasticbeanstalk.com/";



}

