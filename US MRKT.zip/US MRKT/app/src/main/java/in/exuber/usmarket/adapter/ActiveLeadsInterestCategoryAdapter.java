package in.exuber.usmarket.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import in.exuber.usmarket.R;
import in.exuber.usmarket.apimodels.allleads.allleadsoutput.CategoryList;

public class ActiveLeadsInterestCategoryAdapter extends RecyclerView.Adapter<ActiveLeadsInterestCategoryAdapter.MyViewHolder>{

    //Declaring variables
    List<CategoryList> allLeadsOutput;
    Context context;

    public ActiveLeadsInterestCategoryAdapter(Context context, List<CategoryList> allLeadsOutput) {
        this.allLeadsOutput = allLeadsOutput;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int i) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_interest_category,parent,false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {

        Log.e("Hi", "msg");

         myViewHolder.tv_interestCategory.setText(allLeadsOutput.get(i).getCategory().getName());
            Log.e("LeadCategoryName", allLeadsOutput.get(i).getCategory().getName() + "");


    }

    @Override
    public int getItemCount() {
        return allLeadsOutput.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tv_interestCategory;
        public MyViewHolder(View itemView) {
            super(itemView);

            tv_interestCategory=itemView.findViewById(R.id.tv_interestCategory);
        }
    }
}
