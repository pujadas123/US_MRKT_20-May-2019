package in.exuber.usmarket.apimodels.ppdateappdata;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class UpgradeAppDataOutputList {

    @SerializedName("action")
    @Expose
    private Integer action;
    @SerializedName("message")
    @Expose
    private String message;

    public Integer getAction() {
        return action;
    }

    public void setAction(Integer action) {
        this.action = action;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
