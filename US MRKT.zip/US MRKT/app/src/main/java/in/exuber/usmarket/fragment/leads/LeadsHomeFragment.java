package in.exuber.usmarket.fragment.leads;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import in.exuber.usmarket.R;
import in.exuber.usmarket.activity.campaigndetail.CampaignDetailActivity;
import in.exuber.usmarket.activity.leadsadd.LeadsAddActivity;
import in.exuber.usmarket.activity.notification.NotificationActivity;
import in.exuber.usmarket.apimodels.login.loginoutput.MobileLang;
import in.exuber.usmarket.models.leads.LeadsOutput;
import in.exuber.usmarket.utils.ConnectionDetector;
import in.exuber.usmarket.utils.Constants;

import static android.content.Context.MODE_PRIVATE;
import static in.exuber.usmarket.utils.UtilMethods.getLanguageLabelPreference;
import static in.exuber.usmarket.utils.UtilMethods.hideKeyBoard;

/**
 * A simple {@link Fragment} subclass.
 */
public class LeadsHomeFragment extends Fragment implements View.OnClickListener {

    //Declaring views
    private LinearLayout leadsHomeFragmentContainer;

    private RelativeLayout toolbarNotificationClick;
    private TextView toolbarAddClick,LeadsText;

    private TabLayout leadsTabLayout;
    private ViewPager leadsViewPager;


    //Sharedpreferences
    private SharedPreferences marketPreference;

    //Connection detector class
    private ConnectionDetector connectionDetector;

    String active="ACTIVE";
    String ready="READY";
    String converted="CONVERTED";



    public LeadsHomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View leadsView = inflater.inflate(R.layout.fragment_leads_home, container, false);

        //Hiding keyboard
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        //Initialising shared preferences
        marketPreference =  getActivity().getSharedPreferences(Constants.PREFERENCE_NAME,MODE_PRIVATE);

        //Initialising connection detector
        connectionDetector = new ConnectionDetector(getActivity());


        //Initialising views
        leadsHomeFragmentContainer = leadsView.findViewById(R.id.fragment_leads_home);

        toolbarNotificationClick = leadsView.findViewById(R.id.rl_homeLeads_toolBar_notificationLayout);
        toolbarAddClick = leadsView.findViewById(R.id.iv_homeLeads_toolBar_add);

        leadsViewPager = leadsView.findViewById(R.id.vp_leadsHomeFragment_viewPager);
        leadsTabLayout = leadsView.findViewById(R.id.tl_leadsHomeFragment_tabLayout);
        LeadsText=leadsView.findViewById(R.id.txt_LeadsText);

        //Setting tabs
        setupViewPager(leadsViewPager);
        leadsTabLayout.setupWithViewPager(leadsViewPager);


        //Setting onclick listner
        toolbarNotificationClick.setOnClickListener(this);
        toolbarAddClick.setOnClickListener(this);


        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());

        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1155")) {
                toolbarAddClick.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1154")) {
                LeadsText.setText(languageLabelModelList.get(index).getValue());
            }
        }

        return leadsView;
    }



    @Override
    public void onClick(View view) {

        switch (view.getId())
        {

            case R.id.rl_homeLeads_toolBar_notificationLayout:

                //Hiding Keyboard
                hideKeyBoard(getActivity());

                //Calling Notification Activity
                startActivity(new Intent(getActivity(), NotificationActivity.class));

                break;

            case R.id.iv_homeLeads_toolBar_add:

                //Hiding Keyboard
                hideKeyBoard(getActivity());

                //Calling Add leads Activity
                startActivity(new Intent(getActivity(), LeadsAddActivity.class));


                break;
        }

    }

    //Func - Setting up viewpager
    private void setupViewPager(ViewPager viewPager) {

        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());

        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1156")) {
                active=languageLabelModelList.get(index).getValue();
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1158")) {
                ready=languageLabelModelList.get(index).getValue();
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1160")) {
                converted=languageLabelModelList.get(index).getValue();
            }
        }

        LeadsPagerAdapter adapter = new LeadsPagerAdapter(getChildFragmentManager());
        adapter.addFragment(new LeadsActiveFragment(LeadsHomeFragment.this), active);
        adapter.addFragment(new LeadsReadyFragment(LeadsHomeFragment.this), ready);
        adapter.addFragment(new LeadsConvertedFragment(LeadsHomeFragment.this), converted);
        viewPager.setAdapter(adapter);
    }

    //Func - Setting up first tab title
    public void setFirstTabTitleText() {

        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1156")) {
                active = languageLabelModelList.get(index).getValue();
            }
        }

        leadsTabLayout.getTabAt(0).setText(active);
    }

    //Func - Setting up first tab title
    public void setFirstTabTitle(int size) {

        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1156")) {
                active = languageLabelModelList.get(index).getValue();
            }
        }

        leadsTabLayout.getTabAt(0).setText(active + "("+size+")");
    }

    //Func - Setting up second tab title
    public void setSecondTabTitleText() {

        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1158")) {
                ready=languageLabelModelList.get(index).getValue();
            }
        }
        leadsTabLayout.getTabAt(1).setText(ready);
    }

    //Func - Setting up second tab title
    public void setSecondTabTitle(int size) {

        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1158")) {
                ready=languageLabelModelList.get(index).getValue();
            }
        }
        leadsTabLayout.getTabAt(1).setText(ready + "("+size+")");
    }

    //Func - Setting up third tab title
    public void setThirdTabTitleText() {

        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1160")) {
                converted=languageLabelModelList.get(index).getValue();
            }
        }
        leadsTabLayout.getTabAt(2).setText(converted);
    }


    //Func - Setting up third tab title
    public void setThirdTabTitle(int size) {

        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1160")) {
                converted=languageLabelModelList.get(index).getValue();
            }
        }
        leadsTabLayout.getTabAt(2).setText(converted + "("+size+")");
    }



    //Adapter - Pager Adapter
    class LeadsPagerAdapter extends FragmentPagerAdapter {

        //Declaring variables
        private final List<Fragment> pagerFragmentList = new ArrayList<>();
        private final List<String> pagerFragmentTitleList = new ArrayList<>();

        public LeadsPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return pagerFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return pagerFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            pagerFragmentList.add(fragment);
            pagerFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return pagerFragmentTitleList.get(position);
        }
    }


}
