package in.exuber.usmarket.models.AddLeads;

public class AddLeadsProductsOutput {

    private String productName;


    public AddLeadsProductsOutput(String productName) {
        this.productName = productName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }


}
