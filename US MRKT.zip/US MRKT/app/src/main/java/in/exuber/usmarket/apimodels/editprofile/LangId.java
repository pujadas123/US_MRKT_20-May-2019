
package in.exuber.usmarket.apimodels.editprofile;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LangId {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("language")
    @Expose
    private Object language;
    @SerializedName("locale")
    @Expose
    private Object locale;
    @SerializedName("labelList")
    @Expose
    private Object labelList;
    @SerializedName("mobileList")
    @Expose
    private Object mobileList;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Object getLanguage() {
        return language;
    }

    public void setLanguage(Object language) {
        this.language = language;
    }

    public Object getLocale() {
        return locale;
    }

    public void setLocale(Object locale) {
        this.locale = locale;
    }

    public Object getLabelList() {
        return labelList;
    }

    public void setLabelList(Object labelList) {
        this.labelList = labelList;
    }

    public Object getMobileList() {
        return mobileList;
    }

    public void setMobileList(Object mobileList) {
        this.mobileList = mobileList;
    }

}
