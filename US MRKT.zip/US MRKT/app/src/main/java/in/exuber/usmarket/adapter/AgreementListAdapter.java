package in.exuber.usmarket.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.Gson;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import in.exuber.usmarket.R;
import in.exuber.usmarket.activity.profileagreementsdetail.ProfileAgreementsDetailActivity;
import in.exuber.usmarket.apimodels.agreements.agreementsoutput.AgreementDatum;
import in.exuber.usmarket.apimodels.agreements.agreementsoutput.AgreementOutput;


public class AgreementListAdapter extends RecyclerView.Adapter<AgreementListAdapter.ViewHolder> {

    //Declaring variables
    private Context context;
    private List<AgreementOutput> agreementOutputList;
    private List<AgreementDatum> agreementData;
    String Sales, SalesURL, Terms, TermsURL;


    public AgreementListAdapter(Context context, List<AgreementOutput> agreementOutputList) {

        this.context = context;
        this.agreementOutputList = agreementOutputList;
    }

    @Override
    public AgreementListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_profileagreements_listadapter, parent, false);
        return new AgreementListAdapter.ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(AgreementListAdapter.ViewHolder holder, int position) {


        //Setting values
        long shareTimeMillis = agreementOutputList.get(position).getCreatedOn();
        DateFormat formatter = new SimpleDateFormat("MMM dd, yyyy", Locale.US);
        String pringTimeString = formatter.format(shareTimeMillis);
        holder.agreementDate.setText(pringTimeString);
        agreementData=agreementOutputList.get(position).getAgreementData();
        if (agreementOutputList.get(position).getAgreementData() == null){
            holder.agreementsSalesClick.setVisibility(View.GONE);
            holder.agreementTermsClick.setVisibility(View.GONE);
            holder.agreementDate.setVisibility(View.GONE);

        }
        else {
            for (int i = 0; i < agreementData.size(); i++) {
               /* if (i == 0) {
                    if (agreementOutputList.get(position).getAgreementData().get(i).getName().equalsIgnoreCase("SA agreements")) {
                        Sales = agreementOutputList.get(position).getAgreementData().get(i).getName();
                        SalesURL = agreementOutputList.get(position).getAgreementData().get(i).getUrl();
                    }
                } else {
                    Terms = agreementOutputList.get(position).getAgreementData().get(i).getName();
                    TermsURL = agreementOutputList.get(position).getAgreementData().get(i).getUrl();
                }*/

                if (agreementOutputList.get(position).getAgreementData().get(i).getName().equalsIgnoreCase("SA agreements")) {
                    Sales = agreementOutputList.get(position).getAgreementData().get(i).getName();
                    SalesURL = agreementOutputList.get(position).getAgreementData().get(i).getUrl();
                    holder.agreementsSalesClick.setVisibility(View.VISIBLE);


                }
                else {
                    Terms = agreementOutputList.get(position).getAgreementData().get(i).getName();
                    TermsURL = agreementOutputList.get(position).getAgreementData().get(i).getUrl();
                    holder.agreementTermsClick.setVisibility(View.VISIBLE);
                }
            }
            holder.agreementSales.setText(Sales);
            holder.agreementTerms.setText(Terms);
        }

        /*for (int i = 0; i < agreementData.size(); i++) {
            if (i == 0) {
                Sales = agreementOutputList.get(position).getAgreementData().get(i).getName();
                SalesURL = agreementOutputList.get(position).getAgreementData().get(i).getUrl();
            } else {
                Terms = agreementOutputList.get(position).getAgreementData().get(i).getName();
                TermsURL = agreementOutputList.get(position).getAgreementData().get(i).getUrl();
            }
        }
        holder.agreementSales.setText(Sales);
        holder.agreementTerms.setText(Terms);*/


    }

    @Override
    public int getItemCount() {

        return agreementOutputList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        //Declaring views
        LinearLayout agreementsSalesClick, agreementTermsClick;
        private TextView agreementDate, agreementSales, agreementTerms;

        public ViewHolder(View view) {
            super(view);
            //view.setOnClickListener(this);

            //Initialising views
            agreementsSalesClick=view.findViewById(R.id.ll_profileHomeFragment_agreementsSalesClick);
            agreementTermsClick=view.findViewById(R.id.ll_profileHomeFragment_agreementTermsClick);
            agreementDate = view.findViewById(R.id.tv_profileAgreementList_date);
            agreementSales = view.findViewById(R.id.txt_agreementsSalesAsociateText);
            agreementTerms = view.findViewById(R.id.txt_agreementsTermsText);

            agreementsSalesClick.setOnClickListener(this);
            agreementTermsClick.setOnClickListener(this);
        }


        @Override
        public void onClick(View view) {

            switch (view.getId()){

                case R.id.ll_profileHomeFragment_agreementsSalesClick:

                    Intent intent=new Intent(context,ProfileAgreementsDetailActivity.class);
                    intent.putExtra("selectedAgreement",SalesURL);
                    context.startActivity(intent);

                    break;

                case R.id.ll_profileHomeFragment_agreementTermsClick:

                    Intent intent2=new Intent(context,ProfileAgreementsDetailActivity.class);
                    intent2.putExtra("selectedAgreement",TermsURL);
                    context.startActivity(intent2);

                    break;
            }




            /*int clickPosition = getLayoutPosition();
            Gson gson = new Gson();
            AgreementOutput agreementOutput = agreementOutputList.get(clickPosition);

            //Converting to string
            String agreementItemString = gson.toJson(agreementOutput);

            //Preparing Intent
            Intent agreementDetailsIntent = new Intent(view.getContext(), ProfileAgreementsDetailActivity.class);

            //Create the bundle
            Bundle agreementDetailBundle = new Bundle();

            //Add your data to bundle
            agreementDetailBundle.putString("selectedAgreement",agreementItemString);

            //Add the bundle to the intent
            agreementDetailsIntent.putExtras(agreementDetailBundle);

            view.getContext().startActivity(agreementDetailsIntent);*/

        }

    }

}