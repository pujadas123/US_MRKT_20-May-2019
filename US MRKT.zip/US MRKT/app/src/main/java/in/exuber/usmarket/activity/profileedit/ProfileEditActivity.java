package in.exuber.usmarket.activity.profileedit;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.rilixtech.CountryCodePicker;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import in.exuber.usmarket.R;
import in.exuber.usmarket.activity.homeaddproducts.HomeAddProductsActivity;
import in.exuber.usmarket.activity.leadsedit.LeadsEditActivity;
import in.exuber.usmarket.activity.paymentinfo.Payment_Info_Activity;
import in.exuber.usmarket.activity.productedit.ProductEditActivity;
import in.exuber.usmarket.apimodels.editlead.editleadinput.EditLeadInput;
import in.exuber.usmarket.apimodels.editprofile.EditProfileInput;
import in.exuber.usmarket.apimodels.editprofile.EditProfileOutput;
import in.exuber.usmarket.apimodels.editprofile.UpdatedBy;
import in.exuber.usmarket.apimodels.login.loginoutput.LoginOutput;
import in.exuber.usmarket.apimodels.login.loginoutput.MobileLang;
import in.exuber.usmarket.libraries.circularimageview.CircleImageView;
import in.exuber.usmarket.models.ProfilePicModel.ProfileImageModel;
import in.exuber.usmarket.models.language.LanguagePreferenceModel;
import in.exuber.usmarket.models.user.UserOutput;
import in.exuber.usmarket.utils.Api;
import in.exuber.usmarket.utils.Config;
import in.exuber.usmarket.utils.ConnectionDetector;
import in.exuber.usmarket.utils.Constants;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static in.exuber.usmarket.utils.UtilMethods.bitmapToFile;
import static in.exuber.usmarket.utils.UtilMethods.getLanguageLabelPreference;
import static in.exuber.usmarket.utils.UtilMethods.hideKeyBoard;
import static in.exuber.usmarket.utils.UtilMethods.isValidEmail;

public class ProfileEditActivity extends AppCompatActivity implements View.OnClickListener {

    //Declaring views
    private LinearLayout profileEditActivityContainer;
    private TextView toolbarHeader, toolbarHeaderDone;

    LinearLayout ll_toolbarHeaderDone;

    private CircleImageView userImage;
    private RelativeLayout userImageClick;

    private EditText firstName, lastName, email, phoneNumber, whatsappNumber, facebookMessenger, password, confirmPassword;
    private RadioButton englishLanguageSelect, spanishLanguageSelect;
    private CountryCodePicker phoneCodePicker,whatsAppCodePicker;
    private TextView firstNameError, lastNameError, emailError, phoneNumberError, whatsappNumberError, facebookMessengerError, prefLanguangeError, passwordError, confirmPasswordError;

    private EditText addressOne, addressTwo, aptUnit, city, state, postalCode;
    private TextView addressOneError, addressTwoError, aptUnitError, cityError, stateError, postalCodeError, countryRegionError;

    private CountryCodePicker countryPicker;

    RadioGroup radiogrp;

    private Bitmap imageForUpload;
    private String captured_image;
    private File file;
    ProgressDialog pd;
    String url;
    private static final int  PERMISSIONS_REQUEST_ACCOUNTS = 1090;
    private static OkHttpClient.Builder builder;

    private static final int SELECT_SINGLE_PICTURE = 101;

    private static final int SELECT_MULTIPLE_PICTURE = 201;

    public static final String IMAGE_TYPE = "image/*";

    //Sharedpreferences
    private SharedPreferences marketPreference;
    SharedPreferences.Editor preferenceEditor;

    //Connection detector class
    private ConnectionDetector connectionDetector;

    //Declaring variables
    private UserOutput userOutput;
    private boolean isEnglishSelected = false, isSpanishSelected = false;

    String Language;
    String noInternet="No Internet Connection";
    String ServerError="Can't connect Server! Error";
    String SomethingWrong="Something went wrong!";
    String ProfileUpdatedSuccessfully="Profile Updated Successfully";
    TextView firstNameText, lastNameText, emailText, phoneNumberText, WhatsAppText, FacebookText, preferredLanguage, passwordText, confirmPasswordText,AddressText,
            addressOneText, addressTwoText, aptUnitText, cityText, stateText, postalCodeText,countryRegionText;
    //Declaring variables
    private LoginOutput editProfileOutputs=new LoginOutput();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_edit);

        //Hiding keyboard
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        //Initialising shared preferences
        marketPreference =  getSharedPreferences(Constants.PREFERENCE_NAME,MODE_PRIVATE);
        preferenceEditor=marketPreference.edit();
        preferenceEditor.apply();

        //Initialising connection detector
        connectionDetector = new ConnectionDetector(this);


        //Setting Toolbar
        Toolbar toolbar = findViewById(R.id.main_toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_back_primary);

        //Initialising views
        profileEditActivityContainer = findViewById(R.id.activity_profile_edit);
        toolbarHeader = findViewById(R.id.tv_main_toolBar_headerText);
        //toolbarHeader.setText("PROFILE");

        ll_toolbarHeaderDone=findViewById(R.id.ll_main_toolBar_actionClick);
        toolbarHeaderDone=findViewById(R.id.iv_main_toolBar_actionText);
        ll_toolbarHeaderDone.setOnClickListener(this);

        //toolbarHeaderDone.setText(getResources().getString(R.string.done));


        userImage = findViewById(R.id.iv_profileEdit_userImage);
        userImage.setOnClickListener(this);
        userImageClick = findViewById(R.id.rl_profileEdit_userImageClick);

        firstName = findViewById(R.id.et_profileEdit_firstName);
        lastName = findViewById(R.id.et_profileEdit_lastName);
        email = findViewById(R.id.et_profileEdit_email);
        phoneNumber = findViewById(R.id.et_profileEdit_phoneNumber);
        whatsappNumber = findViewById(R.id.et_profileEdit_whatsappNumber);
        facebookMessenger = findViewById(R.id.et_profileEdit_facebookMessenger);
        password = findViewById(R.id.et_profileEdit_password);
        confirmPassword = findViewById(R.id.et_profileEdit_confirmPassword);

        phoneCodePicker = findViewById(R.id.cpp_profileEdit_phoneNumberPicker);
        whatsAppCodePicker = findViewById(R.id.cpp_profileEdit_whatsappNumberPicker);

        radiogrp=findViewById(R.id.radiogrp);

        englishLanguageSelect = findViewById(R.id.cb_profileEdit_languageEnglish);
        spanishLanguageSelect = findViewById(R.id.cb_profileEdit_languageSpanish);

        firstNameError = findViewById(R.id.tv_profileEdit_firstNameError);
        lastNameError = findViewById(R.id.tv_profileEdit_lastNameError);
        emailError = findViewById(R.id.tv_profileEdit_emailError);
        phoneNumberError = findViewById(R.id.tv_profileEdit_phoneNumberError);
        whatsappNumberError = findViewById(R.id.tv_profileEdit_whatsappNumberError);
        facebookMessengerError = findViewById(R.id.tv_profileEdit_facebookMessengerError);
        prefLanguangeError = findViewById(R.id.tv_profileEdit_prefLanguageError);
        passwordError = findViewById(R.id.tv_profileEdit_passwordError);
        confirmPasswordError = findViewById(R.id.tv_profileEdit_confirmPasswordError);

        addressOne = findViewById(R.id.et_profileEdit_addressOne);
        addressTwo = findViewById(R.id.et_profileEdit_addressTwo);
        aptUnit = findViewById(R.id.et_profileEdit_aptUnit);
        city = findViewById(R.id.et_profileEdit_city);
        state = findViewById(R.id.et_profileEdit_state);
        postalCode = findViewById(R.id.et_profileEdit_postalCode);

        countryPicker = findViewById(R.id.cpp_profileEdit_countryRegion);

        addressOneError = findViewById(R.id.tv_profileEdit_addressOneError);
        addressTwoError = findViewById(R.id.tv_profileEdit_addressTwoError);
        aptUnitError = findViewById(R.id.tv_profileEdit_aptUnitError);
        cityError = findViewById(R.id.tv_profileEdit_cityError);
        stateError = findViewById(R.id.tv_profileEdit_stateError);
        postalCodeError = findViewById(R.id.tv_profileEdit_postalCodeError);
        countryRegionError = findViewById(R.id.tv_profileEdit_countryRegionError);

        //Labels
        firstNameText = findViewById(R.id.txt_profileEdit_firstName);
        lastNameText = findViewById(R.id.txt_profileEdit_lastName);
        emailText = findViewById(R.id.txt_profileEdit_email);
        phoneNumberText = findViewById(R.id.txt_profileEdit_phoneNumber);
        WhatsAppText = findViewById(R.id.txt_profileEdit_WhatsAppNumbetText);
        FacebookText = findViewById(R.id.txt_profileEdit_facebookText);
        preferredLanguage=findViewById(R.id.txt_profileEdit_preferredLanguage);
        passwordText = findViewById(R.id.txt_profileEdit_password);
        confirmPasswordText = findViewById(R.id.txt_profileEdit_confirmPassword);
        AddressText=findViewById(R.id.txt_profileEdit_Address);
        addressOneText = findViewById(R.id.txt_profileEdit_addressOne);
        addressTwoText = findViewById(R.id.txt_profileEdit_addressTwo);
        aptUnitText = findViewById(R.id.txt_profileEdit_aptUnit);
        cityText = findViewById(R.id.txt_profileEdit_city);
        stateText = findViewById(R.id.txt_profileEdit_state);
        postalCodeText = findViewById(R.id.txt_profileEdit_postalCode);
        countryRegionText=findViewById(R.id.txt_profileEdit_countryRegion);

        //Hiding views
        firstNameError.setVisibility(View.GONE);
        lastNameError.setVisibility(View.GONE);
        emailError.setVisibility(View.GONE);
        phoneNumberError.setVisibility(View.GONE);
        whatsappNumberError.setVisibility(View.GONE);
        facebookMessengerError.setVisibility(View.GONE);
        prefLanguangeError.setVisibility(View.GONE);
        passwordError.setVisibility(View.GONE);
        confirmPasswordError.setVisibility(View.GONE);

        addressOneError.setVisibility(View.GONE);
        addressTwoError.setVisibility(View.GONE);
        aptUnitError.setVisibility(View.GONE);
        cityError.setVisibility(View.GONE);
        stateError.setVisibility(View.GONE);
        postalCodeError.setVisibility(View.GONE);
        countryRegionError.setVisibility(View.GONE);

        //Registering validation
        phoneCodePicker.registerPhoneNumberTextView(phoneNumber);
        whatsAppCodePicker.registerPhoneNumberTextView(whatsappNumber);





        //Setting values
        firstName.setText(marketPreference.getString("userName", ""));
        lastName.setText(marketPreference.getString("userLastName", ""));
        email.setText(marketPreference.getString("email", ""));

        Log.e("Code",marketPreference.getString("code", ""));
        try {
            phoneCodePicker.setCountryForPhoneCode(Integer.parseInt(marketPreference.getString("phoneNoCode", "")));
            phoneCodePicker.setCountryForNameCode(marketPreference.getString("flagCodeName", ""));

            whatsAppCodePicker.setCountryForPhoneCode(Integer.parseInt(marketPreference.getString("WhatsappCode", "")));
            whatsAppCodePicker.setCountryForNameCode(marketPreference.getString("WhatsappFlag", ""));
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        phoneNumber.setText(marketPreference.getString("phoneNo", ""));
        whatsappNumber.setText(marketPreference.getString("WhatsappNumber", ""));

        facebookMessenger.setText(marketPreference.getString("FacebookId", ""));

        password.setText(marketPreference.getString("password", ""));
        confirmPassword.setText(marketPreference.getString("password", ""));

        addressOne.setText(marketPreference.getString("streetaddress1", ""));
        addressTwo.setText(marketPreference.getString("streetaddress2", ""));
        aptUnit.setText(marketPreference.getString("Unit", ""));
        city.setText(marketPreference.getString("City", ""));
        state.setText(marketPreference.getString("State", ""));
        postalCode.setText(marketPreference.getString("PostalCode", ""));
        countryPicker.setCountryForNameCode(marketPreference.getString("Country", ""));

        Log.e("Country profile edit",marketPreference.getString("Country", ""));

        Log.e("Language",marketPreference.getString("prefLanguage", ""));

        /*Language=marketPreference.getString("prefLanguage", "");

        if (Language.equals("English")){
            radiogrp.check(R.id.cb_profileEdit_languageEnglish);
        }*/

        radiogrp.clearCheck();
        if (marketPreference.getString("prefLanguage", "").equals("1")){
            radiogrp.check(R.id.cb_profileEdit_languageEnglish);
            //englishLanguageSelect.setSelected(true);
            Log.e("Language","1");
        }
        if (marketPreference.getString("prefLanguage", "").equals("2")){
            radiogrp.check(R.id.cb_profileEdit_languageSpanish);
            //spanishLanguageSelect.setChecked(true);
            Log.e("Language","2");
        }



        englishLanguageSelect.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                                                             @Override
                                                             public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                                                                 if (isChecked)
                                                                 {
                                                                     isEnglishSelected = true;

                                                                 }
                                                                 else {
                                                                     isEnglishSelected = false;
                                                                 }

                                                             }

                                                         }
        );

        spanishLanguageSelect.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                                                             @Override
                                                             public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                                                                 if (isChecked)
                                                                 {
                                                                     isSpanishSelected = true;

                                                                 }
                                                                 else {
                                                                     isSpanishSelected = false;
                                                                 }

                                                             }

                                                         }
        );

        /*isEnglishSelected = userOutput.isEnglishSelected();
        isSpanishSelected = userOutput.isSpanishSelected();*/

        /*englishLanguageSelect.setChecked(isEnglishSelected);
        spanishLanguageSelect.setChecked(isSpanishSelected);*/

        //phoneCodePicker.setCountryForNameCode(userOutput.getCountryCode());
        //countryPicker.setCountryForNameCode(userOutput.getCountryCode());


        /////////////Profile Image.....................

        url=marketPreference.getString("userProfilePic","");

        if (url == null)
        {

            userImage.setImageResource(R.drawable.user_profile);

        }
        else
        {
            if (url.isEmpty())
            {
                userImage.setImageResource(R.drawable.user_profile);

            }
            else
            {
                Picasso.get()
                        .load(url)
                        .placeholder(R.drawable.user_profile)
                        .error(R.drawable.user_profile)
                        .into(userImage);

            }
        }

        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileEditActivity.this);

        pd=new ProgressDialog(ProfileEditActivity.this);
        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1143")) {
                pd.setMessage(languageLabelModelList.get(index).getValue()+"...");
            }
        }
        //pd.setMessage("Please Wait...");
        pd.setCancelable(true);
        pd.setIndeterminate(false);
        pd.setCancelable(false);

        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1176")) {
                toolbarHeader.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1134")) {
                toolbarHeaderDone.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1182")) {
                firstNameText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1404")) {
                firstName.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1183")) {
                lastNameText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1406")) {
                lastName.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1167")) {
                emailText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1433")) {
                phoneNumberText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1420")) {
                phoneNumber.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1503")) {
                WhatsAppText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1504")) {
                whatsappNumber.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1505")) {
                facebookMessenger.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1184")) {
                preferredLanguage.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1185")) {
                passwordText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1472")) {
                password.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1186")) {
                confirmPasswordText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1186")) {
                confirmPassword.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1470")) {
                AddressText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1429")) {
                addressOneText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1452")) {
                addressOne.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1430")) {
                addressTwoText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1453")) {
                addressTwo.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1431")) {
                aptUnitText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1454")) {
                aptUnit.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1191")) {
                cityText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1455")) {
                city.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1192")) {
                stateText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1456")) {
                state.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1193")) {
                postalCodeText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1457")) {
                postalCode.setHint(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1432")) {
                countryRegionText.setText(languageLabelModelList.get(index).getValue());
            }
        }


    }

    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_done, menu);
        return true;
    }*/

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return (super.onOptionsItemSelected(menuItem));
    }


    /*@Override
    public void onBackPressed() {

        finish();

    }*/


    //Func - Validating text fields
    private boolean validateTextFields(String firstNameText, String lastNameText, String emailText, String phoneNumberText, String whatsAppNumberText, String facebookMessengerText, String passwordText, String confirmPasswordText,
                                       String addressOneText, String addressTwoText, String aptUnitText, String cityText, String stateText, String postalCodeText) {

        boolean validFlag = true;

        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileEditActivity.this);

        //Registering validation
        phoneCodePicker.registerPhoneNumberTextView(phoneNumber);
        whatsAppCodePicker.registerPhoneNumberTextView(whatsappNumber);


        if (postalCodeText.isEmpty()) {

            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1465")) {
                    postalCodeError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //postalCodeError.setText(getString(R.string.error_postal_code_empty));
            postalCodeError.setVisibility(View.VISIBLE);
            postalCode.requestFocus();
            validFlag = false;

        }

        if (stateText.isEmpty()) {

            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1464")) {
                    stateError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //stateError.setText(getString(R.string.error_state_empty));
            stateError.setVisibility(View.VISIBLE);
            state.requestFocus();
            validFlag = false;

        }


        if (cityText.isEmpty()) {

            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1463")) {
                    cityError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //cityError.setText(getString(R.string.error_city_empty));
            cityError.setVisibility(View.VISIBLE);
            city.requestFocus();
            validFlag = false;

        }


        if (addressOneText.isEmpty()) {

            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1461")) {
                    addressOneError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //addressOneError.setText(getString(R.string.error_address_empty));
            addressOneError.setVisibility(View.VISIBLE);
            addressOne.requestFocus();
            validFlag = false;

        }


        if (confirmPasswordText.isEmpty()) {

            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1473")) {
                    confirmPasswordError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //confirmPasswordError.setText(getString(R.string.error_confirm_password_empty));
            confirmPasswordError.setVisibility(View.VISIBLE);
            confirmPassword.requestFocus();
            validFlag = false;

        }

        if (passwordText.isEmpty()) {
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1474")) {
                    passwordError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //passwordError.setText(getString(R.string.error_password_empty));
            passwordError.setVisibility(View.VISIBLE);
            password.requestFocus();
            validFlag = false;

        }

        if (validFlag)
        {
            if (!confirmPasswordText.equals(passwordText))
            {
                for (int index = 0; index<languageLabelModelList.size();index++) {
                    if (languageLabelModelList.get(index).getLangCode().equals("1475")) {
                        confirmPasswordError.setText(languageLabelModelList.get(index).getValue());
                    }
                }
                //confirmPasswordError.setText(getString(R.string.error_confirm_password_mismatch));
                confirmPasswordError.setVisibility(View.VISIBLE);
                confirmPassword.requestFocus();
                validFlag = false;
            }

        }

        /*if (!isEnglishSelected && !isSpanishSelected) {

            prefLanguangeError.setText(getString(R.string.error_pref_language_empty));
            prefLanguangeError.setVisibility(View.VISIBLE);
            validFlag = false;

        }*/


        if (facebookMessengerText.isEmpty()) {

            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1508")) {
                    facebookMessengerError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //facebookMessengerError.setText(getString(R.string.error_facebook_messenger_empty));
            facebookMessengerError.setVisibility(View.VISIBLE);
            facebookMessenger.requestFocus();
            validFlag = false;

        }

        if (whatsAppNumberText.isEmpty()) {

            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1506")) {
                    whatsappNumberError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //whatsappNumberError.setText(getString(R.string.error_whatsapp_number_empty));
            whatsappNumberError.setVisibility(View.VISIBLE);
            whatsappNumber.requestFocus();

            validFlag = false;

        } else {

            if (!whatsAppCodePicker.isValid()) {
                for (int index = 0; index<languageLabelModelList.size();index++) {
                    if (languageLabelModelList.get(index).getLangCode().equals("1507")) {
                        whatsappNumberError.setText(languageLabelModelList.get(index).getValue());
                    }
                }
                //whatsappNumberError.setText(getString(R.string.error_whatsapp_number_invalid));
                whatsappNumberError.setVisibility(View.VISIBLE);
                whatsappNumber.requestFocus();

                validFlag = false;
            }
        }


        if (phoneNumberText.isEmpty()) {

            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1412")) {
                    phoneNumberError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //phoneNumberError.setText(getString(R.string.error_phone_number_empty));
            phoneNumberError.setVisibility(View.VISIBLE);
            phoneNumber.requestFocus();

            validFlag = false;

        }
        else
        {

            if (!phoneCodePicker.isValid()) {
                for (int index = 0; index<languageLabelModelList.size();index++) {
                    if (languageLabelModelList.get(index).getLangCode().equals("1413")) {
                        phoneNumberError.setText(languageLabelModelList.get(index).getValue());
                    }
                }
                //phoneNumberError.setText(getString(R.string.error_phone_number_invalid));
                phoneNumberError.setVisibility(View.VISIBLE);
                phoneNumber.requestFocus();

                validFlag = false;
            }
        }

        if (passwordText.length()<6) {
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1472")) {
                    passwordError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //passwordError.setText(getString(R.string.password_placeholder));
            passwordError.setVisibility(View.VISIBLE);
            password.requestFocus();
            validFlag = false;
        }

        if (passwordText.length()>=10) {
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1472")) {
                    passwordError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //passwordError.setText(getString(R.string.password_placeholder));
            passwordError.setVisibility(View.VISIBLE);
            password.requestFocus();
            validFlag = false;
        }

        if (phoneNumberText.length()<10)
        {
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1413")) {
                    phoneNumberError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //phoneNumberError.setText(getString(R.string.error_phone_number_invalid));
            phoneNumberError.setVisibility(View.VISIBLE);
            phoneNumber.requestFocus();

            validFlag = false;
        }

        if (phoneNumberText.length()>=11)
        {
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1413")) {
                    phoneNumberError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //phoneNumberError.setText(getString(R.string.error_phone_number_invalid));
            phoneNumberError.setVisibility(View.VISIBLE);
            phoneNumber.requestFocus();

            validFlag = false;
        }

        /*else
        {

            if (!phoneCodePicker.isValid())
            {
                phoneNumberError.setText(getString(R.string.error_phone_number_invalid));
                phoneNumberError.setVisibility(View.VISIBLE);
                phoneNumber.requestFocus();

                validFlag = false;
            }
        }*/


        if (emailText.isEmpty()) {

            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1410")) {
                    emailError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //emailError.setText(getString(R.string.error_email_empty));
            emailError.setVisibility(View.VISIBLE);
            email.requestFocus();

            validFlag = false;

        }
        else
        {
            if (!isValidEmail(emailText))
            {
                for (int index = 0; index<languageLabelModelList.size();index++) {
                    if (languageLabelModelList.get(index).getLangCode().equals("1411")) {
                        emailError.setText(languageLabelModelList.get(index).getValue());
                    }
                }
                //emailError.setText(getString(R.string.error_email_invalid));
                emailError.setVisibility(View.VISIBLE);
                email.requestFocus();

                validFlag = false;
            }
        }


        if (lastNameText.isEmpty()) {

            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1405")) {
                    lastNameError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //lastNameError.setText(getString(R.string.error_last_name_empty));
            lastNameError.setVisibility(View.VISIBLE);
            lastName.requestFocus();
            validFlag = false;

        }

        if (firstNameText.isEmpty()) {

            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1403")) {
                    firstNameError.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //firstNameError.setText(getString(R.string.error_first_name_empty));
            firstNameError.setVisibility(View.VISIBLE);
            firstName.requestFocus();
            validFlag = false;

        }

        return validFlag;
    }


    //Func - Update Profile
    private void updateProfile(String firstNameText, String lastNameText, String emailText, String phoneNumberText, String whatsAppNumberText,
                               String facebookMessengerText, String passwordText, String confirmPasswordText, String addressOneText,
                               String addressTwoText, String aptUnitText, String cityText, String stateText, String postalCodeText) {

        boolean isInternetPresent = connectionDetector.isConnectingToInternet();

        if (isInternetPresent) {

            callUpdateProfileService(firstNameText,lastNameText,emailText,phoneNumberText, whatsAppNumberText, facebookMessengerText,passwordText,confirmPasswordText,
                    addressOneText,addressTwoText,aptUnitText,cityText,stateText,postalCodeText);

        }
        else
        {
            List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileEditActivity.this);
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1340")) {
                    noInternet=languageLabelModelList.get(index).getValue();
                }
            }
            Snackbar snackbar = Snackbar
                    .make(profileEditActivityContainer, noInternet, Snackbar.LENGTH_LONG);

            snackbar.show();
        }
    }

    //Service - Update Profile
    private void callUpdateProfileService(String firstNameText, String lastNameText, String emailText, String phoneNumberText,
                                          String whatsAppNumberText, String facebookMessengerText, String passwordText, String confirmPasswordText,
                                          String addressOneText, String addressTwoText, String aptUnitText, String cityText, String stateText,
                                          String postalCodeText) {

        //Showing loading
        pd.show();

        String accessTokenId = marketPreference.getString(Constants.LOGIN_ACCESSTOKEN_ID, null);
        final String userId = marketPreference.getString(Constants.LOGIN_USER_ID, null);
        String roleId = marketPreference.getString(Constants.LOGIN_ROLE_ID, null);



        UpdatedBy updatedBy=new UpdatedBy();
        updatedBy.setUserId(userId);

        final EditProfileInput editProfileInput = new EditProfileInput();

        editProfileInput.setUpdatedBy(updatedBy);
        editProfileInput.setId(marketPreference.getString("userserialid",null));
        editProfileInput.setName(firstNameText);
        editProfileInput.setLastName(lastNameText);
        editProfileInput.setEmail(emailText);
        editProfileInput.setFlagCode(phoneCodePicker.getSelectedCountryNameCode());
        editProfileInput.setPhoneNo(phoneNumberText);
        editProfileInput.setCode(phoneCodePicker.getSelectedCountryCodeWithPlus());
        editProfileInput.setWhatsappFlag(whatsAppCodePicker.getSelectedCountryNameCode());
        editProfileInput.setWhatsappCode(whatsAppCodePicker.getSelectedCountryCodeWithPlus());
        editProfileInput.setWhatsappNumber(whatsAppNumberText);
        editProfileInput.setFacebookId(facebookMessengerText);
        editProfileInput.setPassword(passwordText);
        editProfileInput.setAddress1(addressOneText);
        editProfileInput.setAddress2(addressTwoText);
        editProfileInput.setUnit(aptUnitText);
        editProfileInput.setCity(cityText);
        editProfileInput.setState(stateText);
        editProfileInput.setPostalCode(postalCodeText);
        editProfileInput.setCountry(countryPicker.getSelectedCountryNameCode());
        String lang = null;
        if (isEnglishSelected)
        {
            lang = "1";
        }
        if (isSpanishSelected)
        {
            if (isEnglishSelected)
            {
                lang = lang+",2";
            }
            else
            {
                lang = "2";
            }

        }
        editProfileInput.setPrefLanguage(lang);


        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Config.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        final Api api = retrofit.create(Api.class);

        Call<LoginOutput> call = (Call<LoginOutput>) api.editProfile(accessTokenId,
                userId,
                roleId,
                Constants.APP_UPDATE_PROFILE_SERVICENAME,
                editProfileInput);
        call.enqueue(new Callback<LoginOutput>() {
            @Override
            public void onResponse(Call<LoginOutput> call, Response<LoginOutput> response) {

                //Checking for response code
                if (response.code() == 200 ) {

                    LoginOutput loginOutput=response.body();

                    Gson gson = new Gson();
                    String loginItemString = gson.toJson(loginOutput);
                    preferenceEditor.putString(Constants.LOGIN_RESPONSE, loginItemString);

                    preferenceEditor.putString("userid",loginOutput.getData().getUserId());
                    preferenceEditor.putString("userserialid",loginOutput.getData().getId().toString());
                    preferenceEditor.putString("userName",loginOutput.getData().getName());
                    preferenceEditor.putString("userLastName",loginOutput.getData().getLastName());

                    preferenceEditor.putString("email", loginOutput.getData().getEmail());
                    preferenceEditor.putString("flagCodeName",loginOutput.getData().getFlagCode());
                    preferenceEditor.putString("phoneNoCode",loginOutput.getData().getCode());
                    preferenceEditor.putString("phoneNo",loginOutput.getData().getPhoneNo());

                    preferenceEditor.putString("WhatsappFlag",loginOutput.getData().getWhatsappFlag());
                    preferenceEditor.putString("WhatsappCode",loginOutput.getData().getWhatsappCode());
                    preferenceEditor.putString("WhatsappNumber",loginOutput.getData().getWhatsappNumber());
                    preferenceEditor.putString("FacebookId",loginOutput.getData().getFacebookId());

                    preferenceEditor.putString("prefLanguage",loginOutput.getData().getPrefLanguage());


                    preferenceEditor.putString("password", loginOutput.getData().getPassword());
                    preferenceEditor.putString("streetaddress1",loginOutput.getData().getAddress1());
                    preferenceEditor.putString("streetaddress2",loginOutput.getData().getAddress2());
                    preferenceEditor.putString("Unit",loginOutput.getData().getUnit());
                    preferenceEditor.putString("City",loginOutput.getData().getCity());
                    preferenceEditor.putString("State",loginOutput.getData().getState());
                    preferenceEditor.putString("PostalCode",loginOutput.getData().getPostalCode());
                    preferenceEditor.putString("Country",loginOutput.getData().getCountry());


                    preferenceEditor.commit();

                    Log.e("ll",loginOutput.getData().getPrefLanguage());

                    pd.dismiss();
                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileEditActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1471")) {
                            ProfileUpdatedSuccessfully=languageLabelModelList.get(index).getValue();
                        }
                    }
                    Toast.makeText(ProfileEditActivity.this, ProfileUpdatedSuccessfully, Toast.LENGTH_SHORT).show();
                    finish();
                }
                //If status code is not 200
                else
                {

                    //Dismiss loading
                    pd.dismiss();

                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileEditActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1341")) {
                            ServerError=languageLabelModelList.get(index).getValue() + ":" + response.code();
                        }
                    }
                    Snackbar snackbar = Snackbar
                            .make(profileEditActivityContainer, ServerError, Snackbar.LENGTH_LONG);

                    snackbar.show();

                }
            }

            @Override
            public void onFailure(Call<LoginOutput> call, Throwable t) {

                //Dismiss loading
                pd.dismiss();

                Log.e("Failure",t.toString());

                List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileEditActivity.this);
                for (int index = 0; index<languageLabelModelList.size();index++) {
                    if (languageLabelModelList.get(index).getLangCode().equals("1342")) {
                        SomethingWrong=languageLabelModelList.get(index).getValue();
                    }
                }
                Snackbar snackbar = Snackbar
                        .make(profileEditActivityContainer, SomethingWrong, Snackbar.LENGTH_LONG);

                snackbar.show();

            }

        });

    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.iv_profileEdit_userImage:

                //Hiding Keyboard
                hideKeyBoard(ProfileEditActivity.this);

                Log.e("Came","Click");

                //Checking permission Marshmallow
                if (Build.VERSION.SDK_INT >= 23) {

                    if (checkPermissionCameraGallery())
                    {
                        Log.e("Came","permission Granted");

                        final Dialog dialog = new Dialog(ProfileEditActivity.this);
                        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        dialog.setContentView(R.layout.chooser_dialouge);
                        LinearLayout CameraBtn = (LinearLayout) dialog.findViewById(R.id.ll_camera_parent);
                        LinearLayout GalleryBtn = (LinearLayout) dialog.findViewById(R.id.ll_gallery_parent);

                        TextView ChooseOptionsText=(TextView)dialog.findViewById(R.id.txt_ChooseOptionsText);
                        TextView camera_button=(TextView)dialog.findViewById(R.id.camera_button);
                        TextView gallery_button=(TextView)dialog.findViewById(R.id.gallery_button);

                        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileEditActivity.this);
                        for (int index = 0; index<languageLabelModelList.size();index++) {
                            if (languageLabelModelList.get(index).getLangCode().equals("1476")) {
                                ChooseOptionsText.setText(languageLabelModelList.get(index).getValue());
                            }
                            if (languageLabelModelList.get(index).getLangCode().equals("1477")) {
                                camera_button.setText(languageLabelModelList.get(index).getValue());
                            }
                            if (languageLabelModelList.get(index).getLangCode().equals("1478")) {
                                gallery_button.setText(languageLabelModelList.get(index).getValue());
                            }
                        }

                        CameraBtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();

                                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                startActivityForResult(cameraIntent, 1);


                            }

                        });

                        GalleryBtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();

                                /*Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                                intent.setType("image/*");
                                startActivityForResult(Intent.createChooser(intent, "Select File"), 2);*/
                                Intent i = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                                startActivityForResult(i, 2);
                            }
                        });

                        dialog.show();
                    } else {

                        //Request permission
                        requestPermissionCameraGallery();
                    }
                } else {

                    final Dialog dialog = new Dialog(ProfileEditActivity.this);
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    dialog.setContentView(R.layout.chooser_dialouge);
                    LinearLayout CameraBtn = (LinearLayout) dialog.findViewById(R.id.ll_camera_parent);
                    LinearLayout GalleryBtn = (LinearLayout) dialog.findViewById(R.id.ll_gallery_parent);

                    TextView ChooseOptionsText=(TextView)dialog.findViewById(R.id.txt_ChooseOptionsText);
                    TextView camera_button=(TextView)dialog.findViewById(R.id.camera_button);
                    TextView gallery_button=(TextView)dialog.findViewById(R.id.gallery_button);

                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileEditActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1476")) {
                            ChooseOptionsText.setText(languageLabelModelList.get(index).getValue());
                        }
                        if (languageLabelModelList.get(index).getLangCode().equals("1477")) {
                            camera_button.setText(languageLabelModelList.get(index).getValue());
                        }
                        if (languageLabelModelList.get(index).getLangCode().equals("1478")) {
                            gallery_button.setText(languageLabelModelList.get(index).getValue());
                        }
                    }

                    CameraBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                            Intent cameraIntent = new Intent("android.media.action.IMAGE_CAPTURE");
                            captured_image = System.currentTimeMillis() + ".jpg";
                            file = new File(Environment.getExternalStorageDirectory(), captured_image);
                            captured_image = file.getAbsolutePath();
                            Uri outputFileUri = Uri.fromFile(file);
                            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
                            startActivityForResult(cameraIntent, 1);
                        }

                    });

                    GalleryBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();

                            /*Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                            intent.setType("image/*");
                            startActivityForResult(Intent.createChooser(intent, "Select File"), 2);*/
                            Intent i = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                            startActivityForResult(i, 2);
                        }
                    });

                    dialog.show();

                }

                break;


            case R.id.ll_main_toolBar_actionClick:

                //Hiding Keyboard
                hideKeyBoard(ProfileEditActivity.this);

                //Hiding views
                firstNameError.setVisibility(View.GONE);
                lastNameError.setVisibility(View.GONE);
                emailError.setVisibility(View.GONE);
                phoneNumberError.setVisibility(View.GONE);
                whatsappNumberError.setVisibility(View.GONE);
                facebookMessengerError.setVisibility(View.GONE);
                prefLanguangeError.setVisibility(View.GONE);
                passwordError.setVisibility(View.GONE);
                confirmPasswordError.setVisibility(View.GONE);

                addressOneError.setVisibility(View.GONE);
                addressTwoError.setVisibility(View.GONE);
                aptUnitError.setVisibility(View.GONE);
                cityError.setVisibility(View.GONE);
                stateError.setVisibility(View.GONE);
                postalCodeError.setVisibility(View.GONE);
                countryRegionError.setVisibility(View.GONE);


                String firstNameText = firstName.getText().toString().trim();
                String lastNameText = lastName.getText().toString().trim();
                String emailText = email.getText().toString().trim();
                String phoneNumberText = phoneNumber.getText().toString().trim();
                String whatsAppNumberText = whatsappNumber.getText().toString().trim();
                String facebookMessengerText = facebookMessenger.getText().toString().trim();
                String passwordText = password.getText().toString().trim();
                String confirmPasswordText = confirmPassword.getText().toString().trim();


                String addressOneText = addressOne.getText().toString().trim();
                String addressTwoText = addressTwo.getText().toString().trim();
                String aptUnitText = aptUnit.getText().toString().trim();
                String cityText = city.getText().toString().trim();
                String stateText = state.getText().toString().trim();
                String postalCodeText = postalCode.getText().toString().trim();


                boolean validFlag = validateTextFields(firstNameText,lastNameText,emailText,phoneNumberText, whatsAppNumberText, facebookMessengerText,passwordText,confirmPasswordText,
                        addressOneText,addressTwoText,aptUnitText,cityText,stateText,postalCodeText);

                if (validFlag)
                {
                    updateProfile(firstNameText,lastNameText,emailText,phoneNumberText, whatsAppNumberText, facebookMessengerText,passwordText,confirmPasswordText,
                            addressOneText,addressTwoText,aptUnitText,cityText,stateText,postalCodeText);
                }

                break;
        }
    }


    //Func - Checking permission granted
    private boolean checkPermissionCameraGallery() {

        boolean isPermissionGranted = true;

        int permissionCAMERA = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        int permissionSTORAGE = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);

        if (permissionCAMERA != PackageManager.PERMISSION_GRANTED)
        {
            Log.e("Permission Camera",isPermissionGranted+"");

            isPermissionGranted = false;
        }
        if (permissionSTORAGE != PackageManager.PERMISSION_GRANTED) {

            Log.e("Permission Camera",isPermissionGranted+"");

            isPermissionGranted = false;
        }


        return isPermissionGranted;
    }

    //Func - Requesting permission
    private void requestPermissionCameraGallery() {

        List<String> listPermissionsNeeded = new ArrayList<>();
        listPermissionsNeeded.add(Manifest.permission.CAMERA);
        listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);

        ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), PERMISSIONS_REQUEST_ACCOUNTS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {

        switch (requestCode)
        {
            case PERMISSIONS_REQUEST_ACCOUNTS:

                boolean permissionCAMERA = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                boolean permissionSTORAGE = grantResults[1] == PackageManager.PERMISSION_GRANTED;


                if(permissionCAMERA && permissionSTORAGE)
                {
                    final Dialog dialog = new Dialog(ProfileEditActivity.this);
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    dialog.setContentView(R.layout.chooser_dialouge);
                    LinearLayout CameraBtn = (LinearLayout) dialog.findViewById(R.id.ll_camera_parent);
                    LinearLayout GalleryBtn = (LinearLayout) dialog.findViewById(R.id.ll_gallery_parent);

                    TextView ChooseOptionsText=(TextView)dialog.findViewById(R.id.txt_ChooseOptionsText);
                    TextView camera_button=(TextView)dialog.findViewById(R.id.camera_button);
                    TextView gallery_button=(TextView)dialog.findViewById(R.id.gallery_button);

                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileEditActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1476")) {
                            ChooseOptionsText.setText(languageLabelModelList.get(index).getValue());
                        }
                        if (languageLabelModelList.get(index).getLangCode().equals("1477")) {
                            camera_button.setText(languageLabelModelList.get(index).getValue());
                        }
                        if (languageLabelModelList.get(index).getLangCode().equals("1478")) {
                            gallery_button.setText(languageLabelModelList.get(index).getValue());
                        }
                    }

                    CameraBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                            startActivityForResult(cameraIntent, 1);


                        }

                    });

                    GalleryBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();

                            /*Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                            intent.setType("image/*");
                            startActivityForResult(Intent.createChooser(intent, "Select File"), 2);*/
                            Intent i = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                            startActivityForResult(i, 2);

                        }
                    });

                    dialog.show();
                }


                break;
        }
    }

    private void uploadImage(Bitmap bitmap) {

        //start
        pd.show();

        File fileimage = bitmapToFile(this, bitmap, true);

        RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), fileimage);
        MultipartBody.Part body = MultipartBody.Part.createFormData("file", fileimage.getName(), reqFile);

        RequestBody userIdBody = RequestBody.create(MediaType.parse("text/plain"),  String.valueOf(marketPreference.getString("userid", "")));


        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Constants.DOMAIN).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        Api api = retrofit.create(Api.class);

        Call<ProfileImageModel> call = (Call<ProfileImageModel>) api.uploadImage(
                body,
                userIdBody);
        call.enqueue(new Callback<ProfileImageModel>() {
            @Override
            public void onResponse(Call<ProfileImageModel> call, Response<ProfileImageModel> response) {

                Log.d("ProfileAPICHECK","ProfileCheck");

                // close
                pd.dismiss();
                ProfileImageModel uploadImageOutput = response.body();

                //Checking for response code
                if (response.code() == 200 ) {


                    String uploadImageUrl = uploadImageOutput.getPicId();

                    //es.remove("userProfilePic");

                    Log.e("Uploaded url",uploadImageUrl);

                    preferenceEditor.putString("userProfilePic",uploadImageUrl);
                    preferenceEditor.commit();

                    if (uploadImageUrl == null)
                    {

                        userImage.setImageResource(R.drawable.user_profile);

                    }
                    else
                    {
                        if (uploadImageUrl.isEmpty())
                        {
                            userImage.setImageResource(R.drawable.user_profile);

                        }
                        else
                        {
                            Picasso.get()
                                    .load(uploadImageUrl)
                                    .placeholder(R.drawable.user_profile)
                                    .error(R.drawable.user_profile)
                                    .into(userImage);

                        }
                    }
                }
                else
                {
                    Log.e("Uploaded url","yyy");
                }

            }

            @Override
            public void onFailure(Call<ProfileImageModel> call, Throwable t) {
                //close
                pd.dismiss();

                Log.e("pic","fail");

            }
        });
    }

    public OkHttpClient.Builder getHttpClient() {

        if (builder == null) {
            HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            OkHttpClient.Builder client = new OkHttpClient.Builder();
            client.addInterceptor(loggingInterceptor);
            client.writeTimeout(60000, TimeUnit.MILLISECONDS);
            client.readTimeout(60000, TimeUnit.MILLISECONDS);
            client.connectTimeout(60000, TimeUnit.MILLISECONDS);
            return client;
        }
        return builder;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1 && resultCode == this.RESULT_OK) {

            Bitmap capturedBitmap = (Bitmap) data.getExtras().get("data");
            /*Bitmap resizeBitmapImg = ShrinkBitmap(capturedBitmap, 300, 600);

            File capturedImageFile = convertBitmapToFile(resizeBitmapImg, this);
            uploadProfileImage(capturedImageFile, resizeBitmapImg);

            String imagePath = compressImage(captured_image);
            Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
            imageForUpload = bitmap;*/
            //ProfileImageApiCall();
            uploadImage(capturedBitmap);
            //profilePicIV.setImageBitmap(imageForUpload);
        }
        if (requestCode == 2 && resultCode == this.RESULT_OK) {
            /*Uri selectedImageUri = data.getData();
            String pathforcalculatesize = getRealPathFromURI(selectedImageUri);
            File file = new File(pathforcalculatesize);
            final String dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + Constants.CHAT_IMAGES_DIRECTORY;
            File fDir = new File(dir);
            if (!fDir.exists()) {
                fDir.mkdirs();
            }
            File f = new File(fDir, String.valueOf(System.currentTimeMillis()) + ".png");
            boolean fileCopied = copy(file, f);
            String imaptah = compressImage(f.getAbsolutePath());
            Bitmap bitmap = BitmapFactory.decodeFile(imaptah);
            imageForUpload = bitmap;
            //ProfileImageApiCall();
            uploadImage(bitmap);
            //profilePicIV.setImageBitmap(imageForUpload);
            f.delete();*/

            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };
            Cursor cursor = getContentResolver().query(selectedImage,filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();


            Bitmap bmp = BitmapFactory.decodeFile(picturePath);
            uploadImage(bmp);



        }

        /*-------*/

        /*if (resultCode == RESULT_OK) {
            if (requestCode == SELECT_SINGLE_PICTURE) {

                Uri selectedImageUri = data.getData();
                String pathforcalculatesize = getRealPathFromURI(selectedImageUri);
                File file = new File(pathforcalculatesize);
                final String dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + Constants.CHAT_IMAGES_DIRECTORY;
                File fDir = new File(dir);
                if (!fDir.exists()) {
                    fDir.mkdirs();
                }
                File f = new File(fDir, String.valueOf(System.currentTimeMillis()) + ".png");
                boolean fileCopied = copy(file, f);
                String imaptah = compressImage(f.getAbsolutePath());
                Bitmap bitmap = BitmapFactory.decodeFile(imaptah);
                imageForUpload = bitmap;
                //ProfileImageApiCall();
                uploadImage(bitmap);
                //profilePicIV.setImageBitmap(imageForUpload);
                f.delete();

                //Uri selectedImageUri = data.getData();
                try {
                    userImage.setImageBitmap(new UserPicture(selectedImageUri, getContentResolver()).getBitmap());
                } catch (IOException e) {
                    Log.e(ProfileEditActivity.class.getSimpleName(), "Failed to load image", e);
                }
                // original code
//                String selectedImagePath = getPath(selectedImageUri);
//                selectedImagePreview.setImageURI(selectedImageUri);
            }
        } else {
            // report failure
            Toast.makeText(getApplicationContext(), "Failed to get intent data", Toast.LENGTH_LONG).show();
            Log.d(ProfileEditActivity.class.getSimpleName(), "Failed to get intent data, result code is " + resultCode);
        }
*/

        /*--------*/

    }

    //Func - Upload Image
    private void uploadProfileImage(File capturedImageFile, Bitmap resizeBitmapImg) {

        //Checking internet connection
        boolean isInternetPresent = connectionDetector.isConnectingToInternet();

        if (isInternetPresent) {

            //Calling Service
            uploadImage(resizeBitmapImg);

        } else
        {

            List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileEditActivity.this);
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1340")) {
                    noInternet=languageLabelModelList.get(index).getValue();
                }
            }
            Snackbar snackbar = Snackbar
                    .make(profileEditActivityContainer, noInternet, Snackbar.LENGTH_LONG);

            snackbar.show();

        }
    }

    //Util - creating file
    public static File convertBitmapToFile(Bitmap bitmap, Activity context) {

        //Sharedpreferences
        SharedPreferences quotePreference =  context.getSharedPreferences(Constants.PREFERENCE_NAME,MODE_PRIVATE);
        String userId = quotePreference.getString(Constants.USER_ID, null);
        long millis = System.currentTimeMillis();

        String newCreatedFileName = "IMG" + userId + millis + ".png";


        File f = new File(context.getCacheDir(), newCreatedFileName);
        try {
            f.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //Convert bitmap to byte array
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0 /*ignored for PNG*/, bos);
        byte[] bitmapdata = bos.toByteArray();

        //write the bytes in file
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(f);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            fos.write(bitmapdata);
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return f;

    }

    public String compressImage(String filePath) {

//        String filePath = getRealPathFromURI(imageUri);
        Bitmap scaledBitmap = null;

        BitmapFactory.Options options = new BitmapFactory.Options();

//      by setting this field as true, the actual bitmap pixels are not loaded in the memory. Just the bounds are loaded. If
//      you try the use the bitmap here, you will get null.
        options.inJustDecodeBounds = true;
        Bitmap bmp = BitmapFactory.decodeFile(filePath, options);

        int actualHeight = options.outHeight;
        int actualWidth = options.outWidth;

//      max Height and width values of the compressed image is taken as 816x612

        float maxHeight = 816.0f;
        float maxWidth = 612.0f;
        float imgRatio = actualWidth / actualHeight;
        float maxRatio = maxWidth / maxHeight;

//      width and height values are set maintaining the aspect ratio of the image

        if (actualHeight > maxHeight || actualWidth > maxWidth) {
            if (imgRatio < maxRatio) {
                imgRatio = maxHeight / actualHeight;
                actualWidth = (int) (imgRatio * actualWidth);
                actualHeight = (int) maxHeight;
            } else if (imgRatio > maxRatio) {
                imgRatio = maxWidth / actualWidth;
                actualHeight = (int) (imgRatio * actualHeight);
                actualWidth = (int) maxWidth;
            } else {
                actualHeight = (int) maxHeight;
                actualWidth = (int) maxWidth;

            }
        }

//      setting inSampleSize value allows to load a scaled down version of the original image

        options.inSampleSize = calculateInSampleSize(options, actualWidth, actualHeight);

//      inJustDecodeBounds set to false to load the actual bitmap
        options.inJustDecodeBounds = false;

//      this options allow android to claim the bitmap memory if it runs low on memory
        options.inPurgeable = true;
        options.inInputShareable = true;
        options.inTempStorage = new byte[16 * 1024];

        try {
//          load the bitmap from its path
            bmp = BitmapFactory.decodeFile(filePath, options);
        } catch (OutOfMemoryError exception) {
            exception.printStackTrace();

        }
        try {
            scaledBitmap = Bitmap.createBitmap(actualWidth, actualHeight, Bitmap.Config.ARGB_8888);
        } catch (OutOfMemoryError exception) {
            exception.printStackTrace();
        }

        float ratioX = actualWidth / (float) options.outWidth;
        float ratioY = actualHeight / (float) options.outHeight;
        float middleX = actualWidth / 2.0f;
        float middleY = actualHeight / 2.0f;

        Matrix scaleMatrix = new Matrix();
        scaleMatrix.setScale(ratioX, ratioY, middleX, middleY);

        Canvas canvas = new Canvas(scaledBitmap);
        canvas.setMatrix(scaleMatrix);
        canvas.drawBitmap(bmp, middleX - bmp.getWidth() / 2, middleY - bmp.getHeight() / 2, new Paint(Paint.FILTER_BITMAP_FLAG));

//      check the rotation of the image and display it properly
        ExifInterface exif;
        try {
            exif = new ExifInterface(filePath);

            int orientation = exif.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, 0);
            Log.d("EXIF", "Exif: " + orientation);
            Matrix matrix = new Matrix();
            if (orientation == 6) {
                matrix.postRotate(90);
                Log.d("EXIF", "Exif: " + orientation);
            } else if (orientation == 3) {
                matrix.postRotate(180);
                Log.d("EXIF", "Exif: " + orientation);
            } else if (orientation == 8) {
                matrix.postRotate(270);
                Log.d("EXIF", "Exif: " + orientation);
            }
            scaledBitmap = Bitmap.createBitmap(scaledBitmap, 0, 0,
                    scaledBitmap.getWidth(), scaledBitmap.getHeight(), matrix,
                    true);
        } catch (IOException e) {
            e.printStackTrace();
        }

        FileOutputStream out = null;
        try {
            out = new FileOutputStream(filePath);

//          write the compressed bitmap at the destination specified by filename.
            scaledBitmap.compress(Bitmap.CompressFormat.PNG, 80, out);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return filePath;

    }

    private String getRealPathFromURI(Uri contentURI) {
        Cursor cursor = this.getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) {
            return contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            return cursor.getString(index);
        }
    }

    public boolean copy(File source, File target) {
        try {
            InputStream in = new FileInputStream(source);
            OutputStream out = new FileOutputStream(target);
            // Copy the bits from instream to outstream
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }

            in.close();
            out.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
        }
        final float totalPixels = width * height;
        final float totalReqPixelsCap = reqWidth * reqHeight * 2;
        while (totalPixels / (inSampleSize * inSampleSize) > totalReqPixelsCap) {
            inSampleSize++;
        }

        return inSampleSize;
    }

}
