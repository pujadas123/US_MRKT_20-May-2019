package in.exuber.usmarket.models.language;

import java.util.List;

import in.exuber.usmarket.apimodels.login.loginoutput.MobileLang;

public class LanguagePreferenceModel {

    private List<MobileLang> langCode;

    public List<MobileLang> getLangCode() {
        return langCode;
    }

    public void setLangCode(List<MobileLang> langCode) {
        this.langCode = langCode;
    }
}
