package in.exuber.usmarket.adapter.dialog;

import android.app.Activity;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import in.exuber.usmarket.R;
import in.exuber.usmarket.apimodels.category.categoryoutput.CategoryOutput;
import in.exuber.usmarket.dialog.AddLeadsInterestCategoriesFilterDialog;
import in.exuber.usmarket.dialog.AddLeadsLeadSourceFilterDialog;
import in.exuber.usmarket.models.categorylist.CategoryListOutput;


public class AddLeadsInterestCategoriesFilterListAdapter extends RecyclerView.Adapter<AddLeadsInterestCategoriesFilterListAdapter.ViewHolder> {

    //Declaring variables
    private Context context;
    private int selectedPosition;
    private List<CategoryOutput> filiterList;
    CategoryOutput selectedFilterCategory;

    //private List<String> filiterList;
    private AddLeadsInterestCategoriesFilterDialog addLeadsInterestCategoriesFilterDialog;


    public AddLeadsInterestCategoriesFilterListAdapter(Context context, List<CategoryOutput> filterDataList, CategoryOutput selectedFilterCategory, AddLeadsInterestCategoriesFilterDialog addLeadsInterestCategoriesFilterDialog) {

        this.context = context;
        this.filiterList = filterDataList;
        this.selectedFilterCategory = selectedFilterCategory;
        this.addLeadsInterestCategoriesFilterDialog = addLeadsInterestCategoriesFilterDialog;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_addleads_leadsourcefilter_listadapter, parent, false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {


        //Setting values
        holder.filterName.setText((CharSequence) filiterList.get(position));

        if (position == selectedPosition)
        {
            holder.filterParentLayout.setBackgroundColor(context.getResources().getColor(R.color.colorPrimary));
            holder.filterName.setTextColor(context.getResources().getColor(R.color.colorWhite));
        }
        else
        {
            holder.filterParentLayout.setBackgroundColor(context.getResources().getColor(R.color.colorWhite));
            holder.filterName.setTextColor(context.getResources().getColor(R.color.colorText));
        }



    }

    @Override
    public int getItemCount() {

        return filiterList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        //Declaring views
        private LinearLayout filterParentLayout;
        private TextView filterName;




        public ViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);

            filterParentLayout = view.findViewById(R.id.ll_addLeads_leadSourceFilterListAdapter_parentLayout);
            filterName = view.findViewById(R.id.tv_addLeads_leadSourceFilterListAdapter_filterName);

        }


        @Override
        public void onClick(View view) {

            int clickPosition = getLayoutPosition();

            addLeadsInterestCategoriesFilterDialog.setSelectedCategoryData(filiterList.get(clickPosition));



        }

    }

}