package in.exuber.usmarket.activity.profileagreements;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import in.exuber.usmarket.R;
import in.exuber.usmarket.adapter.AgreementListAdapter;
import in.exuber.usmarket.apimodels.agreements.agreementsoutput.AgreementOutput;
import in.exuber.usmarket.apimodels.login.loginoutput.MobileLang;
import in.exuber.usmarket.utils.Api;
import in.exuber.usmarket.utils.Config;
import in.exuber.usmarket.utils.ConnectionDetector;
import in.exuber.usmarket.utils.Constants;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static in.exuber.usmarket.utils.UtilMethods.getLanguageLabelPreference;
import static in.exuber.usmarket.utils.UtilMethods.hideKeyBoard;

public class ProfileAgreementsActivity extends AppCompatActivity implements View.OnClickListener {

    //Declaring views
    private LinearLayout profileAgreementsActivityContainer;
    private TextView toolbarHeader;
    private SwipeRefreshLayout swipeRefreshLayout_agreement;

    private RecyclerView agreementList;

    private LinearLayout progressDialog;
    private LinearLayout errorDisplay;

    private ImageView errorDisplayIcon;
    private TextView errorDisplayText;
    private TextView errorDisplayTryClick,progressPleaseWait;
    //Progress dialog
    private ProgressDialog progressDialogSecond;
    //Sharedpreferences
    private SharedPreferences marketPreference;

    //Connection detector class
    private ConnectionDetector connectionDetector;

    //Declaring Retrofit log
    private static OkHttpClient.Builder builder;

    //Declaring variables
    private List<AgreementOutput> agreementOutputList;

    //Adapter
    private AgreementListAdapter agreementListAdapter;

    String noInternet="No Internet Connection";
    String ServerError="Can't connect Server! Error";
    String SomethingWrong="Something went wrong!";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_agreements);

        //Hiding keyboard
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        //Initialising shared preferences
        marketPreference = getSharedPreferences(Constants.PREFERENCE_NAME, MODE_PRIVATE);

        //Initialising connection detector
        connectionDetector = new ConnectionDetector(this);

        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileAgreementsActivity.this);
        progressDialogSecond = new ProgressDialog(this);

        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1143")) {
                progressDialogSecond.setMessage(languageLabelModelList.get(index).getValue()+"...");
            }
        }
        //progressDialogSecond.setMessage(getString(R.string.loader_caption));
        progressDialogSecond.setCancelable(true);
        progressDialogSecond.setIndeterminate(false);
        progressDialogSecond.setCancelable(false);


        //Setting Toolbar
        Toolbar toolbar = findViewById(R.id.main_toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_back_primary);

        //Initialising variables
        agreementOutputList = new ArrayList<>();

        progressDialog =  findViewById(R.id.ll_custom_dialog);
        errorDisplay =  findViewById(R.id.ll_errorMain_layout);
        progressPleaseWait=findViewById(R.id.txt_pleaseWait);


        errorDisplayIcon = findViewById(R.id.iv_errorMain_errorIcon);
        errorDisplayText =  findViewById(R.id.tv_errorMain_errorText);
        errorDisplayTryClick =  findViewById(R.id.tv_errorMain_errorTryAgain);


        //Initialising views
        profileAgreementsActivityContainer = findViewById(R.id.activity_profile_agreements);
        toolbarHeader = findViewById(R.id.tv_main_toolBar_headerText);

        //Recyclerview
        agreementList = findViewById(R.id.rv_profileAgreements_agreementsList);
        agreementList.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManagerAgreements = new LinearLayoutManager(this);
        linearLayoutManagerAgreements.setOrientation(LinearLayoutManager.VERTICAL);
        agreementList.setLayoutManager(linearLayoutManagerAgreements);

        swipeRefreshLayout_agreement = findViewById(R.id.srl_agreement_pullToRefresh);
        swipeRefreshLayout_agreement.setColorSchemeResources(
                R.color.colorPrimary);

        //Setting toolbar header
        //toolbarHeader.setText(getResources().getString(R.string.agreements_caps));

        //Setting values
        setAdapterData();

        swipeRefreshLayout_agreement.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                //Get Notification
                setAdapterData();

                swipeRefreshLayout_agreement.setRefreshing(false);
            }
        });


        errorDisplayTryClick.setOnClickListener(this);

        for (int index = 0; index<languageLabelModelList.size();index++) {
            //Setting toolbar header
            if (languageLabelModelList.get(index).getLangCode().equals("1511")) {
                toolbarHeader.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1345")) {
                errorDisplayTryClick.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1143")) {
                progressPleaseWait.setText(languageLabelModelList.get(index).getValue());
            }
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_dummy, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                finish();
                break;

        }
        return (super.onOptionsItemSelected(menuItem));
    }

    @Override
    public void onBackPressed() {

        finish();

    }


    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.tv_errorMain_errorTryAgain:

                //Hiding Keyboard
                hideKeyBoard(ProfileAgreementsActivity.this);

                //Get Notification
                setAdapterData();

                break;

        }
    }


    //Func - Get Notification
    private void setAdapterData() {

        errorDisplayTryClick.setVisibility(View.VISIBLE);

        boolean isInternetPresent = connectionDetector.isConnectingToInternet();

        if (isInternetPresent) {


            errorDisplay.setVisibility(View.GONE);
            agreementList.setVisibility(View.GONE);

            progressDialog.setVisibility(View.VISIBLE);

            //Calling Service
            callGetAgreementsService();

        }
        else
        {
            //Hiding views
            progressDialog.setVisibility(View.GONE);
            agreementList.setVisibility(View.GONE);

            errorDisplay.setVisibility(View.VISIBLE);

            errorDisplayIcon.setImageResource(R.drawable.ic_error_internet);
            List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileAgreementsActivity.this);
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1340")) {
                    errorDisplayText.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //errorDisplayText.setText(getString(R.string.error_internet));
        }
    }



    //Func - Set Adapter Data
    private void callGetAgreementsService() {

        String accessTokenId = marketPreference.getString(Constants.LOGIN_ACCESSTOKEN_ID, null);
        final String userId = marketPreference.getString(Constants.LOGIN_USER_ID, null);
        String roleId = marketPreference.getString(Constants.LOGIN_ROLE_ID, null);

        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Config.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        final Api api = retrofit.create(Api.class);

        Call<List<AgreementOutput>> call = (Call<List<AgreementOutput>>) api.getAgreementByUserId(accessTokenId,
                userId,
                roleId,
                Constants.SERVICE_GET_AGREEMENTS,
                userId);
        call.enqueue(new Callback<List<AgreementOutput>>() {
            @Override
            public void onResponse(Call<List<AgreementOutput>> call, Response<List<AgreementOutput>> response) {

                //Checking for response code
                if (response.code() == 200 ) {

                    agreementOutputList = response.body();


                    if (agreementOutputList.size() == 0)
                    {
                        //Hiding views
                        progressDialog.setVisibility(View.GONE);
                        agreementList.setVisibility(View.GONE);

                        errorDisplay.setVisibility(View.VISIBLE);

                        errorDisplayIcon.setImageResource(R.drawable.ic_no_image);
                        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileAgreementsActivity.this);
                        for (int index = 0; index<languageLabelModelList.size();index++) {
                            if (languageLabelModelList.get(index).getLangCode().equals("1512")) {
                                errorDisplayText.setText(languageLabelModelList.get(index).getValue());
                            }
                        }
                        //errorDisplayText.setText(getString( R.string.error_no_data_agreements));
                        errorDisplayTryClick.setVisibility(View.GONE);



                    }
                    else {

                        //Hiding views
                        progressDialog.setVisibility(View.GONE);
                        errorDisplay.setVisibility(View.GONE);

                        agreementList.setVisibility(View.VISIBLE);

                        //Setting adapter
                        agreementListAdapter = new AgreementListAdapter(ProfileAgreementsActivity.this,agreementOutputList);
                        agreementList.setAdapter(agreementListAdapter);
                        agreementListAdapter.notifyDataSetChanged();
                    }


                }
                //If status code is not 200
                else
                {


                    progressDialog.setVisibility(View.GONE);
                    agreementList.setVisibility(View.GONE);


                    errorDisplay.setVisibility(View.VISIBLE);

                    errorDisplayIcon.setImageResource(R.drawable.ic_error_code);
                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileAgreementsActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1341")) {
                            errorDisplayText.setText(languageLabelModelList.get(index).getValue() + ":" + response.code());
                        }
                    }
                    //errorDisplayText.setText(getString(R.string.error_response_code) + response.code());

                }
            }

            @Override
            public void onFailure(Call<List<AgreementOutput>> call, Throwable t) {

                Log.e("Failure",t.toString());

                if (t instanceof IOException) {

                    //Hiding views
                    progressDialog.setVisibility(View.GONE);
                    agreementList.setVisibility(View.GONE);

                    errorDisplay.setVisibility(View.VISIBLE);

                    errorDisplayIcon.setImageResource(R.drawable.ic_no_image);
                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileAgreementsActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1512")) {
                            errorDisplayText.setText(languageLabelModelList.get(index).getValue());
                        }
                    }
                    //errorDisplayText.setText(getString( R.string.error_no_data_agreements));
                    errorDisplayTryClick.setVisibility(View.GONE);

                }
                else
                {
                    //Hiding views
                    progressDialog.setVisibility(View.GONE);
                    agreementList.setVisibility(View.GONE);


                    errorDisplay.setVisibility(View.VISIBLE);

                    errorDisplayIcon.setImageResource(R.drawable.ic_error_server);
                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(ProfileAgreementsActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1342")) {
                            errorDisplayText.setText(languageLabelModelList.get(index).getValue());
                        }
                    }
                    //errorDisplayText.setText(getString(R.string.error_server));
                }





            }

        });
    }

    //Retrofit log
    public OkHttpClient.Builder getHttpClient() {

        if (builder == null) {
            HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            OkHttpClient.Builder client = new OkHttpClient.Builder();
            client.addInterceptor(loggingInterceptor);
            client.writeTimeout(60000, TimeUnit.MILLISECONDS);
            client.readTimeout(60000, TimeUnit.MILLISECONDS);
            client.connectTimeout(60000, TimeUnit.MILLISECONDS);
            return client;
        }
        return builder;
    }

}
