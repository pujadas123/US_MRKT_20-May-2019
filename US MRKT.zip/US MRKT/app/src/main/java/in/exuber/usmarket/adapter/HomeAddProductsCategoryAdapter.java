package in.exuber.usmarket.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import in.exuber.usmarket.R;
import in.exuber.usmarket.activity.homeaddproducts.HomeAddProductsActivity;
import in.exuber.usmarket.apimodels.category.categoryoutput.CategoryOutput;


public class HomeAddProductsCategoryAdapter extends RecyclerView.Adapter<HomeAddProductsCategoryAdapter.MyViewHolder>{

    //Declaring variables
    private List<CategoryOutput> categoryOutputList;
    private Context context;


    public HomeAddProductsCategoryAdapter(Context context, List<CategoryOutput> categoryOutputList) {

        this.context = context;
        this.categoryOutputList = categoryOutputList;
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int i) {

        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_productaddcategory_listadapter,parent,false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {


        if (categoryOutputList.get(position).getName() == null)
        {
            holder.categoryName.setVisibility(View.INVISIBLE);
        }
        else
        {
            holder.categoryName.setText(categoryOutputList.get(position).getName());
            holder.categoryClick.setVisibility(View.VISIBLE);
        }

        String productImageUrl = String.valueOf(categoryOutputList.get(position).getUrl());

        if (categoryOutputList.get(position).getUrl() == null)
        {
            holder.categoryImage.setVisibility(View.INVISIBLE);
        }
        else
        {
            Picasso.get()
                    .load(productImageUrl.replace(" ","%20"))
                    .placeholder(R.drawable.ic_no_image)
                    .error(R.drawable.ic_no_image)
                    .into(holder.categoryImage);
            holder.categoryImage.setVisibility(View.VISIBLE);
        }

        if (categoryOutputList.get(position).isSelected())
        {
            holder.categoryClick.setBackgroundColor(context.getResources().getColor(R.color.colorPrimary));
        }
        else
        {
            holder.categoryClick.setBackgroundColor(context.getResources().getColor(R.color.colorLightGrey));
        }


    }

    @Override
    public int getItemCount() {
        return categoryOutputList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        //Declaring views
        private LinearLayout categoryClick;
        private ImageView categoryImage;
        private TextView categoryName;

        public MyViewHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);

            //Initailising views
            categoryClick = itemView.findViewById(R.id.ll_productAddCategoryListAdapter_categoryClick);
            categoryImage = itemView.findViewById(R.id.iv_productAddCategoryListAdapter_categoryIcon);
            categoryName = itemView.findViewById(R.id.tv_productAddCategoryListAdapter_categoryName);
        }

        @Override
        public void onClick(View view) {

            int clickPosition = getLayoutPosition();

            ((HomeAddProductsActivity)context).setCategorySelection(clickPosition);

        }
    }

    public void setCategoryOutputList(List<CategoryOutput> categoryOutputList) {
        this.categoryOutputList = categoryOutputList;
        notifyDataSetChanged();
    }
}
