package in.exuber.usmarket.utils;


public class Constants {

    //App Constants
    public static final String PREFERENCE_NAME = "us_market_preference_06_05_2019";

    public static final String IS_LOGGED_IN = "is_logged_in";

    public static final String IS_APPINTRO_OVER = "is_appintro_over";
    public static final String IS_PRODUCT_ADDED = "is_product_added";
    public static final String IS_SHOWCASE_SHOWN = "is_showcase_shown";


    public static final String IS_PRODUCT_DATA_CHANGED = "is_product_data_changed";
    public static final String IS_ACTIVE_LEAD_DATA_CHANGED = "is_active_lead_data_changed";
    public static final String IS_READY_LEAD_DATA_CHANGED = "is_ready_lead_data_changed";
    public static final String IS_CONVERTED_LEAD_DATA_CHANGED = "is_converted_lead_data_changed";

    public static final String IS_NOTIFICATION_CLICK = "is_notification_click";

    public static final String IS_REMEMBER_ME_SELECTED = "is_remember_me_selected";
    public static final String REMEMBER_ME_EMAIL = "remember_me_email";
    public static final String REMEMBER_ME_PASSWORD = "remember_me_password";

    public static final String LOGIN_DATA_STATUS = "ACTIVE";
    public static final String LOGIN_RESPONSE = "login_response";
    public static final String LOGIN_USER_ID = "login_user_id";
    public static final String LOGIN_ROLE_ID = "login_role_id";
    public static final String LOGIN_ACCESSTOKEN_ID = "login_access_token_id";

    public static final String SALES_ASSOCIATE_ROLE_ID = "38";

    public static  final String INTENT_KEY_SELECTED_PRODUCT = "selected_product";
    public static  final String INTENT_KEY_IS_USER_PRODUCT = "is_user_product";

    public static  final String INTENT_KEY_SELECTED_LEAD = "selected_lead";

    public static  final String INTENT_KEY_SELECTED_CAMPAIGN = "selected_campaign";
    public static  final String INTENT_KEY_SELECTED_VIDEO_URL = "selected_video_url";

    public static  final String INTENT_KEY_SELECTED_FILE_URL = "selected_file_url";

    public static  final String LEADSOURCE_SOCIAL_NETWORK_ID = "54";
    public static  final String LEADSOURCE_WEBSITE_ID = "25";
    public static  final String LEADSOURCE_EMAIL_ID = "26";
    public static  final String LEADSOURCE_PHONE_ID = "27";
    public static  final String LEADSOURCE_REFEREL_ID = "48";
    public static  final String LEADSOURCE_OTHER_ID = "49";

    public static  final String PRODUCT_CATEGORY_REALESTATE_ID = "1";
    public static  final String PRODUCT_CATEGORY_INVESTMENT_ID = "2";

    public static  final String SHARE_FACEBOOK_ID = "51";
    public static  final String SHARE_INSTAGRAM_ID = "29";
    public static  final String SHARE_TWITTER_ID = "30";
    public static  final String SHARE_WHATSAPP_ID = "50";

    public static  final String CAMPAIGN_LANGUAGE_ENGLISH_ID = "33";
    public static  final String CAMPAIGN_LANGUAGE_SPANISH_ID = "34";
    public static  final String CAMPAIGN_LANGUAGE_FRENCH_ID = "35";

    public static  final String TRAINING_PDF_ID = "20";
    public static  final String TRAINING_IMAGE_ID = "21";
    public static  final String TRAINING_VIDEO_ID = "22";
    public static  final String TRAINING_LINK_ID = "46";
    public static  final String TRAINING_ARTICLE_ID = "47";

    public static  final String NOTIFICATION_SEEN_STATUS = "SEEN";

    public static final String CUSTOM_TAB_PACKAGE_NAME = "com.android.chrome";


    //Service Names
    public static final String SERVICE_GET_PRODUCT_LIST = "getProductList";
    public static final String SERVICE_GET_PRODUCT_LIST_BY_USERID = "getUserProductByUserId";

    public static final String SERVICE_ADD_PRODUCT = "insertUserProduct";
    public static final String SERVICE_EDIT_PRODUCT = "updateUserProduct";

    public static final String SERVICE_GET_PRODUCT_TRAINING = "getTrainingByProductId";

    public static final String SERVICE_GET_ACTIVE_LEADS = "getLeadsBySA";
    public static final String SERVICE_GET_READY_LEADS = "getReadyLeads";
    public static final String SERVICE_GET_CONVERTED_LEADS = "getLeadsByCustomers";

    public static final String SERVICE_ADD_LEADS = "insertLeadsByCustomer";
    public static final String SERVICE_EDIT_LEADS = "updateCustomerLeads";

    public static final String SERVICE_GET_NEW_CAMPAIGNS = "getNewCompaign";
    public static final String SERVICE_GET_RANDOM_CAMPAIGNS = "getRandomCampaign";
    public static final String SERVICE_GET_EXISTING_CAMPAIGNS = "getExistingCompaign";
    public static final String SERVICE_GET_CAMPAIGNS_BY_PRODUCT_ID = "getCampaignByProductId";
    public static final String SERVICE_GET_SHARED_CAMPAIGNS = "getSharedCampaignByUser";
    public static final String SERVICE_AGREEMENT_RECOED_DATA = "getRecordsAgreementById";


    public static final String SERVICE_SHARE_CAMPAIGNS = "insertSharedCampaign";
    public static final String SERVICE_SHARE_CAMPAIGNS_LOGS = "getDataByCampAndUser";

    public static final String SERVICE_GET_CAMPAIGN_TRAINING = "getTrainingByCampaignId";

    public static final String SERVICE_GET_FAQ = "getFaq";
    public static final String SERVICE_GET_GLOSSARY = "getGlossary";

    public static final String SERVICE_GET_PAYMENT_INFO = "getPaymentInfoById";
    public static final String SERVICE_EDIT_PAYMENT_INFO = "insertPaymentInfo";

    public static final String SERVICE_GET_NOTIFICATIONS = "getNotify";
    public static final String SERVICE_UPDATE_NOTIFICATION_SEEN = "getNotify";

    public static final String SERVICE_GET_PAID_COMMISSIONS = "getSalesPaymentBySa";

    public static final String SERVICE_GET_CATEGORY = "getCategory";

    public static final String SERVICE_GET_AGREEMENTS = "getAgreementByRecepientId";


    ///Services..............
    public static String USER_ID = "user_id";

    public static final String DOMAIN = "http://usmrkt.us-east-2.elasticbeanstalk.com";


    /////Update Profile Service............
    public static final String APP_UPDATE_PROFILE_SERVICENAME ="updateUser";
    public static final String APP_UPDATE_PROFILE_LIST = DOMAIN + "/SuperAdmin/User/";


    ////Profile Get Data List Service.............
    public static final String APP_PROFILE_INFO_DISPLAY_SERVICE_NAME = "getReportData";
    public static final String APP_PROFILE_INFO_DISPLAY_API = DOMAIN + "/SuperAdmin/ReportData/";







}

