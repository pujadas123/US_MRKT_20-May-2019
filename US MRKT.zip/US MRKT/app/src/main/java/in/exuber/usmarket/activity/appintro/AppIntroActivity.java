package in.exuber.usmarket.activity.appintro;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.daimajia.slider.library.Indicators.PagerIndicator;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.Tricks.ViewPagerEx;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import in.exuber.usmarket.R;
import in.exuber.usmarket.activity.home.HomeActivity;
import in.exuber.usmarket.activity.homeaddproducts.HomeAddProductsActivity;
import in.exuber.usmarket.apimodels.login.loginoutput.MobileLang;
import in.exuber.usmarket.apimodels.upadateappintro.updateappintroinput.UpdateAppIntroInput;
import in.exuber.usmarket.utils.Api;
import in.exuber.usmarket.utils.Config;
import in.exuber.usmarket.utils.ConnectionDetector;
import in.exuber.usmarket.utils.Constants;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static in.exuber.usmarket.utils.UtilMethods.getLanguageLabelPreference;

public class AppIntroActivity extends AppCompatActivity implements  ViewPagerEx.OnPageChangeListener, View.OnClickListener {

    //declaring views
    private RelativeLayout appIntroActivityContainer;

    private SliderLayout appIntroSlider;
    private PagerIndicator appIntroIndicator;

    private TextView skipClick;

    //Sharedpreferences
    private SharedPreferences marketPreference;

    private ArrayList<Integer> sliderImageList;
    private ArrayList<String> sliderHeaderList;
    private ArrayList<String> sliderTextList;

    //Progress dialog
    private ProgressDialog progressDialog;

    //Declaring Retrofit log
    private static OkHttpClient.Builder builder;

    //Connection detector class
    private ConnectionDetector connectionDetector;

    String SELECTPRODUCTS="SELECT PRODUCTS";
    String SHARECAMPAIGNS="SHARE CAMPAIGNS";
    String ADDLEADS="ADD LEADS";
    String GETCOMMISSIONS="GET COMMISSIONS";
    String noInternet="No Internet Connection";
    String ServerError="Can't connect Server! Error";
    String SomethingWrong="Something went wrong!";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_intro);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        //Initialising shared preferences
        marketPreference = getSharedPreferences(Constants.PREFERENCE_NAME,MODE_PRIVATE);

        //Initialising connection detector
        connectionDetector = new ConnectionDetector(this);


        //Initialising progress dialog
        progressDialog = new ProgressDialog(this);
        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(AppIntroActivity.this);

        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1143")) {
                progressDialog.setMessage(languageLabelModelList.get(index).getValue()+"...");
            }
        }
        //progressDialog.setMessage(getString(R.string.loader_caption));
        progressDialog.setCancelable(true);
        progressDialog.setIndeterminate(false);
        progressDialog.setCancelable(false);

        //Initialising views
        appIntroActivityContainer = findViewById(R.id.activity_app_intro);
        appIntroSlider = findViewById(R.id.sl_appIntro_sliderLayout);
        appIntroIndicator = findViewById(R.id.pi_appIntro_pagerIndicator);
        skipClick = findViewById(R.id.tv_appIntro_skipClick);

        //Initialising Views
        sliderImageList = new ArrayList<>();
        sliderHeaderList = new ArrayList<>();
        sliderTextList = new ArrayList<>();

        //Setting values
        sliderImageList.add(R.drawable.appintro_slider_one);
        sliderImageList.add(R.drawable.appintro_slider_two);
        sliderImageList.add(R.drawable.appintro_slider_three);
        sliderImageList.add(R.drawable.appintro_slider_four);



        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1133")) {
                SELECTPRODUCTS=languageLabelModelList.get(index).getValue();
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1498")) {
                SHARECAMPAIGNS=languageLabelModelList.get(index).getValue();
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1499")) {
                ADDLEADS=languageLabelModelList.get(index).getValue();
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1450")) {
                GETCOMMISSIONS=languageLabelModelList.get(index).getValue();
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1234")) {
                skipClick.setText(languageLabelModelList.get(index).getValue());
            }
        }

        sliderHeaderList.add(SELECTPRODUCTS);
        sliderHeaderList.add(SHARECAMPAIGNS);
        sliderHeaderList.add(ADDLEADS);
        sliderHeaderList.add(GETCOMMISSIONS);

        sliderTextList.add(getString(R.string.slider_text_one));
        sliderTextList.add(getString(R.string.slider_text_two));
        sliderTextList.add(getString(R.string.slider_text_three));
        sliderTextList.add(getString(R.string.slider_text_four));




        for (int index = 0; index<4; index++)
        {

            AppIntroSliderView appSlider = new AppIntroSliderView(this,index);
            appIntroSlider.addSlider(appSlider);
        }
        appIntroSlider.setCustomIndicator(appIntroIndicator);
        appIntroSlider.addOnPageChangeListener(this);

        appIntroSlider.setCurrentPosition(0);
        skipClick.setVisibility(View.VISIBLE);


        //Setting onclick
        skipClick.setOnClickListener(this);

    }

    @Override
    public void onBackPressed() {

    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {

            case R.id.tv_appIntro_skipClick:

                //Update App Intro
                updateAppIntro();

                break;
        }

    }



    //Func - Done click Appintro
    public void appIntroFinished() {

        //Preference Editor
        SharedPreferences.Editor preferenceEditor = marketPreference.edit();

        preferenceEditor.putBoolean(Constants.IS_APPINTRO_OVER, true);
        preferenceEditor.apply();



        boolean isProductAdded = marketPreference.getBoolean(Constants.IS_PRODUCT_ADDED, false);

        if (isProductAdded)
        {
            //Calling Home activity
            startActivity(new Intent(AppIntroActivity.this, HomeActivity.class));
            finish();
        }
        else
        {
            //Calling Home Add product activity
            startActivity(new Intent(AppIntroActivity.this, HomeAddProductsActivity.class));
            finish();
        }


    }

    //Func - Update App Intro
    private void updateAppIntro() {

        boolean isInternetPresent = connectionDetector.isConnectingToInternet();

        if (isInternetPresent) {


            callUpdateAppIntroService();
        }
        else
        {
            List<MobileLang> languageLabelModelList = getLanguageLabelPreference(AppIntroActivity.this);
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1340")) {
                    noInternet=languageLabelModelList.get(index).getValue();
                }
            }
            Snackbar snackbar = Snackbar
                    .make(appIntroActivityContainer, noInternet, Snackbar.LENGTH_LONG);

            snackbar.show();
        }

    }



    public class AppIntroSliderView extends BaseSliderView {

        private int sliderPosition;

        public AppIntroSliderView(Context context, int sliderPosition) {
            super(context);

            this.sliderPosition = sliderPosition;
        }

        @Override
        public View getView() {

            View view = LayoutInflater.from(getContext()).inflate(R.layout.layout_appintro_slider,null);

            ImageView sliderImage = view.findViewById(R.id.iv_appIntroslider_sliderImage);
            TextView sliderHeader = view.findViewById(R.id.tv_appIntroslider_sliderHeader);
            TextView sliderText = view.findViewById(R.id.tv_appIntroslider_sliderText);
            LinearLayout getStartedClick = view.findViewById(R.id.ll_appIntroslider_getStartedClick);
            TextView getStartedText = view.findViewById(R.id.txt_getStartedText);

            List<MobileLang> languageLabelModelList = getLanguageLabelPreference(AppIntroActivity.this);
            for (int index = 0; index<languageLabelModelList.size();index++) {

                if (languageLabelModelList.get(index).getLangCode().equals("1235")) {
                    getStartedText.setText(languageLabelModelList.get(index).getValue());
                }
            }

            sliderImage.setImageResource(sliderImageList.get(sliderPosition));
            sliderHeader.setText(sliderHeaderList.get(sliderPosition));
            sliderText.setText(sliderTextList.get(sliderPosition));

            if (sliderPosition == 3)
            {
                getStartedClick.setVisibility(View.VISIBLE);
            }
            else
            {
                getStartedClick.setVisibility(View.INVISIBLE);
            }

            getStartedClick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    //Update App Intro
                    updateAppIntro();
                }
            });

            return view;
        }
    }




    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {





    }

    @Override
    public void onPageSelected(int position) {

        Log.e("Position Selected",position+"");

        if (position == 3)
        {
            skipClick.setVisibility(View.GONE);
        }
        else
        {
            skipClick.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }


    //Service - Update App Intro
    private void callUpdateAppIntroService() {

        //Showing loading
        progressDialog.show();

        String userId = marketPreference.getString(Constants.LOGIN_USER_ID, null);

        UpdateAppIntroInput updateAppIntroInput = new UpdateAppIntroInput(userId,"true");

        //Showing loading
        progressDialog.show();


        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Config.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        final Api api = retrofit.create(Api.class);

        Call<ResponseBody> call = (Call<ResponseBody>) api.updateAppIntro(updateAppIntroInput);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                //Checking for response code
                if (response.code() == 201 ) {


                    //Dismiss loading
                    progressDialog.dismiss();

                    appIntroFinished();


                }
                //If status code is not 201
                else
                {
                    //Dismiss loading
                    progressDialog.dismiss();

                    Snackbar snackbar = Snackbar
                            .make(appIntroActivityContainer, getString(R.string.error_response_code) + response.code(), Snackbar.LENGTH_LONG);

                    snackbar.show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

                //Dismiss loading
                progressDialog.dismiss();

                Log.e("Failure",t.toString());

                Snackbar snackbar = Snackbar
                        .make(appIntroActivityContainer, R.string.error_server, Snackbar.LENGTH_LONG);

                snackbar.show();

            }

        });

    }

    //Retrofit log
    public OkHttpClient.Builder getHttpClient() {

        if (builder == null) {
            HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            OkHttpClient.Builder client = new OkHttpClient.Builder();
            client.addInterceptor(loggingInterceptor);
            client.writeTimeout(600000, TimeUnit.MILLISECONDS);
            client.readTimeout(600000, TimeUnit.MILLISECONDS);
            client.connectTimeout(600000, TimeUnit.MILLISECONDS);
            return client;
        }
        return builder;
    }
}
