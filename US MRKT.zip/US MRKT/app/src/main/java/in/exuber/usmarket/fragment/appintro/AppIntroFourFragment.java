package in.exuber.usmarket.fragment.appintro;


import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;
import java.util.concurrent.TimeUnit;

import in.exuber.usmarket.R;
import in.exuber.usmarket.activity.appintro.AppIntroActivity;
import in.exuber.usmarket.activity.homeaddproducts.HomeAddProductsActivity;
import in.exuber.usmarket.apimodels.login.loginoutput.MobileLang;
import in.exuber.usmarket.apimodels.upadateappintro.updateappintroinput.UpdateAppIntroInput;
import in.exuber.usmarket.utils.Api;
import in.exuber.usmarket.utils.Config;
import in.exuber.usmarket.utils.ConnectionDetector;
import in.exuber.usmarket.utils.Constants;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.content.Context.MODE_PRIVATE;
import static in.exuber.usmarket.utils.UtilMethods.getLanguageLabelPreference;

/**
 * A simple {@link Fragment} subclass.
 */
public class AppIntroFourFragment extends Fragment implements View.OnClickListener {

    //Declaring variables
    private Context context;

    //Declaring views
    private RelativeLayout appIntroFourFragmentContainer;
    private LinearLayout getStartedClick;

    TextView headerGetCommissionText,iamReadyText;

    String noInternet="No Internet Connection";
    String ServerError="Can't connect Server! Error";
    String SomethingWrong="Something went wrong!";

    //Sharedpreferences
    private SharedPreferences marketPreference;

    ProgressDialog pd;

    //Connection detector class
    private ConnectionDetector connectionDetector;

    //Progress dialog
    private ProgressDialog progressDialog;

    //Declaring Retrofit log
    private static OkHttpClient.Builder builder;

    public AppIntroFourFragment() {
        // Required empty public constructor
    }

    @SuppressLint("ValidFragment")
    public AppIntroFourFragment(Context context) {

        this.context = context;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View appIntroFourView =  inflater.inflate(R.layout.fragment_app_intro_four, container, false);

        //Initialising shared preferences
        marketPreference =  getActivity().getSharedPreferences(Constants.PREFERENCE_NAME,MODE_PRIVATE);

        //Initialising connection detector
        connectionDetector = new ConnectionDetector(context);

        //Initialising progress dialog
        progressDialog = new ProgressDialog(getActivity());
        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());

        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1143")) {
                progressDialog.setMessage(languageLabelModelList.get(index).getValue()+"...");
            }
        }
        //progressDialog.setMessage(getString(R.string.loader_caption));
        progressDialog.setCancelable(true);
        progressDialog.setIndeterminate(false);
        progressDialog.setCancelable(false);



        //Initialising views
        appIntroFourFragmentContainer = appIntroFourView.findViewById(R.id.fragment_app_intro_four);
        getStartedClick = appIntroFourView.findViewById(R.id.ll_appIntroFourFragment_getStartedClick);

        headerGetCommissionText=appIntroFourView.findViewById(R.id.tv_appIntroFourFragment_sliderHeader);
        iamReadyText=appIntroFourView.findViewById(R.id.txt_appIntroFourFragment_getStarted);

        getStartedClick.setOnClickListener(this);

        for (int index = 0; index<languageLabelModelList.size();index++) {

            if (languageLabelModelList.get(index).getLangCode().equals("1235")) {
                iamReadyText.setText(languageLabelModelList.get(index).getValue());
            }
        }

        return appIntroFourView;
    }


    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.ll_appIntroFourFragment_getStartedClick:

                //Update App Intro
                updateAppIntro();

                break;
        }
    }

    //Func - Update App Intro
    private void updateAppIntro() {

        boolean isInternetPresent = connectionDetector.isConnectingToInternet();

        if (isInternetPresent) {


            callUpdateAppIntroService();
        }
        else
        {
            List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1340")) {
                    noInternet=languageLabelModelList.get(index).getValue();
                }
            }
            Snackbar snackbar = Snackbar
                    .make(appIntroFourFragmentContainer, noInternet, Snackbar.LENGTH_LONG);

            snackbar.show();
        }

    }

    //Service - Update App Intro
    private void callUpdateAppIntroService() {

        //Showing loading
        progressDialog.show();

        String userId = marketPreference.getString(Constants.LOGIN_USER_ID, null);

        UpdateAppIntroInput updateAppIntroInput = new UpdateAppIntroInput(userId,"true");

        //Showing loading
        progressDialog.show();


        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Config.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        final Api api = retrofit.create(Api.class);

        Call<ResponseBody> call = (Call<ResponseBody>) api.updateAppIntro(updateAppIntroInput);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                //Checking for response code
                if (response.code() == 201 ) {


                    //Dismiss loading
                    progressDialog.dismiss();

                    ((AppIntroActivity)getActivity()).appIntroFinished();


                }
                //If status code is not 201
                else
                {
                    //Dismiss loading
                    progressDialog.dismiss();

                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1341")) {
                            ServerError=languageLabelModelList.get(index).getValue() + ":" + response.code();
                        }
                    }
                    Snackbar snackbar = Snackbar
                            .make(appIntroFourFragmentContainer, ServerError, Snackbar.LENGTH_LONG);

                    snackbar.show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

                //Dismiss loading
                progressDialog.dismiss();

                Log.e("Failure",t.toString());

                List<MobileLang> languageLabelModelList = getLanguageLabelPreference(getActivity());
                for (int index = 0; index<languageLabelModelList.size();index++) {
                    if (languageLabelModelList.get(index).getLangCode().equals("1342")) {
                        SomethingWrong=languageLabelModelList.get(index).getValue();
                    }
                }
                Snackbar snackbar = Snackbar
                        .make(appIntroFourFragmentContainer, SomethingWrong, Snackbar.LENGTH_LONG);

                snackbar.show();

            }

        });
    }

    //Retrofit log
    public OkHttpClient.Builder getHttpClient() {

        if (builder == null) {
            HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            OkHttpClient.Builder client = new OkHttpClient.Builder();
            client.addInterceptor(loggingInterceptor);
            client.writeTimeout(600000, TimeUnit.MILLISECONDS);
            client.readTimeout(600000, TimeUnit.MILLISECONDS);
            client.connectTimeout(600000, TimeUnit.MILLISECONDS);
            return client;
        }
        return builder;
    }
}
