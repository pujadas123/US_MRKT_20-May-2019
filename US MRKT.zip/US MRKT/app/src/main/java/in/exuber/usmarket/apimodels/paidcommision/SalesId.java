
package in.exuber.usmarket.apimodels.paidcommision;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SalesId {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("salesId")
    @Expose
    private String salesId;
    @SerializedName("salesDate")
    @Expose
    private Object salesDate;
    @SerializedName("company")
    @Expose
    private Object company;
    @SerializedName("product")
    @Expose
    private Object product;
    @SerializedName("image")
    @Expose
    private Object image;
    @SerializedName("customer")
    @Expose
    private Object customer;
    @SerializedName("associateId")
    @Expose
    private Object associateId;
    @SerializedName("comments")
    @Expose
    private Object comments;
    @SerializedName("dataStatus")
    @Expose
    private Object dataStatus;
    @SerializedName("createdBy")
    @Expose
    private Object createdBy;
    @SerializedName("createdOn")
    @Expose
    private Object createdOn;
    @SerializedName("updatedBy")
    @Expose
    private Object updatedBy;
    @SerializedName("updatedOn")
    @Expose
    private Object updatedOn;
    @SerializedName("paymentInfo")
    @Expose
    private Object paymentInfo;
    @SerializedName("paymentList")
    @Expose
    private Object paymentList;
    @SerializedName("totalSales")
    @Expose
    private Integer totalSales;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSalesId() {
        return salesId;
    }

    public void setSalesId(String salesId) {
        this.salesId = salesId;
    }

    public Object getSalesDate() {
        return salesDate;
    }

    public void setSalesDate(Object salesDate) {
        this.salesDate = salesDate;
    }

    public Object getCompany() {
        return company;
    }

    public void setCompany(Object company) {
        this.company = company;
    }

    public Object getProduct() {
        return product;
    }

    public void setProduct(Object product) {
        this.product = product;
    }

    public Object getImage() {
        return image;
    }

    public void setImage(Object image) {
        this.image = image;
    }

    public Object getCustomer() {
        return customer;
    }

    public void setCustomer(Object customer) {
        this.customer = customer;
    }

    public Object getAssociateId() {
        return associateId;
    }

    public void setAssociateId(Object associateId) {
        this.associateId = associateId;
    }

    public Object getComments() {
        return comments;
    }

    public void setComments(Object comments) {
        this.comments = comments;
    }

    public Object getDataStatus() {
        return dataStatus;
    }

    public void setDataStatus(Object dataStatus) {
        this.dataStatus = dataStatus;
    }

    public Object getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Object createdBy) {
        this.createdBy = createdBy;
    }

    public Object getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Object createdOn) {
        this.createdOn = createdOn;
    }

    public Object getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(Object updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Object getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Object updatedOn) {
        this.updatedOn = updatedOn;
    }

    public Object getPaymentInfo() {
        return paymentInfo;
    }

    public void setPaymentInfo(Object paymentInfo) {
        this.paymentInfo = paymentInfo;
    }

    public Object getPaymentList() {
        return paymentList;
    }

    public void setPaymentList(Object paymentList) {
        this.paymentList = paymentList;
    }

    public Integer getTotalSales() {
        return totalSales;
    }

    public void setTotalSales(Integer totalSales) {
        this.totalSales = totalSales;
    }

}
