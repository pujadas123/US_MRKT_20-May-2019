package in.exuber.usmarket.activity.homeaddproducts;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.NestedScrollView;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import in.exuber.usmarket.R;
import in.exuber.usmarket.activity.home.HomeActivity;
import in.exuber.usmarket.activity.notification.NotificationActivity;
import in.exuber.usmarket.activity.productcampaigndetails.ProductCampaignDetailActivity;
import in.exuber.usmarket.activity.productdetail.ProductDetailActivity;
import in.exuber.usmarket.adapter.AddProductHomeListAdapter;
import in.exuber.usmarket.adapter.HomeAddProductsCategoryAdapter;
import in.exuber.usmarket.apimodels.addproduct.addproductinput.AddProductInput;
import in.exuber.usmarket.apimodels.addproduct.addproductinput.CreatedBy;
import in.exuber.usmarket.apimodels.addproduct.addproductinput.ProductId;
import in.exuber.usmarket.apimodels.addproduct.addproductinput.UserId;
import in.exuber.usmarket.apimodels.category.categoryoutput.CategoryOutput;
import in.exuber.usmarket.apimodels.login.loginoutput.MobileLang;
import in.exuber.usmarket.apimodels.product.productoutput.ProductOutput;
import in.exuber.usmarket.utils.Api;
import in.exuber.usmarket.utils.Config;
import in.exuber.usmarket.utils.ConnectionDetector;
import in.exuber.usmarket.utils.Constants;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static in.exuber.usmarket.utils.UtilMethods.getLanguageLabelPreference;
import static in.exuber.usmarket.utils.UtilMethods.hideKeyBoard;

public class HomeAddProductsActivity extends AppCompatActivity implements View.OnClickListener {

    //Declaring views
    private RelativeLayout homeAddProductsActivityContainer;
    private SwipeRefreshLayout swipeRefreshLayout_productList;

    private LinearLayout toolbarDoneClick;
    private RelativeLayout toolberNotificationClick;


    private SearchView productSearch;
    private RecyclerView productList;
    public RecyclerView categoryList;

    private NestedScrollView parentLayout;

    private LinearLayout progressDialog;
    private LinearLayout errorDisplay;

    private ImageView errorDisplayIcon;
    private TextView errorDisplayText;
    private TextView errorDisplayTryClick, headerText, doneText, categoriesText, productsText, progressPleaseWait;

    String noInternet="No Internet Connection";
    String ServerError="Can't connect Server! Error";
    String SomethingWrong="Something went wrong!";

    //Connection Detector
    private ConnectionDetector connectionDetector;

    //Sharedpreferences
    private SharedPreferences marketPreference;

    //Progress dialog
    private ProgressDialog progressDialogSecond;

    //Declaring Retrofit log
    private static OkHttpClient.Builder builder;


    //Declaring variables
    private List<ProductOutput> productOutputList;
    private List<ProductOutput> selectedProductOutputList;
    private List<CategoryOutput> categoryOutputList;
    private List<String> selectedCategoryIdList;



    //Adapter
    private AddProductHomeListAdapter addProductHomeListAdapter;
    private HomeAddProductsCategoryAdapter homeAddProductsCategoryAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_add_products);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        //Initialising connection detector
        connectionDetector = new ConnectionDetector(HomeAddProductsActivity.this);

        //Initialising shared preferences
        marketPreference =  getSharedPreferences(Constants.PREFERENCE_NAME,MODE_PRIVATE);

        //Initialising progress dialog
        progressDialogSecond = new ProgressDialog(this);
        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(HomeAddProductsActivity.this);

        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1143")) {
                progressDialogSecond.setMessage(languageLabelModelList.get(index).getValue()+"...");
            }
        }
        //progressDialogSecond.setMessage(getString(R.string.loader_caption));
        progressDialogSecond.setCancelable(true);
        progressDialogSecond.setIndeterminate(false);
        progressDialogSecond.setCancelable(false);




        //Setting Toolbar
        Toolbar toolbar = findViewById(R.id.homeAddProduct_toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);


        //Initialising variables
        productOutputList = new ArrayList<>();
        selectedProductOutputList = new ArrayList<>();
        categoryOutputList = new ArrayList<>();
        selectedCategoryIdList = new ArrayList<>();


        //Initialising views
        homeAddProductsActivityContainer = findViewById(R.id.activity_home_add_products);
        toolbarDoneClick = findViewById(R.id.ll_homeAddProduct_toolBar_doneClick);
        toolberNotificationClick=findViewById(R.id.rl_homeProfile_toolBar_notificationLayout);

        headerText=findViewById(R.id.tv_homeProduct_toolBar_headerText);
        doneText=findViewById(R.id.txt_homeAddProduct_toolBar_done);
        categoriesText=findViewById(R.id.txt_homeAddProducts_categories);
        productsText=findViewById(R.id.txt_homeAddProducts_products);

        progressPleaseWait=findViewById(R.id.txt_pleaseWait);

        parentLayout = findViewById(R.id.nsv_homeAddProducts_parentlayout);
        productSearch = findViewById(R.id.et_homeAddProducts_search);



        //Recyclerview
        productList = findViewById(R.id.rv_homeAddProducts_productList);
        productList.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManagerProducts = new LinearLayoutManager(this);
        linearLayoutManagerProducts.setOrientation(LinearLayoutManager.VERTICAL);
        productList.setLayoutManager(linearLayoutManagerProducts);

        categoryList = findViewById(R.id.rv_homeAddProducts_categoryList);
        categoryList.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManagerCategory = new LinearLayoutManager(this);
        linearLayoutManagerCategory.setOrientation(LinearLayoutManager.HORIZONTAL);
        categoryList.setLayoutManager(linearLayoutManagerCategory);

        ///Swipe Refresh Layout
        swipeRefreshLayout_productList = findViewById(R.id.srl_homeAddProducts_pullToRefresh);
        swipeRefreshLayout_productList.setColorSchemeResources(
                R.color.colorPrimary);

        progressDialog =  findViewById(R.id.ll_custom_dialog);
        errorDisplay =  findViewById(R.id.ll_errorMain_layout);


        errorDisplayIcon = findViewById(R.id.iv_errorMain_errorIcon);
        errorDisplayText =  findViewById(R.id.tv_errorMain_errorText);
        errorDisplayTryClick =  findViewById(R.id.tv_errorMain_errorTryAgain);


        addProductHomeListAdapter = new AddProductHomeListAdapter(HomeAddProductsActivity.this,productOutputList);
        productList.setAdapter(addProductHomeListAdapter);
        addProductHomeListAdapter.notifyDataSetChanged();

        boolean isShowcaseShown = marketPreference.getBoolean(Constants.IS_SHOWCASE_SHOWN, false);

        if (isShowcaseShown)
        {


        }
        else
        {

            final Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setCancelable(false);
            dialog.setContentView(R.layout.dialog_select_product);

            LinearLayout showcaseGetStartedClick = dialog.findViewById(R.id.ll_homeAddProducts_getStartedClick);

            TextView txt_oneMoreDetail=dialog.findViewById(R.id.txt_oneMoreDetail);
            TextView txt_inFo=dialog.findViewById(R.id.txt_inFo);
            TextView txt_getStarted=dialog.findViewById(R.id.txt_getStarted);


            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1236")) {
                    txt_oneMoreDetail.setText(languageLabelModelList.get(index).getValue()+"!");
                }
                if (languageLabelModelList.get(index).getLangCode().equals("1237")) {
                    txt_inFo.setText(languageLabelModelList.get(index).getValue()+".");
                }
                if (languageLabelModelList.get(index).getLangCode().equals("1238")) {
                    txt_getStarted.setText(languageLabelModelList.get(index).getValue());
                }
                if (languageLabelModelList.get(index).getLangCode().equals("1345")) {
                    errorDisplayTryClick.setText(languageLabelModelList.get(index).getValue());
                }
            }


            showcaseGetStartedClick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    //Hiding Keyboard
                    hideKeyBoard(HomeAddProductsActivity.this);

                    SharedPreferences.Editor preferenceEditor = marketPreference.edit();

                    //Preference Editor
                    preferenceEditor.putBoolean(Constants.IS_SHOWCASE_SHOWN, true);
                    preferenceEditor.commit();

                    dialog.dismiss();
                }
            });

            dialog.show();


        }

        //Get Category
        getCategory();



        productSearch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String product) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {

                if (addProductHomeListAdapter != null)
                {
                    addProductHomeListAdapter.getFilter().filter(query.toLowerCase());
                }
                return false;
            }
        });

        swipeRefreshLayout_productList.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                //Get Category
                getCategory();


                swipeRefreshLayout_productList.setRefreshing(false);
            }
        });



        //Setting onclick
        toolbarDoneClick.setOnClickListener(this);
        toolberNotificationClick.setOnClickListener(this);
        errorDisplayTryClick.setOnClickListener(this);


    }


    @Override
    protected void onResume() {
        super.onResume();

        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(HomeAddProductsActivity.this);

        for (int index = 0; index<languageLabelModelList.size();index++) {
            if (languageLabelModelList.get(index).getLangCode().equals("1133")) {
                headerText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1134")) {
                doneText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1132")) {
                productSearch.setQueryHint(languageLabelModelList.get(index).getValue()+"...");
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1138")) {
                categoriesText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1129")) {
                productsText.setText(languageLabelModelList.get(index).getValue());
            }
            if (languageLabelModelList.get(index).getLangCode().equals("1143")) {
                progressPleaseWait.setText(languageLabelModelList.get(index).getValue());
            }
        }
    }

    @Override
    public void onBackPressed() {

        boolean isShowcaseShown = marketPreference.getBoolean(Constants.IS_SHOWCASE_SHOWN, false);

        if (isShowcaseShown)
        {
            finish();
        }


    }



    @Override
    public void onClick(View view) {

        SharedPreferences.Editor preferenceEditor = marketPreference.edit();

        switch (view.getId())
        {


            case R.id.ll_homeAddProduct_toolBar_doneClick:

                //Hiding Keyboard
                hideKeyBoard(HomeAddProductsActivity.this);

                selectedProductOutputList.clear();
                List<ProductOutput> selectedProductTempOutputList = addProductHomeListAdapter.getFilteredProductOutputList();

                for (int index = 0; index< selectedProductTempOutputList.size();index++)
                {
                    if (selectedProductTempOutputList.get(index).isSelected())
                    {
                        selectedProductOutputList.add(selectedProductTempOutputList.get(index));
                    }
                }

                Log.e("Selected Size", selectedProductOutputList.size()+"");

                if (selectedProductOutputList.size() == 0)
                {
                    //Preference Editor
                    preferenceEditor.putBoolean(Constants.IS_PRODUCT_ADDED, true);

                    preferenceEditor.commit();

                    //Going to Home Activity
                    startActivity(new Intent(HomeAddProductsActivity.this, HomeActivity.class));
                    finish();


                }
                else
                {

                    //Adding Product
                    addProduct();

                }




                break;

            case R.id.rl_homeProfile_toolBar_notificationLayout:

                //Hiding Keyboard
                hideKeyBoard(HomeAddProductsActivity.this);

                startActivity(new Intent(HomeAddProductsActivity.this, NotificationActivity.class));


                break;

            case R.id.tv_errorMain_errorTryAgain:

                //Hiding Keyboard
                hideKeyBoard(HomeAddProductsActivity.this);

                //Get Category
                getCategory();



                break;


        }

    }

    //Func - Getting Product
    private void filterProductData() {


        if (selectedCategoryIdList.size() == 0)
        {
            addProductHomeListAdapter = new AddProductHomeListAdapter(HomeAddProductsActivity.this,productOutputList);
            productList.setAdapter(addProductHomeListAdapter);
            addProductHomeListAdapter.notifyDataSetChanged();

        }
        else if (selectedCategoryIdList.size() == categoryOutputList.size())
        {

            addProductHomeListAdapter = new AddProductHomeListAdapter(HomeAddProductsActivity.this,productOutputList);
            productList.setAdapter(addProductHomeListAdapter);
            addProductHomeListAdapter.notifyDataSetChanged();
        }
        else
        {
            List<ProductOutput> filteredProductOutputList  = new ArrayList<>();

            for (int i=0;i<productOutputList.size();i++)
            {
                if (productOutputList.get(i).getProductCategory() != null)
                {
                    if (selectedCategoryIdList.contains(productOutputList.get(i).getProductCategory().getId()))
                    {
                        filteredProductOutputList.add(productOutputList.get(i));
                    }
                }
            }

            addProductHomeListAdapter = new AddProductHomeListAdapter(HomeAddProductsActivity.this,filteredProductOutputList);
            productList.setAdapter(addProductHomeListAdapter);
            addProductHomeListAdapter.notifyDataSetChanged();
        }


    }

    //Func - Category Selection
    public void setCategorySelection(int clickPosition) {

        CategoryOutput categoryOutput = categoryOutputList.get(clickPosition);

        if (categoryOutput.isSelected())
        {
            categoryOutput.setSelected(false);

            selectedCategoryIdList.remove(categoryOutput.getId());
        }
        else
        {
            categoryOutput.setSelected(true);

            selectedCategoryIdList.add(categoryOutput.getId());

        }

        categoryOutputList.set(clickPosition,categoryOutput);
        homeAddProductsCategoryAdapter.setCategoryOutputList(categoryOutputList);

        Log.e("Selected Count", selectedCategoryIdList.size()+"");

        filterProductData();

    }


    //Func - Getting Category
    private void getCategory() {

        errorDisplayTryClick.setVisibility(View.VISIBLE);
        categoryOutputList.clear();
        selectedCategoryIdList.clear();


        boolean isInternetPresent = connectionDetector.isConnectingToInternet();

        if (isInternetPresent) {

            errorDisplay.setVisibility(View.GONE);
            parentLayout.setVisibility(View.GONE);

            progressDialog.setVisibility(View.VISIBLE);


            //Calling Service
            callCategoryService();

        }
        else
        {
            //Hiding views
            progressDialog.setVisibility(View.GONE);
            parentLayout.setVisibility(View.GONE);

            errorDisplay.setVisibility(View.VISIBLE);

            errorDisplayIcon.setImageResource(R.drawable.ic_error_internet);
            List<MobileLang> languageLabelModelList = getLanguageLabelPreference(HomeAddProductsActivity.this);
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1340")) {
                    errorDisplayText.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //errorDisplayText.setText(getString(R.string.error_internet));
        }
    }


    //Func - Getting Product
    private void getProduct() {

        errorDisplayTryClick.setVisibility(View.VISIBLE);


        boolean isInternetPresent = connectionDetector.isConnectingToInternet();

        if (isInternetPresent) {

            errorDisplay.setVisibility(View.GONE);
            parentLayout.setVisibility(View.GONE);

            progressDialog.setVisibility(View.VISIBLE);


            //Calling Service
            callGetProductService();

        }
        else
        {
            //Hiding views
            progressDialog.setVisibility(View.GONE);
            parentLayout.setVisibility(View.GONE);

            errorDisplay.setVisibility(View.VISIBLE);

            errorDisplayIcon.setImageResource(R.drawable.ic_error_internet);
            List<MobileLang> languageLabelModelList = getLanguageLabelPreference(HomeAddProductsActivity.this);
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1340")) {
                    errorDisplayText.setText(languageLabelModelList.get(index).getValue());
                }
            }
            //errorDisplayText.setText(getString(R.string.error_internet));
        }
    }

    //Func - Add Product
    private void addProduct() {

        boolean isInternetPresent = connectionDetector.isConnectingToInternet();

        if (isInternetPresent) {

            //Calling Service
            callAddProductService();

        }
        else
        {
            List<MobileLang> languageLabelModelList = getLanguageLabelPreference(HomeAddProductsActivity.this);
            for (int index = 0; index<languageLabelModelList.size();index++) {
                if (languageLabelModelList.get(index).getLangCode().equals("1340")) {
                    noInternet=languageLabelModelList.get(index).getValue();
                }
            }
            Snackbar snackbar = Snackbar
                    .make(homeAddProductsActivityContainer, noInternet, Snackbar.LENGTH_LONG);

            snackbar.show();
        }
    }

    //Service - Getting Category
    private void callCategoryService() {



        String accessTokenId = marketPreference.getString(Constants.LOGIN_ACCESSTOKEN_ID, null);
        final String userId = marketPreference.getString(Constants.LOGIN_USER_ID, null);
        String roleId = marketPreference.getString(Constants.LOGIN_ROLE_ID, null);

        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Config.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        final Api api = retrofit.create(Api.class);

        Call<List<CategoryOutput>> call = (Call<List<CategoryOutput>>) api.getCategory(accessTokenId,
                userId,
                roleId,
                Constants.SERVICE_GET_CATEGORY);
        call.enqueue(new Callback<List<CategoryOutput>>() {
            @Override
            public void onResponse(Call<List<CategoryOutput>> call, Response<List<CategoryOutput>> response) {


                //Checking for response code
                if (response.code() == 200 ) {


                    List<CategoryOutput> categoryOutputListResponse = response.body();


                    for (int index = 0; index<categoryOutputListResponse.size();index++)
                    {

                        CategoryOutput categoryOutput = categoryOutputListResponse.get(index);
                        categoryOutputList.add(categoryOutput);
                    }

                    Log.e("Category Size",categoryOutputList.size()+"");

                    //Getting Products
                    getProduct();


                }
                //If status code is not 200
                else
                {

                    progressDialog.setVisibility(View.GONE);
                    parentLayout.setVisibility(View.GONE);


                    errorDisplay.setVisibility(View.VISIBLE);

                    errorDisplayIcon.setImageResource(R.drawable.ic_error_code);
                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(HomeAddProductsActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1341")) {
                            errorDisplayText.setText(languageLabelModelList.get(index).getValue() + ":" + response.code());
                        }
                    }
                    //errorDisplayText.setText(getString(R.string.error_response_code) + response.code());

                }
            }

            @Override
            public void onFailure(Call<List<CategoryOutput>> call, Throwable t) {

                Log.e("Failure",t.toString());

                if (t instanceof IOException) {


                    //Getting Products
                    getProduct();
                }
                else
                {
                    //Hiding views
                    progressDialog.setVisibility(View.GONE);
                    parentLayout.setVisibility(View.GONE);


                    errorDisplay.setVisibility(View.VISIBLE);

                    errorDisplayIcon.setImageResource(R.drawable.ic_error_server);
                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(HomeAddProductsActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1342")) {
                            errorDisplayText.setText(languageLabelModelList.get(index).getValue());
                        }
                    }
                    //errorDisplayText.setText(getString(R.string.error_server));
                }




            }

        });



    }






    //Service - Getting Product
    private void callGetProductService() {



        String accessTokenId = marketPreference.getString(Constants.LOGIN_ACCESSTOKEN_ID, null);
        final String userId = marketPreference.getString(Constants.LOGIN_USER_ID, null);
        String roleId = marketPreference.getString(Constants.LOGIN_ROLE_ID, null);

        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Config.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        final Api api = retrofit.create(Api.class);

        Call<List<ProductOutput>> call = (Call<List<ProductOutput>>) api.getProduct(accessTokenId,
                userId,
                roleId,
                Constants.SERVICE_GET_PRODUCT_LIST);
        call.enqueue(new Callback<List<ProductOutput>>() {
            @Override
            public void onResponse(Call<List<ProductOutput>> call, Response<List<ProductOutput>> response) {

                List<ProductOutput> productOutputListTemp = response.body();

                //Checking for response code
                if (response.code() == 200 ) {


                    if (productOutputListTemp.size() == 0)
                    {
                        //Hiding views
                        progressDialog.setVisibility(View.GONE);
                        parentLayout.setVisibility(View.GONE);

                        errorDisplay.setVisibility(View.VISIBLE);

                        errorDisplayIcon.setImageResource(R.drawable.ic_error_product);
                        List<MobileLang> languageLabelModelList = getLanguageLabelPreference(HomeAddProductsActivity.this);
                        for (int index = 0; index<languageLabelModelList.size();index++) {
                            if (languageLabelModelList.get(index).getLangCode().equals("1346")) {
                                errorDisplayText.setText(languageLabelModelList.get(index).getValue());
                            }
                        }
                        //errorDisplayText.setText(getString( R.string.error_no_data_products));
                        errorDisplayTryClick.setVisibility(View.GONE);
                    }
                    else {

                        productOutputList = productOutputListTemp;

                        addProductHomeListAdapter = new AddProductHomeListAdapter(HomeAddProductsActivity.this,productOutputList);
                        productList.setAdapter(addProductHomeListAdapter);
                        addProductHomeListAdapter.notifyDataSetChanged();


                        homeAddProductsCategoryAdapter = new HomeAddProductsCategoryAdapter(HomeAddProductsActivity.this, categoryOutputList);
                        categoryList.setAdapter(homeAddProductsCategoryAdapter);
                        homeAddProductsCategoryAdapter.notifyDataSetChanged();


                        //Hiding views
                        progressDialog.setVisibility(View.GONE);
                        errorDisplay.setVisibility(View.GONE);

                        parentLayout.setVisibility(View.VISIBLE);


                    }

                }
                //If status code is not 200
                else
                {

                    progressDialog.setVisibility(View.GONE);
                    parentLayout.setVisibility(View.GONE);


                    errorDisplay.setVisibility(View.VISIBLE);

                    errorDisplayIcon.setImageResource(R.drawable.ic_error_code);
                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(HomeAddProductsActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1341")) {
                            errorDisplayText.setText(languageLabelModelList.get(index).getValue() + ":" + response.code());
                        }
                    }
                    //errorDisplayText.setText(getString(R.string.error_response_code) + response.code());

                }
            }

            @Override
            public void onFailure(Call<List<ProductOutput>> call, Throwable t) {

                Log.e("Failure",t.toString());

                if (t instanceof IOException) {

                    //Hiding views
                    progressDialog.setVisibility(View.GONE);
                    parentLayout.setVisibility(View.GONE);

                    errorDisplay.setVisibility(View.VISIBLE);

                    errorDisplayIcon.setImageResource(R.drawable.ic_error_product);
                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(HomeAddProductsActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1346")) {
                            errorDisplayText.setText(languageLabelModelList.get(index).getValue());
                        }
                    }
                    //errorDisplayText.setText(getString( R.string.error_no_data_products));
                    errorDisplayTryClick.setVisibility(View.GONE);
                }
                else
                {
                    //Hiding views
                    progressDialog.setVisibility(View.GONE);
                    parentLayout.setVisibility(View.GONE);


                    errorDisplay.setVisibility(View.VISIBLE);

                    errorDisplayIcon.setImageResource(R.drawable.ic_error_server);
                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(HomeAddProductsActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1342")) {
                            errorDisplayText.setText(languageLabelModelList.get(index).getValue());
                        }
                    }
                    //errorDisplayText.setText(getString(R.string.error_server));
                }




                }

        });



    }

    //Service - Add Product
    private void callAddProductService() {

        //Showing loading
        progressDialogSecond.show();

        String accessTokenId = marketPreference.getString(Constants.LOGIN_ACCESSTOKEN_ID, null);
        final String userId = marketPreference.getString(Constants.LOGIN_USER_ID, null);
        String roleId = marketPreference.getString(Constants.LOGIN_ROLE_ID, null);

        List<AddProductInput> addProductInputList = new ArrayList<>();

        for (int index = 0; index<selectedProductOutputList.size();index++)
        {
            ProductOutput productOutput = selectedProductOutputList.get(index);

            AddProductInput addProductInput = new AddProductInput();

            UserId userIdObject = new UserId();
            userIdObject.setUserId(userId);

            CreatedBy createdByObject = new CreatedBy();
            createdByObject.setUserId(userId);

            ProductId productIdObject = new ProductId();
            productIdObject.setProductId(productOutput.getProductId());

            addProductInput.setUserId(userIdObject);
            addProductInput.setCreatedBy(createdByObject);
            addProductInput.setProductId(productIdObject);

            addProductInputList.add(addProductInput);

        }

        builder = getHttpClient();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Config.BASE_URL).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
        final Api api = retrofit.create(Api.class);

        Call<ResponseBody> call = (Call<ResponseBody>) api.addProduct(accessTokenId,
                userId,
                roleId,
                Constants.SERVICE_ADD_PRODUCT,
                addProductInputList);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {


                //Checking for response code
                if (response.code() == 201 ) {

                    //Dismiss loading
                    progressDialogSecond.dismiss();

                    SharedPreferences.Editor preferenceEditor = marketPreference.edit();

                    //Preference Editor
                    preferenceEditor.putBoolean(Constants.IS_PRODUCT_ADDED, true);

                    preferenceEditor.commit();

                    //Going to Home Activity
                    startActivity(new Intent(HomeAddProductsActivity.this, HomeActivity.class));
                    finish();


                }
                //If status code is not 201
                else
                {

                    //Dismiss loading
                    progressDialogSecond.dismiss();

                    List<MobileLang> languageLabelModelList = getLanguageLabelPreference(HomeAddProductsActivity.this);
                    for (int index = 0; index<languageLabelModelList.size();index++) {
                        if (languageLabelModelList.get(index).getLangCode().equals("1341")) {
                            ServerError=languageLabelModelList.get(index).getValue() + ":" + response.code();
                        }
                    }
                    Snackbar snackbar = Snackbar
                            .make(homeAddProductsActivityContainer, ServerError, Snackbar.LENGTH_LONG);

                    snackbar.show();

                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {


                //Dismiss loading
                progressDialogSecond.dismiss();

                Log.e("Failure",t.toString());
                List<MobileLang> languageLabelModelList = getLanguageLabelPreference(HomeAddProductsActivity.this);
                for (int index = 0; index<languageLabelModelList.size();index++) {
                    if (languageLabelModelList.get(index).getLangCode().equals("1342")) {
                        SomethingWrong=languageLabelModelList.get(index).getValue();
                    }
                }
                Snackbar snackbar = Snackbar
                        .make(homeAddProductsActivityContainer, SomethingWrong, Snackbar.LENGTH_LONG);

                snackbar.show();



            }

        });
    }

    //Retrofit log
    public OkHttpClient.Builder getHttpClient() {

        if (builder == null) {
            HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            OkHttpClient.Builder client = new OkHttpClient.Builder();
            client.addInterceptor(loggingInterceptor);
            client.writeTimeout(60000, TimeUnit.MILLISECONDS);
            client.readTimeout(60000, TimeUnit.MILLISECONDS);
            client.connectTimeout(60000, TimeUnit.MILLISECONDS);
            return client;
        }
        return builder;
    }



}
